import { Student, ActivityJournal, AcademicEvent, SchoolSettings } from '../types';
import { 
  fetchStudentsFromSheets, 
  syncStudentsToSheets, 
  fetchJournalsFromSheets, 
  appendJournalToSheets 
} from './googleWorkspace';

export type RealtimeSyncAction = 
  | { type: 'STUDENT_ADDED'; payload: Student }
  | { type: 'STUDENT_UPDATED'; payload: Student }
  | { type: 'STUDENT_PHOTO_UPDATED'; payload: { studentId: string; avatar: string } }
  | { type: 'JOURNAL_ADDED'; payload: ActivityJournal }
  | { type: 'JOURNAL_UPDATED'; payload: ActivityJournal }
  | { type: 'RATING_GIVEN'; payload: { journalId: string; rating: number } }
  | { type: 'COMMENT_ADDED'; payload: { journalId: string; comment: any } }
  | { type: 'SETTINGS_UPDATED'; payload: SchoolSettings }
  | { type: 'DATABASE_REFRESHED'; payload: { students?: Student[]; journals?: ActivityJournal[] } };

type ListenerCallback = (action: RealtimeSyncAction) => void;

class RealtimeSyncManager {
  private channel: BroadcastChannel | null = null;
  private listeners: Set<ListenerCallback> = new Set();
  private isConnectedToDatabase = false;
  private isSyncing = false;
  private lastSyncedTime: Date | null = null;

  constructor() {
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      try {
        this.channel = new BroadcastChannel('jurnal_siswa_realtime_db');
        this.channel.onmessage = (event) => {
          if (event.data) {
            this.notifyLocalListeners(event.data);
          }
        };
      } catch (e) {
        console.warn('BroadcastChannel unavailable:', e);
      }
    }

    // Fallback: Listen to storage events for cross-tab sync
    if (typeof window !== 'undefined') {
      window.addEventListener('storage', (e) => {
        if (e.key === 'jurnal_realtime_event' && e.newValue) {
          try {
            const action: RealtimeSyncAction = JSON.parse(e.newValue);
            this.notifyLocalListeners(action);
          } catch {
            // Ignore parse errors
          }
        }
      });
    }
  }

  public subscribe(callback: ListenerCallback): () => void {
    this.listeners.add(callback);
    return () => {
      this.listeners.delete(callback);
    };
  }

  private notifyLocalListeners(action: RealtimeSyncAction) {
    this.listeners.forEach((listener) => {
      try {
        listener(action);
      } catch (err) {
        console.error('Error in realtime listener:', err);
      }
    });
  }

  /**
   * Broadcast an action to all other tabs and window instances in real-time
   */
  public broadcast(action: RealtimeSyncAction) {
    // 1. Notify local listeners in current tab
    this.notifyLocalListeners(action);

    // 2. Broadcast via channel
    if (this.channel) {
      try {
        this.channel.postMessage(action);
      } catch (e) {
        console.warn('Channel postMessage failed:', e);
      }
    }

    // 3. Storage event fallback
    if (typeof window !== 'undefined' && window.localStorage) {
      try {
        localStorage.setItem(
          'jurnal_realtime_event',
          JSON.stringify({ ...action, _ts: Date.now() })
        );
      } catch {
        // storage quota or private mode
      }
    }
  }

  public setDatabaseConnected(connected: boolean) {
    this.isConnectedToDatabase = connected;
  }

  public getStatus() {
    return {
      isDatabaseConnected: this.isConnectedToDatabase,
      isSyncing: this.isSyncing,
      lastSyncedTime: this.lastSyncedTime,
    };
  }

  /**
   * Push current student list to remote database automatically
   */
  public async autoSyncStudents(students: Student[]): Promise<boolean> {
    if (!this.isConnectedToDatabase) return false;
    this.isSyncing = true;
    try {
      const ok = await syncStudentsToSheets(students);
      if (ok) {
        this.lastSyncedTime = new Date();
      }
      return ok;
    } finally {
      this.isSyncing = false;
    }
  }

  /**
   * Push a single journal entry to remote database automatically
   */
  public async autoSyncJournal(journal: ActivityJournal): Promise<boolean> {
    if (!this.isConnectedToDatabase) return false;
    this.isSyncing = true;
    try {
      const ok = await appendJournalToSheets(journal);
      if (ok) {
        this.lastSyncedTime = new Date();
      }
      return ok;
    } finally {
      this.isSyncing = false;
    }
  }

  /**
   * Pull latest data from Google Sheets database in background
   */
  public async pullLatestFromDatabase(): Promise<{
    students: Student[] | null;
    journals: ActivityJournal[] | null;
  }> {
    if (!this.isConnectedToDatabase) {
      return { students: null, journals: null };
    }
    this.isSyncing = true;
    try {
      const [students, journals] = await Promise.all([
        fetchStudentsFromSheets(),
        fetchJournalsFromSheets(),
      ]);
      if (students || journals) {
        this.lastSyncedTime = new Date();
      }
      return { students, journals };
    } finally {
      this.isSyncing = false;
    }
  }
}

export const realtimeSync = new RealtimeSyncManager();
