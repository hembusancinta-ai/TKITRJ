/**
 * Web Speech Recognition Service for Indonesian voice-to-text narrative input
 */

// Declare SpeechRecognition interface for browser types
declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

export interface SpeechListenerOptions {
  onResult: (transcript: string, isFinal: boolean) => void;
  onError?: (errorMsg: string) => void;
  onStart?: () => void;
  onEnd?: () => void;
  lang?: string;
}

export class SpeechToTextService {
  private recognition: any = null;
  private isListening = false;
  private isSupported = false;

  constructor() {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SpeechRecognition) {
        this.isSupported = true;
        this.recognition = new SpeechRecognition();
        this.recognition.continuous = true;
        this.recognition.interimResults = true;
        this.recognition.lang = 'id-ID'; // Bahasa Indonesia
      }
    }
  }

  public checkSupport(): boolean {
    return this.isSupported;
  }

  public startListening(options: SpeechListenerOptions) {
    if (!this.isSupported || !this.recognition) {
      if (options.onError) {
        options.onError('Browser ini belum mendukung fitur pengenalan suara langsung (Web Speech API).');
      }
      return;
    }

    if (this.isListening) {
      this.stopListening();
    }

    this.recognition.lang = options.lang || 'id-ID';

    this.recognition.onstart = () => {
      this.isListening = true;
      if (options.onStart) options.onStart();
    };

    this.recognition.onresult = (event: any) => {
      let interimTranscript = '';
      let finalTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalTranscript += transcript;
        } else {
          interimTranscript += transcript;
        }
      }

      if (finalTranscript) {
        options.onResult(finalTranscript.trim(), true);
      } else if (interimTranscript) {
        options.onResult(interimTranscript.trim(), false);
      }
    };

    this.recognition.onerror = (event: any) => {
      let message = 'Terjadi kesalahan saat merekam suara.';
      if (event.error === 'not-allowed') {
        message = 'Izin mikrofon ditolak oleh peramban. Silakan berikan izin mikrofon.';
      } else if (event.error === 'no-speech') {
        message = 'Tidak ada suara yang terdeteksi. Silakan coba lagi.';
      }
      if (options.onError) options.onError(message);
      this.isListening = false;
    };

    this.recognition.onend = () => {
      this.isListening = false;
      if (options.onEnd) options.onEnd();
    };

    try {
      this.recognition.start();
    } catch (e) {
      console.warn('Error starting speech recognition:', e);
      if (options.onError) options.onError('Tidak dapat memulai perekam suara.');
    }
  }

  public stopListening() {
    if (this.recognition && this.isListening) {
      try {
        this.recognition.stop();
      } catch (e) {
        console.warn('Error stopping speech recognition:', e);
      }
      this.isListening = false;
    }
  }

  public getListeningState(): boolean {
    return this.isListening;
  }
}

export const speechService = new SpeechToTextService();
