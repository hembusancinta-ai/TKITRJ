import { Student, ActivityJournal, AcademicEvent, DriveMediaItem } from '../types';
import { getAccessToken } from './googleAuth';
import { INITIAL_STUDENTS } from '../data/sampleData';

const SPREADSHEET_KEY = 'jurnal_siswa_spreadsheet_id';
const DRIVE_FOLDER_KEY = 'jurnal_siswa_drive_folder_id';

export interface WorkspaceSyncStatus {
  isConnected: boolean;
  spreadsheetId: string | null;
  spreadsheetUrl: string | null;
  driveFolderId: string | null;
  driveFolderUrl: string | null;
  lastSynced: string | null;
  syncing: boolean;
  error: string | null;
}

/**
 * Initialize or get Google Spreadsheet ID
 */
export async function getOrCreateSpreadsheet(): Promise<{ id: string; url: string }> {
  const token = await getAccessToken();
  if (!token) throw new Error('Token akses Google tidak tersedia.');

  const existingId = localStorage.getItem(SPREADSHEET_KEY);
  if (existingId) {
    try {
      // Test check if accessible
      const res = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${existingId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        return {
          id: existingId,
          url: `https://docs.google.com/spreadsheets/d/${existingId}`
        };
      }
    } catch (e) {
      console.warn('Existing spreadsheet unreachable, creating new one', e);
    }
  }

  // Create new Spreadsheet with proper sheets & headers
  const createRes = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      properties: {
        title: 'Jurnal Perkembangan & Aktivitas Siswa (Database Otomatis)'
      },
      sheets: [
        {
          properties: { title: 'Siswa' },
          data: [
            {
              startRow: 0,
              startColumn: 0,
              rowData: [
                {
                  values: [
                    { userEnteredValue: { stringValue: 'ID_Siswa' } },
                    { userEnteredValue: { stringValue: 'NIS' } },
                    { userEnteredValue: { stringValue: 'Nama_Lengkap' } },
                    { userEnteredValue: { stringValue: 'Kelas' } },
                    { userEnteredValue: { stringValue: 'Gender' } },
                    { userEnteredValue: { stringValue: 'Nama_Orang_Tua' } },
                    { userEnteredValue: { stringValue: 'No_Telepon' } },
                    { userEnteredValue: { stringValue: 'Email_Orang_Tua' } },
                    { userEnteredValue: { stringValue: 'Foto_URL' } },
                  ]
                },
                // Prepopulate initial students so dropdown works immediately
                ...INITIAL_STUDENTS.map(s => ({
                  values: [
                    { userEnteredValue: { stringValue: s.id } },
                    { userEnteredValue: { stringValue: s.nis } },
                    { userEnteredValue: { stringValue: s.name } },
                    { userEnteredValue: { stringValue: s.className } },
                    { userEnteredValue: { stringValue: s.gender } },
                    { userEnteredValue: { stringValue: s.parentName } },
                    { userEnteredValue: { stringValue: s.parentPhone } },
                    { userEnteredValue: { stringValue: s.parentEmail } },
                    { userEnteredValue: { stringValue: s.avatar || '' } },
                  ]
                }))
              ]
            }
          ]
        },
        {
          properties: { title: 'JurnalAktivitas' },
          data: [
            {
              startRow: 0,
              startColumn: 0,
              rowData: [
                {
                  values: [
                    { userEnteredValue: { stringValue: 'ID_Jurnal' } },
                    { userEnteredValue: { stringValue: 'Tanggal' } },
                    { userEnteredValue: { stringValue: 'Jam' } },
                    { userEnteredValue: { stringValue: 'ID_Siswa' } },
                    { userEnteredValue: { stringValue: 'Nama_Siswa' } },
                    { userEnteredValue: { stringValue: 'Kelas' } },
                    { userEnteredValue: { stringValue: 'Kategori' } },
                    { userEnteredValue: { stringValue: 'Capaian' } },
                    { userEnteredValue: { stringValue: 'Judul' } },
                    { userEnteredValue: { stringValue: 'Narasi' } },
                    { userEnteredValue: { stringValue: 'Foto_URL' } },
                    { userEnteredValue: { stringValue: 'Nama_Guru' } },
                  ]
                }
              ]
            }
          ]
        },
        {
          properties: { title: 'AgendaAkademik' },
          data: [
            {
              startRow: 0,
              startColumn: 0,
              rowData: [
                {
                  values: [
                    { userEnteredValue: { stringValue: 'ID_Agenda' } },
                    { userEnteredValue: { stringValue: 'Tanggal' } },
                    { userEnteredValue: { stringValue: 'Jam_Mulai' } },
                    { userEnteredValue: { stringValue: 'Jam_Selesai' } },
                    { userEnteredValue: { stringValue: 'Judul' } },
                    { userEnteredValue: { stringValue: 'Deskripsi' } },
                    { userEnteredValue: { stringValue: 'Kategori' } },
                    { userEnteredValue: { stringValue: 'Lokasi' } },
                  ]
                }
              ]
            }
          ]
        }
      ]
    })
  });

  if (!createRes.ok) {
    const err = await createRes.text();
    throw new Error(`Gagal membuat spreadsheet Google Sheets: ${err}`);
  }

  const created = await createRes.json();
  localStorage.setItem(SPREADSHEET_KEY, created.spreadsheetId);
  return {
    id: created.spreadsheetId,
    url: created.spreadsheetUrl || `https://docs.google.com/spreadsheets/d/${created.spreadsheetId}`
  };
}

/**
 * Fetch list of students from Google Sheets
 */
export async function fetchStudentsFromSheets(): Promise<Student[] | null> {
  const token = await getAccessToken();
  const spreadsheetId = localStorage.getItem(SPREADSHEET_KEY);
  if (!token || !spreadsheetId) return null;

  try {
    const res = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Siswa!A2:I`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    if (!res.ok) return null;
    const data = await res.json();
    if (!data.values || data.values.length === 0) return null;

    return data.values.map((row: string[], idx: number) => {
      const fallbackAvatar = INITIAL_STUDENTS[idx % INITIAL_STUDENTS.length]?.avatar || 'https://images.unsplash.com/photo-1544717302-de2939b7ef71?w=150&auto=format&fit=crop&q=80';
      return {
        id: row[0] || `std-gs-${idx + 1}`,
        nis: row[1] || `2024010${idx + 1}`,
        name: row[2] || `Siswa ${idx + 1}`,
        className: row[3] || 'Kelas 2-A (Cendrawasih)',
        gender: (row[4] as 'L' | 'P') || 'L',
        parentName: row[5] || 'Orang Tua Siswa',
        parentPhone: row[6] || '08123456789',
        parentEmail: row[7] || 'ortu@gmail.com',
        avatar: (row[8] && row[8].trim().length > 0) ? row[8] : fallbackAvatar,
      };
    });
  } catch (err) {
    console.error('Error fetching students from sheets:', err);
    return null;
  }
}

/**
 * Synchronize all students back to Google Sheets database
 */
export async function syncStudentsToSheets(students: Student[]): Promise<boolean> {
  const token = await getAccessToken();
  const spreadsheetId = localStorage.getItem(SPREADSHEET_KEY);
  if (!token || !spreadsheetId) return false;

  try {
    const rows = students.map(s => [
      s.id,
      s.nis,
      s.name,
      s.className,
      s.gender,
      s.parentName,
      s.parentPhone,
      s.parentEmail,
      s.avatar || '',
    ]);

    // Clear and re-populate to prevent stale duplicates
    await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Siswa!A2:I:clear`,
      {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      }
    );

    const res = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Siswa!A2:I?valueInputOption=USER_ENTERED`,
      {
        method: 'PUT',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          values: rows,
        }),
      }
    );

    return res.ok;
  } catch (err) {
    console.error('Error syncing students to sheets:', err);
    return false;
  }
}

/**
 * Fetch all journal records from Google Sheets database
 */
export async function fetchJournalsFromSheets(): Promise<ActivityJournal[] | null> {
  const token = await getAccessToken();
  const spreadsheetId = localStorage.getItem(SPREADSHEET_KEY);
  if (!token || !spreadsheetId) return null;

  try {
    const res = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/JurnalAktivitas!A2:L`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    if (!res.ok) return null;
    const data = await res.json();
    if (!data.values || data.values.length === 0) return null;

    return data.values.map((row: string[], idx: number) => ({
      id: row[0] || `jnl-sheet-${idx + 1}`,
      date: row[1] || new Date().toISOString().split('T')[0],
      time: row[2] || '08:00',
      timestamp: Date.now() - (idx * 3600000),
      studentId: row[3] || '',
      studentName: row[4] || '',
      className: row[5] || '',
      category: (row[6] as any) || 'Kognitif & Logika',
      milestone: (row[7] as any) || 'Berkembang Sesuai Harapan',
      title: row[8] || '',
      narrative: row[9] || '',
      photoUrl: row[10] || '',
      teacherName: row[11] || 'Guru',
      syncedToGoogleSheets: true,
    }));
  } catch (err) {
    console.error('Error fetching journals from sheets:', err);
    return null;
  }
}

/**
 * Append journal record to Google Sheets
 */
export async function appendJournalToSheets(journal: ActivityJournal): Promise<boolean> {
  const token = await getAccessToken();
  const spreadsheetId = localStorage.getItem(SPREADSHEET_KEY);
  if (!token || !spreadsheetId) return false;

  try {
    const rowValues = [
      journal.id,
      journal.date,
      journal.time,
      journal.studentId,
      journal.studentName,
      journal.className,
      journal.category,
      journal.milestone,
      journal.title,
      journal.narrative,
      journal.photoUrl || '',
      journal.teacherName,
    ];

    const res = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/JurnalAktivitas!A:L:append?valueInputOption=USER_ENTERED`,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          values: [rowValues],
        }),
      }
    );

    return res.ok;
  } catch (err) {
    console.error('Error appending journal to sheets:', err);
    return false;
  }
}

/**
 * Get or create Google Drive Folder for Activity Photos
 */
export async function getOrCreateDriveFolder(): Promise<{ id: string; url: string }> {
  const token = await getAccessToken();
  if (!token) throw new Error('Token akses Google tidak tersedia.');

  const existingFolderId = localStorage.getItem(DRIVE_FOLDER_KEY);
  if (existingFolderId) {
    try {
      const res = await fetch(`https://www.googleapis.com/drive/v3/files/${existingFolderId}?fields=id,name,webViewLink`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const d = await res.json();
        return { id: d.id, url: d.webViewLink || `https://drive.google.com/drive/folders/${d.id}` };
      }
    } catch {
      // Create new folder
    }
  }

  // Create folder in user's Drive
  const res = await fetch('https://www.googleapis.com/drive/v3/files', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      name: 'Dokumentasi Jurnal Siswa',
      mimeType: 'application/vnd.google-apps.folder',
      description: 'Folder foto aktivitas dan perkembangan siswa dari aplikasi Jurnal Siswa'
    })
  });

  if (!res.ok) throw new Error('Gagal membuat folder di Google Drive');
  const folder = await res.json();
  localStorage.setItem(DRIVE_FOLDER_KEY, folder.id);
  return {
    id: folder.id,
    url: folder.webViewLink || `https://drive.google.com/drive/folders/${folder.id}`
  };
}

/**
 * Upload Image to Google Drive folder
 */
export async function uploadImageToDrive(
  fileBlob: Blob,
  fileName: string,
  description?: string
): Promise<{ id: string; webViewLink: string; thumbnailLink?: string }> {
  const token = await getAccessToken();
  if (!token) throw new Error('Token akses Google tidak tersedia.');

  const { id: folderId } = await getOrCreateDriveFolder();

  const metadata = {
    name: fileName,
    parents: [folderId],
    description: description || 'Foto perkembangan aktivitas siswa',
  };

  const form = new FormData();
  form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
  form.append('file', fileBlob);

  const res = await fetch(
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink,thumbnailLink',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: form,
    }
  );

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Gagal upload ke Google Drive: ${err}`);
  }

  return await res.json();
}

/**
 * Fetch gallery files from Google Drive folder
 */
export async function fetchDriveGallery(): Promise<DriveMediaItem[] | null> {
  const token = await getAccessToken();
  const folderId = localStorage.getItem(DRIVE_FOLDER_KEY);
  if (!token || !folderId) return null;

  try {
    const query = encodeURIComponent(`'${folderId}' in parents and trashed = false`);
    const res = await fetch(
      `https://www.googleapis.com/drive/v3/files?q=${query}&fields=files(id,name,mimeType,thumbnailLink,webViewLink,createdTime,description)&pageSize=30`,
      {
        headers: { Authorization: `Bearer ${token}` }
      }
    );

    if (!res.ok) return null;
    const data = await res.json();
    if (!data.files) return null;

    return data.files.map((f: any) => ({
      id: f.id,
      name: f.name,
      mimeType: f.mimeType,
      thumbnailUrl: f.thumbnailLink || f.webViewLink,
      date: f.createdTime ? f.createdTime.split('T')[0] : new Date().toISOString().split('T')[0],
      description: f.description || '',
    }));
  } catch (err) {
    console.error('Error fetching drive gallery:', err);
    return null;
  }
}

/**
 * Sync an academic event with Google Calendar
 */
export async function syncEventToGoogleCalendar(event: AcademicEvent): Promise<string | null> {
  const token = await getAccessToken();
  if (!token) return null;

  try {
    const startDateTime = event.startTime 
      ? `${event.date}T${event.startTime}:00+07:00`
      : `${event.date}T08:00:00+07:00`;
    
    const endDateTime = event.endTime
      ? `${event.date}T${event.endTime}:00+07:00`
      : `${event.date}T10:00:00+07:00`;

    const res = await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        summary: `[Sekolah] ${event.title}`,
        description: `${event.description}\nKategori: ${event.category}\nLokasi: ${event.location || 'Sekolah'}`,
        location: event.location || 'Sekolah',
        start: { dateTime: startDateTime },
        end: { dateTime: endDateTime },
      }),
    });

    if (res.ok) {
      const created = await res.json();
      return created.id;
    }
  } catch (err) {
    console.warn('Could not sync to Google Calendar:', err);
  }
  return null;
}
