import { jsPDF } from 'jspdf';
import { Student, ActivityJournal, WeeklySummaryData, SchoolSettings } from '../types';

export function generateStudentReportPdf(
  student: Student,
  journals: ActivityJournal[],
  periodLabel: string = 'Minggu Ini (September 2026)',
  summary?: WeeklySummaryData,
  schoolSettings?: SchoolSettings
): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  let y = 18;

  const schoolName = (schoolSettings?.schoolName || 'SEKOLAH DASAR & TK CENDEKIA HARAPAN').toUpperCase();
  const schoolAddress = schoolSettings?.schoolAddress || 'Jl. Pendidikan No. 45, Jakarta | Telp: (021) 7890-1234 | info@cendekia.sch.id';

  // Header / Kop Surat
  doc.setFillColor(30, 58, 138); // Navy blue primary
  doc.rect(14, y, pageWidth - 28, 2, 'F');
  y += 6;

  // Render School Logo if available
  if (schoolSettings?.schoolLogo) {
    try {
      doc.addImage(schoolSettings.schoolLogo, 'PNG', 14, y, 16, 16);
    } catch {
      try {
        doc.addImage(schoolSettings.schoolLogo, 'JPEG', 14, y, 16, 16);
      } catch (err) {
        console.warn('Could not embed school logo into PDF:', err);
      }
    }
  }

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.setTextColor(30, 58, 138);
  doc.text(schoolName, pageWidth / 2, y + 4, { align: 'center' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(100, 116, 139);
  doc.text(schoolAddress, pageWidth / 2, y + 10, { align: 'center' });
  y += 15;

  doc.setDrawColor(203, 213, 225);
  doc.setLineWidth(0.5);
  doc.line(14, y, pageWidth - 14, y);
  y += 7;

  // Document Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(15, 23, 42);
  doc.text('LAPORAN JURNAL PERKEMBANGAN & AKTIVITAS SISWA', pageWidth / 2, y, { align: 'center' });
  y += 5;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.setTextColor(71, 85, 105);
  doc.text(`Periode Pemantauan: ${periodLabel}`, pageWidth / 2, y, { align: 'center' });
  y += 8;

  // Student Information Box
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(14, y, pageWidth - 28, 30, 2, 2, 'FD');

  const boxY = y + 6;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(30, 41, 59);
  doc.text('Nama Siswa', 18, boxY);
  doc.text('NIS / NISN', 18, boxY + 7);
  doc.text('Kelas', 18, boxY + 14);

  doc.setFont('helvetica', 'normal');
  doc.text(`: ${student.name}`, 44, boxY);
  doc.text(`: ${student.nis}`, 44, boxY + 7);
  doc.text(`: ${student.className}`, 44, boxY + 14);

  doc.setFont('helvetica', 'bold');
  doc.text('Orang Tua/Wali', 96, boxY);
  doc.text('Kontak Wali', 96, boxY + 7);
  doc.text('Tanggal Cetak', 96, boxY + 14);

  doc.setFont('helvetica', 'normal');
  doc.text(`: ${student.parentName}`, 124, boxY);
  doc.text(`: ${student.parentPhone}`, 124, boxY + 7);
  const today = new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
  doc.text(`: ${today}`, 124, boxY + 14);

  // Embed Student Photo in PDF
  const photoW = 20;
  const photoH = 24;
  const photoX = pageWidth - 14 - photoW - 3;
  const photoY = y + 3;

  doc.setFillColor(241, 245, 249);
  doc.setDrawColor(203, 213, 225);
  doc.rect(photoX, photoY, photoW, photoH, 'FD');

  if (student.avatar) {
    try {
      doc.addImage(student.avatar, 'JPEG', photoX, photoY, photoW, photoH);
    } catch {
      try {
        doc.addImage(student.avatar, 'PNG', photoX, photoY, photoW, photoH);
      } catch (err) {
        console.warn('Could not embed student photo into PDF:', err);
        doc.setFontSize(7);
        doc.setTextColor(148, 163, 184);
        doc.text('Foto Siswa', photoX + 4, photoY + 13);
      }
    }
  }

  y += 36;

  // Overview Summary Section
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(30, 58, 138);
  doc.text('I. RINGKASAN CAPAIAN PERKEMBANGAN', 14, y);
  y += 6;

  // Stat summary pills
  const totalAct = journals.length;
  const categoriesFound = Array.from(new Set(journals.map(j => j.category)));

  doc.setFillColor(239, 246, 255);
  doc.setDrawColor(191, 219, 254);
  doc.roundedRect(14, y, 55, 12, 1.5, 1.5, 'FD');
  doc.setFontSize(8);
  doc.setTextColor(30, 58, 138);
  doc.text(`Total Aktivitas Tercatat: ${totalAct} Catatan`, 18, y + 7.5);

  doc.setFillColor(240, 253, 244);
  doc.setDrawColor(187, 247, 208);
  doc.roundedRect(73, y, 60, 12, 1.5, 1.5, 'FD');
  doc.setTextColor(22, 101, 52);
  doc.text(`Aspek Terdokumentasi: ${categoriesFound.length} Aspek`, 77, y + 7.5);

  doc.setFillColor(254, 243, 199);
  doc.setDrawColor(253, 230, 138);
  doc.roundedRect(137, y, 59, 12, 1.5, 1.5, 'FD');
  doc.setTextColor(146, 64, 14);
  doc.text('Status: Berkembang Positif', 141, y + 7.5);

  y += 18;

  // Activities Table / List
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(30, 58, 138);
  doc.text('II. CATATAN AKTIVITAS & PERKEMBANGAN HARIAN', 14, y);
  y += 6;

  if (journals.length === 0) {
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(9);
    doc.setTextColor(100, 116, 139);
    doc.text('Belum ada catatan aktivitas pada periode ini.', 14, y);
    y += 10;
  } else {
    // Render each journal entry
    journals.slice(0, 5).forEach((j, index) => {
      // Check if near page bottom
      if (y > 240) {
        doc.addPage();
        y = 20;
      }

      doc.setFillColor(248, 250, 252);
      doc.setDrawColor(226, 232, 240);
      doc.rect(14, y, pageWidth - 28, 28, 'FD');

      // Entry title & date
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.setTextColor(15, 23, 42);
      doc.text(`${index + 1}. ${j.title}`, 18, y + 6);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(100, 116, 139);
      doc.text(`${j.date} • ${j.time} WIB | Guru: ${j.teacherName}`, pageWidth - 20, y + 6, { align: 'right' });

      // Badge Category & Milestone
      doc.setFillColor(224, 231, 255);
      doc.roundedRect(18, y + 8, 42, 5, 1, 1, 'F');
      doc.setFontSize(7.5);
      doc.setTextColor(67, 56, 202);
      doc.text(`[${j.category}]`, 20, y + 11.5);

      doc.setFillColor(220, 252, 231);
      doc.roundedRect(63, y + 8, 50, 5, 1, 1, 'F');
      doc.setTextColor(21, 128, 61);
      doc.text(`Capaian: ${j.milestone}`, 65, y + 11.5);

      // Narrative text with auto wrapping
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(51, 65, 85);
      const splitText = doc.splitTextToSize(j.narrative, pageWidth - 40);
      doc.text(splitText.slice(0, 3), 18, y + 18);

      y += 32;
    });
  }

  // Teacher note / reflection
  if (y > 230) {
    doc.addPage();
    y = 20;
  }

  y += 4;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(30, 58, 138);
  doc.text('III. REKOMENDASI GURU WALI KELAS', 14, y);
  y += 5;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(51, 65, 85);
  const defaultRec = summary?.teacherNotes || 
    `${student.name} menunjukkan progress yang membanggakan di bidang kemandirian dan rasa ingin tahu. Disarankan bagi orang tua di rumah untuk terus memberikan ruang eksplorasi aktif dan membaca buku cerita bersama 15 menit sebelum tidur.`;
  const recLines = doc.splitTextToSize(defaultRec, pageWidth - 28);
  doc.text(recLines, 14, y);

  y += 18;

  // Signatures
  if (y > 245) {
    doc.addPage();
    y = 20;
  }

  const signY = y + 10;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(30, 41, 59);

  doc.text('Mengetahui,', 25, signY);
  doc.text('Orang Tua / Wali Siswa,', 25, signY + 5);

  doc.text('Guru Wali Kelas 2-A,', pageWidth - 70, signY + 5);

  // Sign lines
  doc.line(25, signY + 28, 70, signY + 28);
  doc.text(`( ${student.parentName} )`, 25, signY + 33);

  doc.line(pageWidth - 70, signY + 28, pageWidth - 25, signY + 28);
  doc.text('( Ibu Ratna Kumalasari, S.Pd )', pageWidth - 70, signY + 33);

  // Save PDF to user device
  const safeName = student.name.replace(/\s+/g, '_');
  doc.save(`Laporan_Jurnal_${safeName}_${new Date().toISOString().split('T')[0]}.pdf`);
}
