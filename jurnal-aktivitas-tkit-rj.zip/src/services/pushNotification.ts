import { NotificationItem } from '../types';

export class PushNotificationService {
  private hasNativePermission: boolean = false;

  constructor() {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      this.hasNativePermission = Notification.permission === 'granted';
    }
  }

  /**
   * Request native browser push notification permission
   */
  public async requestPermission(): Promise<boolean> {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      return false;
    }

    try {
      const permission = await Notification.requestPermission();
      this.hasNativePermission = permission === 'granted';
      return this.hasNativePermission;
    } catch (e) {
      console.warn('Could not request notification permission:', e);
      return false;
    }
  }

  public isPermissionGranted(): boolean {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      return Notification.permission === 'granted';
    }
    return false;
  }

  /**
   * Play a pleasant synthesized chime sound
   */
  public playChime() {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.15); // A5
      
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      osc.start();
      osc.stop(ctx.currentTime + 0.45);
    } catch (e) {
      // Audio context might be restricted before interaction
    }
  }

  /**
   * Trigger push notification
   */
  public sendNotification(item: Omit<NotificationItem, 'id' | 'timestamp' | 'read' | 'time'>): NotificationItem {
    const newItem: NotificationItem = {
      ...item,
      id: `notif-${Date.now()}`,
      time: 'Baru saja',
      timestamp: Date.now(),
      read: false,
    };

    this.playChime();

    // Trigger native browser notification if granted
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(item.title, {
          body: item.message,
          icon: '/public/assets/icon.png',
          badge: '/public/assets/icon.png',
        });
      } catch (err) {
        console.warn('Browser push failed, in-app notification active', err);
      }
    }

    return newItem;
  }
}

export const pushService = new PushNotificationService();
