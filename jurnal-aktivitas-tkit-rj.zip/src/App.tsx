/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { TeacherInputView } from './components/TeacherInputView';
import { ParentView } from './components/ParentView';
import { WeeklySummaryView } from './components/WeeklySummaryView';
import { AcademicCalendarView } from './components/AcademicCalendarView';
import { DriveGalleryView } from './components/DriveGalleryView';
import { SettingsView } from './components/SettingsView';
import { StudentsListView } from './components/StudentsListView';
import { LoginModal } from './components/LoginModal';
import { GoogleConnectModal } from './components/GoogleConnectModal';
import { LoginView } from './components/LoginView';
import { 
  UserRole, 
  Student, 
  ActivityJournal, 
  AcademicEvent, 
  NotificationItem, 
  DriveMediaItem,
  SchoolSettings,
  JournalComment,
  DEFAULT_SCHOOL_SETTINGS
} from './types';
import { 
  INITIAL_STUDENTS, 
  INITIAL_JOURNALS, 
  INITIAL_EVENTS, 
  INITIAL_NOTIFICATIONS, 
  INITIAL_GALLERY 
} from './data/sampleData';
import { 
  initAuth, 
  signInWithGoogle, 
  signOutGoogle, 
  getAccessToken, 
  getGoogleUser 
} from './services/googleAuth';
import { 
  getOrCreateSpreadsheet, 
  fetchStudentsFromSheets, 
  appendJournalToSheets, 
  syncStudentsToSheets,
  fetchJournalsFromSheets,
  getOrCreateDriveFolder, 
  uploadImageToDrive, 
  fetchDriveGallery, 
  syncEventToGoogleCalendar, 
  WorkspaceSyncStatus 
} from './services/googleWorkspace';
import { pushService } from './services/pushNotification';
import { generateStudentReportPdf } from './services/pdfReport';
import { realtimeSync } from './services/realtimeSync';

export default function App() {
  // Authentication state - First screen shown on initial load
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return !!localStorage.getItem('jurnal_active_session');
  });

  // App state
  const [currentRole, setCurrentRole] = useState<UserRole>('teacher');
  const [activeTab, setActiveTab] = useState<string>('input');
  const [currentChildId, setCurrentChildId] = useState<string>('std-1');
  const [preselectedStudentId, setPreselectedStudentId] = useState<string | undefined>(undefined);
  const [isSyncingDatabase, setIsSyncingDatabase] = useState<boolean>(false);

  // Modals
  const [isLoginModalOpen, setIsLoginModalOpen] = useState<boolean>(false);
  const [isGoogleModalOpen, setIsGoogleModalOpen] = useState<boolean>(false);

  // Data collections with local storage initialization
  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem('jurnal_students');
    return saved ? JSON.parse(saved) : INITIAL_STUDENTS;
  });

  const [journals, setJournals] = useState<ActivityJournal[]>(() => {
    const saved = localStorage.getItem('jurnal_activities');
    return saved ? JSON.parse(saved) : INITIAL_JOURNALS;
  });

  const [events, setEvents] = useState<AcademicEvent[]>(() => {
    const saved = localStorage.getItem('jurnal_events');
    return saved ? JSON.parse(saved) : INITIAL_EVENTS;
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const saved = localStorage.getItem('jurnal_notifications');
    return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
  });

  const [galleryItems, setGalleryItems] = useState<DriveMediaItem[]>(() => {
    const saved = localStorage.getItem('jurnal_gallery');
    return saved ? JSON.parse(saved) : INITIAL_GALLERY;
  });

  // School configuration & portal visibility settings
  const [schoolSettings, setSchoolSettings] = useState<SchoolSettings>(() => {
    const saved = localStorage.getItem('jurnal_school_settings');
    return saved ? JSON.parse(saved) : DEFAULT_SCHOOL_SETTINGS;
  });

  // Google Workspace state
  const [syncStatus, setSyncStatus] = useState<WorkspaceSyncStatus>({
    isConnected: false,
    spreadsheetId: localStorage.getItem('jurnal_siswa_spreadsheet_id'),
    spreadsheetUrl: localStorage.getItem('jurnal_siswa_spreadsheet_id') 
      ? `https://docs.google.com/spreadsheets/d/${localStorage.getItem('jurnal_siswa_spreadsheet_id')}` 
      : null,
    driveFolderId: localStorage.getItem('jurnal_siswa_drive_folder_id'),
    driveFolderUrl: localStorage.getItem('jurnal_siswa_drive_folder_id')
      ? `https://drive.google.com/drive/folders/${localStorage.getItem('jurnal_siswa_drive_folder_id')}`
      : null,
    lastSynced: null,
    syncing: false,
    error: null,
  });

  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [googleUserEmail, setGoogleUserEmail] = useState<string | undefined>(undefined);
  const [hasPushPermission, setHasPushPermission] = useState<boolean>(pushService.isPermissionGranted());
  const [isRefreshingGallery, setIsRefreshingGallery] = useState<boolean>(false);

  // Sync state to localStorage
  useEffect(() => {
    localStorage.setItem('jurnal_students', JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem('jurnal_activities', JSON.stringify(journals));
  }, [journals]);

  useEffect(() => {
    localStorage.setItem('jurnal_events', JSON.stringify(events));
  }, [events]);

  useEffect(() => {
    localStorage.setItem('jurnal_notifications', JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem('jurnal_gallery', JSON.stringify(galleryItems));
  }, [galleryItems]);

  useEffect(() => {
    localStorage.setItem('jurnal_school_settings', JSON.stringify(schoolSettings));
  }, [schoolSettings]);

  // Firebase auth initialization
  useEffect(() => {
    const unsubscribe = initAuth(
      async (user, token) => {
        setGoogleUserEmail(user.email || undefined);
        setSyncStatus(prev => ({ ...prev, isConnected: true }));
        realtimeSync.setDatabaseConnected(true);
        // Try fetch students from Google Sheets if available
        const sheetStudents = await fetchStudentsFromSheets();
        if (sheetStudents && sheetStudents.length > 0) {
          setStudents(sheetStudents);
        }
      },
      () => {
        setSyncStatus(prev => ({ ...prev, isConnected: false }));
        realtimeSync.setDatabaseConnected(false);
      }
    );
    return () => unsubscribe();
  }, []);

  // Real-time synchronization across browser tabs and devices
  useEffect(() => {
    const savedSessionStr = localStorage.getItem('jurnal_active_session');
    if (savedSessionStr) {
      try {
        const session = JSON.parse(savedSessionStr);
        if (session.role === 'teacher' || session.role === 'parent') {
          setCurrentRole(session.role);
          if (session.role === 'teacher') {
            setActiveTab('input');
          } else {
            setActiveTab('parent-feed');
            if (session.childId) setCurrentChildId(session.childId);
          }
        }
      } catch (e) {
        console.warn('Session parse error:', e);
      }
    }
  }, []);

  // Real-time synchronization across browser tabs and devices
  useEffect(() => {
    const unsub = realtimeSync.subscribe((action) => {
      if (action.type === 'STUDENT_ADDED') {
        setStudents(prev => {
          if (prev.some(s => s.id === action.payload.id)) return prev;
          return [...prev, action.payload];
        });
      } else if (action.type === 'STUDENT_UPDATED') {
        setStudents(prev => prev.map(s => (s.id === action.payload.id ? action.payload : s)));
      } else if (action.type === 'STUDENT_PHOTO_UPDATED') {
        setStudents(prev =>
          prev.map(s => (s.id === action.payload.studentId ? { ...s, avatar: action.payload.avatar } : s))
        );
      } else if (action.type === 'JOURNAL_ADDED') {
        setJournals(prev => {
          if (prev.some(j => j.id === action.payload.id)) return prev;
          return [action.payload, ...prev];
        });
      } else if (action.type === 'RATING_GIVEN') {
        setJournals(prev =>
          prev.map(j => (j.id === action.payload.journalId ? { ...j, parentRating: action.payload.rating } : j))
        );
      } else if (action.type === 'COMMENT_ADDED') {
        setJournals(prev =>
          prev.map(j =>
            j.id === action.payload.journalId
              ? { ...j, comments: [...(j.comments || []), action.payload.comment] }
              : j
          )
        );
      } else if (action.type === 'SETTINGS_UPDATED') {
        setSchoolSettings(action.payload);
      }
    });

    return () => unsub();
  }, []);

  // Automatic real-time background sync with Google Sheets (every 25 seconds when connected)
  useEffect(() => {
    if (!syncStatus.isConnected) return;
    const interval = setInterval(async () => {
      try {
        const [sheetStudents, sheetJournals] = await Promise.all([
          fetchStudentsFromSheets(),
          fetchJournalsFromSheets(),
        ]);
        if (sheetStudents && sheetStudents.length > 0) {
          setStudents(prev => {
            if (JSON.stringify(prev) !== JSON.stringify(sheetStudents)) {
              return sheetStudents;
            }
            return prev;
          });
        }
        if (sheetJournals && sheetJournals.length > 0) {
          setJournals(prev => {
            const currentIds = new Set(prev.map(j => j.id));
            const hasNew = sheetJournals.some(sj => !currentIds.has(sj.id));
            if (hasNew) {
              const merged = [...sheetJournals];
              prev.forEach(p => {
                if (!merged.some(m => m.id === p.id)) {
                  merged.push(p);
                }
              });
              return merged;
            }
            return prev;
          });
        }
      } catch (err) {
        // Silent background catch
      }
    }, 25000);

    return () => clearInterval(interval);
  }, [syncStatus.isConnected]);

  // Handle switching roles
  const handleRoleChange = (newRole: UserRole, childId?: string) => {
    setCurrentRole(newRole);
    if (newRole === 'teacher') {
      setActiveTab('input');
    } else {
      setActiveTab('parent-feed');
      if (childId) setCurrentChildId(childId);
    }
    localStorage.setItem(
      'jurnal_active_session',
      JSON.stringify({ role: newRole, childId: childId || (newRole === 'parent' ? currentChildId : null) })
    );
  };

  // Login handler from the dedicated initial LoginView
  const handleLoginSuccess = (role: UserRole, childId?: string) => {
    setCurrentRole(role);
    if (role === 'teacher') {
      setActiveTab('input');
    } else {
      setActiveTab('parent-feed');
      if (childId) setCurrentChildId(childId);
    }
    setIsAuthenticated(true);
    localStorage.setItem(
      'jurnal_active_session',
      JSON.stringify({ role, childId: childId || (role === 'parent' ? currentChildId : null) })
    );

    triggerNotification({
      title: role === 'teacher' ? 'Selamat Datang, Bapak/Ibu Guru' : 'Selamat Datang di Portal Orang Tua',
      message:
        role === 'teacher'
          ? 'Anda berhasil masuk ke panel pencatatan jurnal dan evaluasi belajar siswa.'
          : 'Anda terhubung ke portal monitoring perkembangan belajar resmi anak Anda.',
      targetRole: role,
      type: 'system',
    });
  };

  // Logout handler to return to the dedicated initial LoginView
  const handleLogout = () => {
    localStorage.removeItem('jurnal_active_session');
    setIsAuthenticated(false);
    triggerNotification({
      title: 'Sesi Berakhir',
      message: 'Anda telah keluar dari aplikasi. Silakan masuk kembali.',
      targetRole: 'all',
      type: 'system',
    });
  };

  // Connect Google Account
  const handleSignInGoogle = async () => {
    setIsGoogleLoading(true);
    try {
      const res = await signInWithGoogle();
      setGoogleUserEmail(res.user.email || undefined);
      setSyncStatus(prev => ({ ...prev, isConnected: true }));

      // Initialize spreadsheet & drive folder
      await handleInitGoogleWorkspace();

      // Show in-app notification
      triggerNotification({
        title: 'Google Workspace Terhubung',
        message: 'Google Sheets, Drive, dan Calendar siap digunakan untuk sinkronisasi otomatis.',
        targetRole: 'all',
        type: 'system',
      });
    } catch (err: any) {
      console.warn('Google sign-in skipped or cancelled:', err);
    } finally {
      setIsGoogleLoading(false);
    }
  };

  // Initialize spreadsheet and drive folder
  const handleInitGoogleWorkspace = async () => {
    try {
      setSyncStatus(prev => ({ ...prev, syncing: true }));
      const sheet = await getOrCreateSpreadsheet();
      const drive = await getOrCreateDriveFolder();

      setSyncStatus(prev => ({
        ...prev,
        isConnected: true,
        spreadsheetId: sheet.id,
        spreadsheetUrl: sheet.url,
        driveFolderId: drive.id,
        driveFolderUrl: drive.url,
        lastSynced: new Date().toLocaleTimeString('id-ID'),
        syncing: false,
      }));

      // Fetch students from the sheet
      const sheetStudents = await fetchStudentsFromSheets();
      if (sheetStudents && sheetStudents.length > 0) {
        setStudents(sheetStudents);
      }
    } catch (e: any) {
      console.error('Workspace init error:', e);
      setSyncStatus(prev => ({ ...prev, syncing: false, error: e.message }));
    }
  };

  // Trigger in-app + browser push notification
  const triggerNotification = (notifData: Omit<NotificationItem, 'id' | 'timestamp' | 'read' | 'time'>) => {
    const item = pushService.sendNotification(notifData);
    setNotifications(prev => [item, ...prev]);
  };

  // Request native push notifications
  const handleRequestPush = async () => {
    const granted = await pushService.requestPermission();
    setHasPushPermission(granted);
    if (granted) {
      triggerNotification({
        title: 'Push Notifikasi Aktif',
        message: 'Anda akan menerima pengingat agenda dan catatan aktivitas siswa tepat waktu di gawai Anda.',
        targetRole: 'all',
        type: 'system',
      });
    }
  };

  // Save new journal entry from teacher
  const handleSaveJournal = async (
    journalData: Omit<ActivityJournal, 'id' | 'timestamp'>,
    imageBlob?: Blob
  ): Promise<boolean> => {
    const journalId = `jrn-${Date.now()}`;
    let finalPhotoUrl = journalData.photoUrl;
    let driveFileId: string | undefined = undefined;

    // 1. Upload photo to Google Drive if connected and image blob exists
    if (imageBlob && syncStatus.isConnected) {
      try {
        const fileName = `Jurnal_${journalData.studentName.replace(/\s+/g, '_')}_${Date.now()}.jpg`;
        const driveResult = await uploadImageToDrive(imageBlob, fileName, journalData.title);
        driveFileId = driveResult.id;
        if (driveResult.thumbnailLink) {
          finalPhotoUrl = driveResult.thumbnailLink;
        }

        // Add to Drive gallery
        const newGalleryItem: DriveMediaItem = {
          id: driveResult.id,
          name: fileName,
          mimeType: 'image/jpeg',
          thumbnailUrl: finalPhotoUrl || '',
          date: journalData.date,
          studentName: journalData.studentName,
          category: journalData.category,
          description: journalData.title,
        };
        setGalleryItems(prev => [newGalleryItem, ...prev]);
      } catch (err) {
        console.warn('Google Drive photo upload failed, fallback to local URL:', err);
      }
    } else if (finalPhotoUrl) {
      // Add local preview to gallery
      const localGalleryItem: DriveMediaItem = {
        id: `dr-${Date.now()}`,
        name: `Foto_${journalData.title.slice(0, 15)}.jpg`,
        mimeType: 'image/jpeg',
        thumbnailUrl: finalPhotoUrl,
        date: journalData.date,
        studentName: journalData.studentName,
        category: journalData.category,
        description: journalData.title,
      };
      setGalleryItems(prev => [localGalleryItem, ...prev]);
    }

    const fullJournal: ActivityJournal = {
      ...journalData,
      id: journalId,
      timestamp: Date.now(),
      photoUrl: finalPhotoUrl,
      photoDriveId: driveFileId,
    };

    // 2. Append row to Google Sheets
    if (syncStatus.isConnected) {
      await appendJournalToSheets(fullJournal);
    }

    // 3. Save to app state & broadcast real-time
    setJournals(prev => [fullJournal, ...prev]);
    realtimeSync.broadcast({ type: 'JOURNAL_ADDED', payload: fullJournal });

    // 4. REAL-TIME PUSH NOTIFICATION TO PARENTS
    triggerNotification({
      title: `Catatan Baru: ${fullJournal.studentName}`,
      message: `${fullJournal.teacherName} mencatat: "${fullJournal.title}" (${fullJournal.milestone}).`,
      targetRole: 'parent',
      studentId: fullJournal.studentId,
      type: 'journal',
    });

    return true;
  };

  // Add new academic calendar event
  const handleAddEvent = async (
    eventData: Omit<AcademicEvent, 'id'>,
    syncGoogleCal: boolean,
    pushToParents: boolean
  ) => {
    const eventId = `evt-${Date.now()}`;
    let googleCalId: string | undefined = undefined;

    const newEvent: AcademicEvent = {
      ...eventData,
      id: eventId,
    };

    if (syncGoogleCal && syncStatus.isConnected) {
      const calId = await syncEventToGoogleCalendar(newEvent);
      if (calId) googleCalId = calId;
    }

    newEvent.googleCalendarEventId = googleCalId;
    setEvents(prev => [newEvent, ...prev]);

    if (pushToParents) {
      triggerNotification({
        title: `Agenda Baru: ${newEvent.title}`,
        message: `Dijadwalkan pada ${newEvent.date} pukul ${newEvent.startTime || '08:00'} WIB di ${newEvent.location || 'Sekolah'}.`,
        targetRole: 'all',
        type: 'agenda',
      });
    }
  };

  // Trigger agenda notification manually
  const handleTriggerAgendaNotification = (event: AcademicEvent) => {
    triggerNotification({
      title: `Pengingat Agenda: ${event.title}`,
      message: `Agenda "${event.title}" akan berlangsung pada ${event.date} (${event.startTime || '08:00'} WIB) di ${event.location || 'Sekolah'}.`,
      targetRole: 'all',
      type: 'agenda',
    });
  };

  // Trigger weekly summary notification
  const handleSendSummaryNotification = (studentName: string) => {
    triggerNotification({
      title: `Ringkasan Mingguan: ${studentName}`,
      message: `Laporan evaluasi perkembangan ${studentName} minggu ini sudah tersedia dan dapat diunduh dalam format PDF.`,
      targetRole: 'parent',
      type: 'summary',
    });
  };

  // Refresh Google Drive gallery
  const handleRefreshGallery = async () => {
    setIsRefreshingGallery(true);
    try {
      const drivePhotos = await fetchDriveGallery();
      if (drivePhotos && drivePhotos.length > 0) {
        setGalleryItems(drivePhotos);
      }
    } catch (e) {
      console.warn('Drive gallery refresh error:', e);
    } finally {
      setIsRefreshingGallery(false);
    }
  };

  // Open PDF report for a student
  const handleOpenPdfReport = (student: Student) => {
    const studentJournals = journals.filter(j => j.studentId === student.id);
    generateStudentReportPdf(student, studentJournals, 'September 2026', undefined, schoolSettings);
  };

  // Update school settings and broadcast
  const handleUpdateSettings = (newSettings: SchoolSettings) => {
    setSchoolSettings(newSettings);
    realtimeSync.broadcast({ type: 'SETTINGS_UPDATED', payload: newSettings });
  };

  // Update student and auto sync with database
  const handleUpdateStudent = async (updated: Student) => {
    let nextList: Student[] = [];
    setStudents(prev => {
      nextList = prev.map(s => (s.id === updated.id ? updated : s));
      return nextList;
    });

    realtimeSync.broadcast({ type: 'STUDENT_UPDATED', payload: updated });

    if (syncStatus.isConnected) {
      try {
        await syncStudentsToSheets(nextList);
      } catch (err) {
        console.warn('Auto sync student update failed:', err);
      }
    }

    triggerNotification({
      title: 'Data Siswa Diperbarui',
      message: `Data untuk ${updated.name} (NIS: ${updated.nis}) telah diperbarui dan tersinkron.`,
      targetRole: 'teacher',
      type: 'system',
    });
  };

  // Add new student and auto sync with database
  const handleAddStudent = async (newStudent: Student) => {
    let nextList: Student[] = [];
    setStudents(prev => {
      nextList = [...prev, newStudent];
      return nextList;
    });

    realtimeSync.broadcast({ type: 'STUDENT_ADDED', payload: newStudent });

    if (syncStatus.isConnected) {
      try {
        await syncStudentsToSheets(nextList);
      } catch (err) {
        console.warn('Auto sync new student failed:', err);
      }
    }

    triggerNotification({
      title: 'Siswa Baru Ditambahkan',
      message: `${newStudent.name} (NIS: ${newStudent.nis}) berhasil ditambahkan ke database.`,
      targetRole: 'teacher',
      type: 'system',
    });
  };

  // Manual trigger for two-way database synchronization
  const handleManualSyncDatabase = async () => {
    setIsSyncingDatabase(true);
    try {
      if (syncStatus.isConnected) {
        // 1. Sync current students to Google Sheets
        await syncStudentsToSheets(students);

        // 2. Fetch fresh students & journals from Sheets
        const [sheetStudents, sheetJournals] = await Promise.all([
          fetchStudentsFromSheets(),
          fetchJournalsFromSheets(),
        ]);

        if (sheetStudents && sheetStudents.length > 0) {
          setStudents(sheetStudents);
        }
        if (sheetJournals && sheetJournals.length > 0) {
          setJournals(prev => {
            const currentIds = new Set(prev.map(j => j.id));
            const merged = [...prev];
            sheetJournals.forEach(sj => {
              if (!currentIds.has(sj.id)) merged.push(sj);
            });
            return merged;
          });
        }
      }

      setSyncStatus(prev => ({
        ...prev,
        lastSynced: new Date().toLocaleTimeString('id-ID'),
      }));

      triggerNotification({
        title: 'Sinkronisasi Database Berhasil',
        message: 'Data siswa, foto, dan jurnal aktivitas tersinkron otomatis dan real-time.',
        targetRole: 'teacher',
        type: 'system',
      });
    } catch (e: any) {
      console.error('Manual sync failed:', e);
      triggerNotification({
        title: 'Sinkronisasi Database',
        message: 'Sinkronisasi lokal selesai. Sambungkan Google untuk sinkronisasi cloud.',
        targetRole: 'teacher',
        type: 'system',
      });
    } finally {
      setIsSyncingDatabase(false);
    }
  };

  // Parent gives star rating to activity
  const handleRateActivity = (journalId: string, rating: number) => {
    const targetJournal = journals.find(j => j.id === journalId);
    setJournals(prev => prev.map(j => (j.id === journalId ? { ...j, parentRating: rating } : j)));
    realtimeSync.broadcast({ type: 'RATING_GIVEN', payload: { journalId, rating } });

    triggerNotification({
      title: 'Apresiasi Bintang dari Orang Tua',
      message: `Orang tua memberikan apresiasi ${rating} bintang untuk aktivitas "${targetJournal?.title || 'kegiatan'}".`,
      targetRole: 'teacher',
      type: 'journal',
    });
  };

  // Parent posts comment/feedback to activity
  const handleAddComment = (journalId: string, commentText: string) => {
    const currentStudent = students.find(s => s.id === currentChildId);
    const parentDisplayName = currentStudent?.parentName || `Orang Tua ${currentStudent?.name || 'Siswa'}`;
    const newComment: JournalComment = {
      id: `cmt-${Date.now()}`,
      senderRole: 'parent',
      senderName: parentDisplayName,
      comment: commentText,
      timestamp: Date.now(),
      dateStr: new Date().toLocaleDateString('id-ID', {
        day: 'numeric',
        month: 'short',
        hour: '2-digit',
        minute: '2-digit',
      }),
    };

    setJournals(prev => prev.map(j => (j.id === journalId ? { ...j, comments: [...(j.comments || []), newComment] } : j)));
    realtimeSync.broadcast({ type: 'COMMENT_ADDED', payload: { journalId, comment: newComment } });

    triggerNotification({
      title: `Tanggapan Baru dari ${parentDisplayName}`,
      message: `"${commentText}"`,
      targetRole: 'teacher',
      type: 'journal',
    });
  };

  // 1. Initial Gate: When not authenticated, display the modern full-screen Login View
  if (!isAuthenticated) {
    return (
      <LoginView
        schoolSettings={schoolSettings}
        students={students}
        onLoginSuccess={handleLoginSuccess}
        onSignInGoogle={handleSignInGoogle}
        isGoogleLoading={isGoogleLoading}
        googleUserEmail={googleUserEmail}
        isDatabaseConnected={syncStatus.isConnected}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 flex flex-col font-sans antialiased">
      {/* Top Navbar */}
      <Navbar
        currentRole={currentRole}
        onRoleChange={handleRoleChange}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        syncStatus={syncStatus}
        onOpenGoogleModal={() => setActiveTab('settings')}
        notifications={notifications}
        onMarkNotificationRead={(id) => {
          setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
        }}
        onClearAllNotifications={() => {
          setNotifications(prev => prev.map(n => ({ ...n, read: true })));
        }}
        onRequestPushPermission={handleRequestPush}
        hasPushPermission={hasPushPermission}
        onOpenLoginModal={() => setIsLoginModalOpen(true)}
        schoolSettings={schoolSettings}
        currentChild={students.find(s => s.id === currentChildId)}
        onLogout={handleLogout}
      />

      {/* Main Content Area */}
      <main className="flex-1 pb-12">
        {/* VIEW 1: Teacher Input View */}
        {activeTab === 'input' && currentRole === 'teacher' && (
          <TeacherInputView
            students={students}
            onSaveJournal={handleSaveJournal}
            syncStatus={syncStatus}
            recentJournals={journals}
            initialStudentId={preselectedStudentId}
          />
        )}

        {/* VIEW: Students List & Photo Management (Khusus Portal Guru) */}
        {activeTab === 'students' && currentRole === 'teacher' && (
          <StudentsListView
            students={students}
            journals={journals}
            schoolSettings={schoolSettings}
            onUpdateStudent={handleUpdateStudent}
            onAddStudent={handleAddStudent}
            onOpenPdfReport={handleOpenPdfReport}
            onSelectStudentForJournal={(studentId) => {
              setPreselectedStudentId(studentId);
              setActiveTab('input');
            }}
            syncStatus={syncStatus}
            onSyncDatabase={handleManualSyncDatabase}
            isSyncing={isSyncingDatabase}
          />
        )}

        {/* VIEW 2: Parent Live Feed View */}
        {(activeTab === 'parent-feed' || (activeTab === 'input' && currentRole === 'parent')) && (
          <ParentView
            students={students}
            journals={journals}
            currentChildId={currentChildId}
            onSelectChild={setCurrentChildId}
            onOpenPdfReport={handleOpenPdfReport}
            onOpenLoginModal={() => setIsLoginModalOpen(true)}
            schoolSettings={schoolSettings}
            onRateActivity={handleRateActivity}
            onAddComment={handleAddComment}
          />
        )}

        {/* VIEW 3: Weekly Summary View */}
        {activeTab === 'summary' && (
          <WeeklySummaryView
            students={students}
            journals={journals}
            onSendSummaryNotification={handleSendSummaryNotification}
            currentRole={currentRole}
            currentChildId={currentChildId}
            schoolSettings={schoolSettings}
          />
        )}

        {/* VIEW 4: Academic Calendar View */}
        {activeTab === 'calendar' && (
          <AcademicCalendarView
            events={events}
            onAddEvent={handleAddEvent}
            onTriggerAgendaNotification={handleTriggerAgendaNotification}
            currentRole={currentRole}
            isGoogleConnected={syncStatus.isConnected}
          />
        )}

        {/* VIEW 5: Google Drive Activity Gallery */}
        {activeTab === 'gallery' && (
          <DriveGalleryView
            galleryItems={galleryItems}
            driveFolderUrl={syncStatus.driveFolderUrl}
            onRefreshGallery={handleRefreshGallery}
            isRefreshing={isRefreshingGallery}
            isGoogleConnected={syncStatus.isConnected}
            currentRole={currentRole}
            currentChildName={students.find(s => s.id === currentChildId)?.name}
          />
        )}

        {/* VIEW 6: School Settings & Google Workspace Integrations */}
        {activeTab === 'settings' && currentRole === 'teacher' && (
          <SettingsView
            settings={schoolSettings}
            onUpdateSettings={handleUpdateSettings}
            syncStatus={syncStatus}
            onConnectGoogle={handleSignInGoogle}
            onInitSpreadsheet={handleInitGoogleWorkspace}
            isGoogleLoading={isGoogleLoading}
            googleUserEmail={googleUserEmail}
            students={students}
            onUpdateStudent={handleUpdateStudent}
            onAddStudent={handleAddStudent}
            onNavigateToStudents={() => setActiveTab('students')}
          />
        )}
      </main>

      {/* Dual Login / Portal Switcher Modal */}
      <LoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        currentRole={currentRole}
        onSelectRole={handleRoleChange}
        students={students}
        onSignInGoogle={handleSignInGoogle}
        isGoogleLoading={isGoogleLoading}
        googleUserEmail={googleUserEmail}
      />

      {/* Google Workspace Connection & Status Modal */}
      <GoogleConnectModal
        isOpen={isGoogleModalOpen}
        onClose={() => setIsGoogleModalOpen(false)}
        syncStatus={syncStatus}
        onConnectGoogle={handleSignInGoogle}
        onInitSpreadsheet={handleInitGoogleWorkspace}
        isConnecting={isGoogleLoading}
        googleUserEmail={googleUserEmail}
      />
    </div>
  );
}
