import React, { useState } from 'react';
import { 
  FileSpreadsheet, 
  Folder, 
  Calendar, 
  ExternalLink, 
  CheckCircle2, 
  RefreshCw, 
  ShieldCheck, 
  Cloud,
  AlertCircle,
  Database
} from 'lucide-react';
import { WorkspaceSyncStatus } from '../services/googleWorkspace';

interface GoogleConnectModalProps {
  isOpen: boolean;
  onClose: () => void;
  syncStatus: WorkspaceSyncStatus;
  onConnectGoogle: () => Promise<void>;
  onInitSpreadsheet: () => Promise<void>;
  isConnecting: boolean;
  googleUserEmail?: string;
}

export const GoogleConnectModal: React.FC<GoogleConnectModalProps> = ({
  isOpen,
  onClose,
  syncStatus,
  onConnectGoogle,
  onInitSpreadsheet,
  isConnecting,
  googleUserEmail,
}) => {
  const [initMsg, setInitMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleInit = async () => {
    setInitMsg(null);
    try {
      await onInitSpreadsheet();
      setInitMsg('Database Google Sheet dan Folder Drive berhasil disinkronkan!');
      setTimeout(() => setInitMsg(null), 4000);
    } catch (e: any) {
      setInitMsg(`Gagal: ${e.message || 'Periksa koneksi Google'}`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-150 space-y-5">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg text-slate-900">
                Integrasi Database Google Workspace
              </h3>
              <p className="text-xs text-slate-500">
                Google Sheets, Google Drive, dan Google Calendar
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 text-sm font-bold"
          >
            ✕
          </button>
        </div>

        {initMsg && (
          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{initMsg}</span>
          </div>
        )}

        {/* Integration Status Cards */}
        <div className="space-y-3">
          {/* Card 1: Google Sheets */}
          <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 flex items-start justify-between gap-3">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 mt-0.5">
                <FileSpreadsheet className="w-4 h-4" />
              </div>
              <div className="text-xs">
                <div className="font-bold text-slate-900">Google Sheets (Database Utama)</div>
                <p className="text-slate-500 mt-0.5">
                  Menyimpan data siswa, jurnal aktivitas harian, dan capaian perkembangan secara real-time.
                </p>
                {syncStatus.spreadsheetUrl && (
                  <a
                    href={syncStatus.spreadsheetUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-emerald-700 font-semibold flex items-center gap-1 mt-1.5 hover:underline"
                  >
                    <span>Buka Spreadsheet Database</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
            </div>
            <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full shrink-0 ${syncStatus.isConnected ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'}`}>
              {syncStatus.isConnected ? 'Aktif' : 'Tersedia'}
            </span>
          </div>

          {/* Card 2: Google Drive */}
          <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 flex items-start justify-between gap-3">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center shrink-0 mt-0.5">
                <Folder className="w-4 h-4" />
              </div>
              <div className="text-xs">
                <div className="font-bold text-slate-900">Google Drive (Penyimpanan Foto)</div>
                <p className="text-slate-500 mt-0.5">
                  Menyimpan foto dokumentasi yang diunggah guru dan menampilkannya di galeri kegiatan.
                </p>
                {syncStatus.driveFolderUrl && (
                  <a
                    href={syncStatus.driveFolderUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-amber-700 font-semibold flex items-center gap-1 mt-1.5 hover:underline"
                  >
                    <span>Buka Folder Google Drive</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
            </div>
            <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full shrink-0 ${syncStatus.isConnected ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'}`}>
              {syncStatus.isConnected ? 'Aktif' : 'Tersedia'}
            </span>
          </div>

          {/* Card 3: Google Calendar */}
          <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 flex items-start justify-between gap-3">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center shrink-0 mt-0.5">
                <Calendar className="w-4 h-4" />
              </div>
              <div className="text-xs">
                <div className="font-bold text-slate-900">Google Calendar (Agenda Akademik)</div>
                <p className="text-slate-500 mt-0.5">
                  Sinkronisasi agenda sekolah, ujian, dan pertemuan wali murid ke kalender utama.
                </p>
              </div>
            </div>
            <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full shrink-0 ${syncStatus.isConnected ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'}`}>
              {syncStatus.isConnected ? 'Aktif' : 'Tersedia'}
            </span>
          </div>
        </div>

        {/* Action button */}
        <div className="pt-2 border-t border-slate-100 space-y-2">
          {!syncStatus.isConnected ? (
            <button
              onClick={onConnectGoogle}
              disabled={isConnecting}
              className="w-full py-2.5 px-4 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-xl text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xs transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${isConnecting ? 'animate-spin' : ''}`} />
              <span>{isConnecting ? 'Menghubungkan...' : 'Hubungkan Akun Google Anda Sekarang'}</span>
            </button>
          ) : (
            <button
              onClick={handleInit}
              className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xs transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Sinkronkan Ulang Database Google Sheet</span>
            </button>
          )}

          <p className="text-[11px] text-slate-400 text-center">
            {googleUserEmail ? `Masuk sebagai: ${googleUserEmail}` : 'Cukup dihubungkan satu kali saat awal pemakaian.'}
          </p>
        </div>
      </div>
    </div>
  );
};
