import React, { useState } from 'react';
import { 
  Heart, 
  Download, 
  Sparkles, 
  Clock, 
  Calendar, 
  CheckCircle2, 
  User, 
  Filter, 
  BellRing, 
  BookOpen, 
  Eye,
  Star,
  MessageCircle,
  Send,
  Lock,
  Building2,
  ShieldCheck,
  Award
} from 'lucide-react';
import { Student, ActivityJournal, ActivityCategory, MilestoneLevel, SchoolSettings } from '../types';

interface ParentViewProps {
  students: Student[];
  journals: ActivityJournal[];
  currentChildId?: string;
  onOpenPdfReport: (student: Student) => void;
  onOpenLoginModal: () => void;
  schoolSettings: SchoolSettings;
  onRateActivity: (journalId: string, rating: number) => void;
  onAddComment: (journalId: string, comment: string) => void;
}

export const ParentView: React.FC<ParentViewProps> = ({
  students,
  journals,
  currentChildId,
  onOpenPdfReport,
  onOpenLoginModal,
  schoolSettings,
  onRateActivity,
  onAddComment,
}) => {
  // Strict Isolation: Only show the currently authenticated child
  const selectedStudent = students.find(s => s.id === currentChildId);

  // Category filter
  const [selectedCategory, setSelectedCategory] = useState<string>('Semua');
  const [parentLikes, setParentLikes] = useState<Record<string, number>>({});
  const [selectedPhoto, setSelectedPhoto] = useState<string | null>(null);

  // Comment input per journal
  const [commentInputs, setCommentInputs] = useState<Record<string, string>>({});
  const [hoveredStars, setHoveredStars] = useState<Record<string, number>>({});

  // If no child has been verified yet, show security gate prompt
  if (!selectedStudent) {
    return (
      <div className="max-w-xl mx-auto px-4 py-12 text-center">
        <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-xl space-y-5">
          <div className="w-16 h-16 rounded-3xl bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto shadow-xs">
            <Lock className="w-8 h-8" />
          </div>
          <div className="space-y-2">
            <h2 className="text-xl sm:text-2xl font-black text-slate-900">
              Verifikasi Akses Portal Orang Tua
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Demi keamanan dan privasi data anak, portal orang tua hanya menampilkan data siswa yang telah diverifikasi dengan Nama Lengkap dan Nomor Induk Siswa (NIS/NISN).
            </p>
          </div>
          <button
            onClick={onOpenLoginModal}
            className="w-full py-3.5 px-6 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-2xl text-sm shadow-md transition-all flex items-center justify-center gap-2"
          >
            <ShieldCheck className="w-5 h-5" />
            <span>Masukkan Nama Lengkap & NIS Anak</span>
          </button>
        </div>
      </div>
    );
  }

  // Filter journals strictly for this child only!
  const childJournals = journals.filter(j => j.studentId === selectedStudent.id);

  const filteredJournals = selectedCategory === 'Semua' 
    ? childJournals 
    : childJournals.filter(j => j.category === selectedCategory);

  const handleLike = (journalId: string) => {
    setParentLikes(prev => ({
      ...prev,
      [journalId]: (prev[journalId] || 0) + 1
    }));
  };

  const handleCommentSubmit = (journalId: string, e: React.FormEvent) => {
    e.preventDefault();
    const commentText = commentInputs[journalId]?.trim();
    if (!commentText) return;

    onAddComment(journalId, commentText);
    setCommentInputs(prev => ({ ...prev, [journalId]: '' }));
  };

  const categories = ['Semua', 'Kognitif & Logika', 'Sosial & Emosional', 'Motorik & Seni', 'Kemandirian', 'Bahasa & Literasi'];

  const getMilestoneBadge = (level: MilestoneLevel) => {
    switch (level) {
      case 'Sangat Baik':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300';
      case 'Berkembang Sesuai Harapan':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'Mulai Terlihat':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      default:
        return 'bg-orange-100 text-orange-800 border-orange-300';
    }
  };

  const starLabels: Record<number, string> = {
    1: 'Perlu Perhatian',
    2: 'Cukup Baik',
    3: 'Baik & Berkembang',
    4: 'Sangat Baik',
    5: 'Luar Biasa & Menginspirasi! 🌟'
  };

  const { parentPortalSections } = schoolSettings;

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      {/* School Name & Branding Header (With LARGER font size as requested) */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          {schoolSettings.schoolLogo ? (
            <img
              src={schoolSettings.schoolLogo}
              alt="Logo Sekolah"
              className="w-14 h-14 rounded-2xl object-contain border border-slate-200 p-1 bg-white shadow-xs shrink-0"
            />
          ) : (
            <div className="w-12 h-12 rounded-2xl bg-blue-100 text-blue-800 flex items-center justify-center shrink-0 shadow-xs">
              <Building2 className="w-6 h-6" />
            </div>
          )}
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black uppercase tracking-wider text-blue-700 bg-blue-50 px-2 py-0.5 rounded-md border border-blue-200">
                Lembaga Pendidikan
              </span>
            </div>
            {/* BIGGER SCHOOL NAME */}
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              {schoolSettings.schoolName || 'SD & TK CENDEKIA HARAPAN'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 font-medium">
              {schoolSettings.schoolSubheader} • Tahun Ajaran {schoolSettings.academicYear}
            </p>
          </div>
        </div>

        {parentPortalSections.showWeeklyReportDownload && (
          <button
            onClick={() => onOpenPdfReport(selectedStudent)}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-2xl text-xs sm:text-sm shadow-xs transition-colors whitespace-nowrap self-start sm:self-auto"
          >
            <Download className="w-4 h-4" />
            <span>Unduh Rapor PDF Resmi</span>
          </button>
        )}
      </div>

      {/* Real-Time Sync Notification Banner */}
      <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white rounded-3xl p-4 sm:p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center backdrop-blur shrink-0">
            <BellRing className="w-5 h-5 text-white animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-sm sm:text-base">Kanal Informasi Real-Time Orang Tua</h3>
              <span className="text-[10px] uppercase font-bold bg-white text-emerald-800 px-2 py-0.5 rounded-full">
                Privasi Terlindungi
              </span>
            </div>
            <p className="text-xs text-emerald-100 mt-0.5 leading-relaxed">
              Data terisolasi khusus untuk <strong>{selectedStudent.name}</strong>. Anda dapat memberikan apresiasi bintang dan komentar kepada guru.
            </p>
          </div>
        </div>
      </div>

      {/* Child Profile Card (STRICTLY ISOLATED - NO DROPDOWN OF OTHER CHILDREN) */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="relative shrink-0">
              <img
                src={selectedStudent.avatar}
                alt={selectedStudent.name}
                className="w-18 h-18 rounded-2xl object-cover border-2 border-emerald-500 shadow-md bg-slate-50"
              />
              <span className="absolute -bottom-1 -right-1 bg-emerald-600 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full shadow-xs border border-white">
                Foto Database
              </span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-bold text-slate-900">
                  {selectedStudent.name}
                </h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                  Anak Anda
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                NIS: <strong className="text-blue-700 font-mono">{selectedStudent.nis}</strong> • {selectedStudent.className}
              </p>
              <p className="text-xs text-slate-600 mt-0.5">
                Wali Murid Terdaftar: <span className="font-semibold text-slate-800">{selectedStudent.parentName}</span>
              </p>
            </div>
          </div>

          <div className="self-start sm:self-auto flex items-center gap-2">
            <button
              onClick={onOpenLoginModal}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-colors"
              title="Ganti siswa atau verifikasi data anak lainnya"
            >
              Ganti Anak / Verifikasi Ulang
            </button>
          </div>
        </div>

        {/* Quick progress badges (Toggled by school settings) */}
        {parentPortalSections.showSummaryStats && (
          <div className="mt-5 pt-4 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className="p-3 bg-blue-50/70 rounded-2xl text-center">
              <span className="text-xs text-blue-700 font-medium block">Total Aktivitas</span>
              <span className="text-base sm:text-lg font-bold text-blue-900">{childJournals.length} Catatan</span>
            </div>
            <div className="p-3 bg-emerald-50/70 rounded-2xl text-center">
              <span className="text-xs text-emerald-700 font-medium block">Capaian Terbanyak</span>
              <span className="text-base sm:text-lg font-bold text-emerald-900">Sangat Baik</span>
            </div>
            <div className="p-3 bg-purple-50/70 rounded-2xl text-center">
              <span className="text-xs text-purple-700 font-medium block">Status Belajar</span>
              <span className="text-base sm:text-lg font-bold text-purple-900">Aktif & Ceria</span>
            </div>
            <div className="p-3 bg-amber-50/70 rounded-2xl text-center">
              <span className="text-xs text-amber-700 font-medium block">Evaluasi Mingguan</span>
              <span className="text-base sm:text-lg font-bold text-amber-900">Optimal</span>
            </div>
          </div>
        )}
      </div>

      {/* Category Filter Chips (Toggled by school settings) */}
      {parentPortalSections.showCategoryFilter && (
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          <Filter className="w-4 h-4 text-slate-400 shrink-0 ml-1 mr-1" />
          {categories.map(cat => {
            const isActive = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-colors ${
                  isActive
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>
      )}

      {/* Activity Timeline Feed */}
      <div className="space-y-5">
        {filteredJournals.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-slate-200">
            <BookOpen className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-sm font-bold text-slate-700">Belum ada catatan aktivitas untuk kategori ini.</p>
            <p className="text-xs text-slate-400 mt-1">Guru akan segera memperbarui jurnal perkembangan harian anak Anda.</p>
          </div>
        ) : (
          filteredJournals.map(journal => {
            const likesCount = parentLikes[journal.id] || 0;
            const currentRating = journal.parentRating || 0;
            const currentHover = hoveredStars[journal.id] || 0;
            const activeStarScore = currentHover || currentRating;
            const comments = journal.comments || [];

            return (
              <article
                key={journal.id}
                className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden hover:shadow-md transition-shadow"
              >
                {/* Header */}
                <div className="p-4 sm:p-5 flex items-start justify-between gap-3 border-b border-slate-100">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-bold text-slate-900">{journal.title}</span>
                      <span className="text-[11px] px-2.5 py-0.5 rounded-full font-semibold bg-blue-50 text-blue-700 border border-blue-200">
                        {journal.category}
                      </span>
                      <span className={`text-[11px] px-2.5 py-0.5 rounded-full font-semibold border ${getMilestoneBadge(journal.milestone)}`}>
                        {journal.milestone}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-slate-500">
                      <span className="flex items-center gap-1 font-medium">
                        <Calendar className="w-3.5 h-3.5" />
                        {journal.date}
                      </span>
                      <span className="flex items-center gap-1 font-medium">
                        <Clock className="w-3.5 h-3.5" />
                        {journal.time} WIB
                      </span>
                      <span>• Oleh: <strong className="text-slate-700">{journal.teacherName}</strong></span>
                    </div>
                  </div>

                  <span className="text-[10px] px-2 py-1 rounded-md bg-emerald-50 text-emerald-700 font-bold flex items-center gap-1 shrink-0">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    <span>Real-time</span>
                  </span>
                </div>

                {/* Body & Narrative */}
                <div className="p-4 sm:p-5 space-y-4">
                  <p className="text-xs sm:text-sm text-slate-700 leading-relaxed font-normal whitespace-pre-line">
                    {journal.narrative}
                  </p>

                  {/* Photo Documentation */}
                  {journal.photoUrl && (
                    <div
                      onClick={() => setSelectedPhoto(journal.photoUrl || null)}
                      className="relative rounded-2xl overflow-hidden border border-slate-200 cursor-pointer group bg-slate-900 max-h-80 flex items-center justify-center"
                    >
                      <img
                        src={journal.photoUrl}
                        alt={journal.title}
                        className="max-h-80 w-full object-cover group-hover:scale-101 transition-transform"
                      />
                      <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <span className="px-3 py-1.5 bg-black/60 text-white rounded-xl text-xs font-semibold backdrop-blur flex items-center gap-1.5">
                          <Eye className="w-4 h-4" />
                          Lihat Foto Lengkap
                        </span>
                      </div>
                      <div className="absolute bottom-2 left-2 bg-black/60 backdrop-blur text-white text-[10px] px-2 py-1 rounded-md">
                        Dokumentasi Kegiatan Siswa
                      </div>
                    </div>
                  )}

                  {/* Tags */}
                  {journal.tags && journal.tags.length > 0 && (
                    <div className="flex items-center gap-1.5 flex-wrap pt-1">
                      {journal.tags.map(t => (
                        <span key={t} className="text-[11px] text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                          #{t}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                {/* INTERACTIVE STAR RATING & COMMENTS (Toggled by school settings) */}
                {parentPortalSections.allowParentFeedback && (
                  <div className="px-4 sm:px-5 py-4 bg-amber-50/40 border-t border-amber-100 space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div>
                        <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                          <span>Beri Bintang Apresiasi untuk Aktivitas Ini:</span>
                        </span>
                        <p className="text-[11px] text-slate-500">
                          Bintang dan tanggapan Anda akan langsung terlihat oleh guru kelas.
                        </p>
                      </div>

                      {/* 5-Star Interactive Rating */}
                      <div className="flex items-center gap-1">
                        {[1, 2, 3, 4, 5].map(starNum => {
                          const isFilled = starNum <= activeStarScore;
                          return (
                            <button
                              key={starNum}
                              type="button"
                              onClick={() => onRateActivity(journal.id, starNum)}
                              onMouseEnter={() => setHoveredStars(prev => ({ ...prev, [journal.id]: starNum }))}
                              onMouseLeave={() => setHoveredStars(prev => ({ ...prev, [journal.id]: 0 }))}
                              className="p-1 hover:scale-115 transition-transform"
                              title={`${starNum} Bintang - ${starLabels[starNum]}`}
                            >
                              <Star
                                className={`w-5 h-5 sm:w-6 sm:h-6 ${
                                  isFilled
                                    ? 'text-amber-500 fill-amber-400'
                                    : 'text-slate-300'
                                }`}
                              />
                            </button>
                          );
                        })}
                        {currentRating > 0 && (
                          <span className="ml-1 text-[11px] font-bold text-amber-900 bg-amber-100 px-2 py-0.5 rounded-md">
                            {currentRating} Bintang
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Existing Comments List */}
                    {comments.length > 0 && (
                      <div className="space-y-2 pt-2 border-t border-amber-200/60">
                        <span className="text-[11px] font-bold text-slate-700 block">
                          Tanggapan & Diskusi Guru-Orang Tua:
                        </span>
                        {comments.map(c => (
                          <div
                            key={c.id}
                            className={`p-3 rounded-2xl text-xs space-y-1 ${
                              c.senderRole === 'teacher'
                                ? 'bg-amber-100/60 border border-amber-200 text-amber-950'
                                : 'bg-white border border-slate-200 text-slate-800'
                            }`}
                          >
                            <div className="flex items-center justify-between text-[11px]">
                              <strong className={c.senderRole === 'teacher' ? 'text-amber-900' : 'text-emerald-800'}>
                                {c.senderName} ({c.senderRole === 'teacher' ? 'Guru' : 'Orang Tua'})
                              </strong>
                              <span className="text-[10px] text-slate-400">{c.dateStr}</span>
                            </div>
                            <p className="leading-relaxed">{c.comment}</p>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Add Comment Input Form */}
                    <form
                      onSubmit={(e) => handleCommentSubmit(journal.id, e)}
                      className="flex items-center gap-2 pt-1"
                    >
                      <input
                        type="text"
                        value={commentInputs[journal.id] || ''}
                        onChange={e => setCommentInputs({ ...commentInputs, [journal.id]: e.target.value })}
                        placeholder="Tulis komentar atau ucapan terima kasih kepada guru..."
                        className="flex-1 px-3.5 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
                      />
                      <button
                        type="submit"
                        className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-2xs transition-colors shrink-0"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>Kirim</span>
                      </button>
                    </form>
                  </div>
                )}

                {/* Footer Quick Action */}
                <div className="px-4 py-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => handleLike(journal.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-slate-200 hover:border-rose-300 hover:text-rose-600 transition-colors"
                    >
                      <Heart className={`w-4 h-4 ${likesCount > 0 ? 'text-rose-600 fill-rose-600' : 'text-slate-400'}`} />
                      <span className="font-bold">{likesCount > 0 ? `${likesCount} Suka` : 'Suka'}</span>
                    </button>
                    <span className="text-[11px] text-slate-500 hidden sm:inline">
                      Dilihat langsung oleh orang tua
                    </span>
                  </div>

                  {parentPortalSections.showWeeklyReportDownload && (
                    <button
                      onClick={() => onOpenPdfReport(selectedStudent)}
                      className="text-xs text-emerald-700 hover:text-emerald-800 font-bold flex items-center gap-1"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Cetak Jurnal Siswa</span>
                    </button>
                  )}
                </div>
              </article>
            );
          })
        )}
      </div>

      {/* Photo Lightbox Modal */}
      {selectedPhoto && (
        <div
          onClick={() => setSelectedPhoto(null)}
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200"
        >
          <div className="relative max-w-3xl w-full" onClick={e => e.stopPropagation()}>
            <img
              src={selectedPhoto}
              alt="Foto Kegiatan"
              className="w-full max-h-[85vh] object-contain rounded-2xl shadow-2xl"
            />
            <button
              onClick={() => setSelectedPhoto(null)}
              className="absolute top-3 right-3 px-3 py-1.5 bg-black/70 hover:bg-black/90 text-white rounded-xl text-xs font-bold backdrop-blur"
            >
              ✕ Tutup
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
