import React, { useState, useRef } from 'react';
import { 
  Users, 
  Search, 
  Plus, 
  Camera, 
  Upload, 
  FileText, 
  Edit3, 
  Phone, 
  Mail, 
  CheckCircle2, 
  Download, 
  RefreshCw, 
  GraduationCap, 
  Sparkles, 
  BookOpen, 
  X,
  UserCheck,
  Building2,
  ShieldCheck,
  Image as ImageIcon
} from 'lucide-react';
import { Student, ActivityJournal, SchoolSettings } from '../types';
import { WorkspaceSyncStatus } from '../services/googleWorkspace';
import { realtimeSync } from '../services/realtimeSync';

interface StudentsListViewProps {
  students: Student[];
  journals: ActivityJournal[];
  onAddStudent: (newStudent: Student) => void;
  onUpdateStudent: (updatedStudent: Student) => void;
  onOpenPdfReport: (student: Student) => void;
  onSelectStudentForJournal: (studentId: string) => void;
  schoolSettings: SchoolSettings;
  syncStatus: WorkspaceSyncStatus;
  onManualSyncDatabase: () => Promise<void>;
  isSyncingDatabase: boolean;
}

export const StudentsListView: React.FC<StudentsListViewProps> = ({
  students,
  journals,
  onAddStudent,
  onUpdateStudent,
  onOpenPdfReport,
  onSelectStudentForJournal,
  schoolSettings,
  syncStatus,
  onManualSyncDatabase,
  isSyncingDatabase,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedClassFilter, setSelectedClassFilter] = useState('Semua');
  const [selectedGenderFilter, setSelectedGenderFilter] = useState('Semua');

  // Modal states
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);

  // New Student Form State
  const [newStudentName, setNewStudentName] = useState('');
  const [newStudentNis, setNewStudentNis] = useState('');
  const [newStudentClass, setNewStudentClass] = useState('Kelas 2-A (Cendrawasih)');
  const [newStudentGender, setNewStudentGender] = useState<'L' | 'P'>('L');
  const [newStudentParentName, setNewStudentParentName] = useState('');
  const [newStudentParentPhone, setNewStudentParentPhone] = useState('');
  const [newStudentParentEmail, setNewStudentParentEmail] = useState('');
  const [newStudentAvatar, setNewStudentAvatar] = useState('');

  // Editing Student Form State
  const [editName, setEditName] = useState('');
  const [editNis, setEditNis] = useState('');
  const [editClass, setEditClass] = useState('');
  const [editGender, setEditGender] = useState<'L' | 'P'>('L');
  const [editParentName, setEditParentName] = useState('');
  const [editParentPhone, setEditParentPhone] = useState('');
  const [editParentEmail, setEditParentEmail] = useState('');
  const [editAvatar, setEditAvatar] = useState('');

  // Notification toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [activePhotoUploadStudentId, setActivePhotoUploadStudentId] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Filter students based on search and filters
  const filteredStudents = students.filter((s) => {
    const matchesSearch = 
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.nis.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.parentName.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesClass = selectedClassFilter === 'Semua' || s.className === selectedClassFilter;
    const matchesGender = selectedGenderFilter === 'Semua' || s.gender === selectedGenderFilter;

    return matchesSearch && matchesClass && matchesGender;
  });

  const uniqueClasses = Array.from(new Set(students.map(s => s.className)));

  // Handle direct photo upload for a student card
  const handleTriggerPhotoUpload = (studentId: string) => {
    setActivePhotoUploadStudentId(studentId);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
      fileInputRef.current.click();
    }
  };

  const handleCardFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !activePhotoUploadStudentId) return;

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        const student = students.find(s => s.id === activePhotoUploadStudentId);
        if (student) {
          const updated: Student = {
            ...student,
            avatar: reader.result,
          };
          onUpdateStudent(updated);
          realtimeSync.broadcast({
            type: 'STUDENT_PHOTO_UPDATED',
            payload: { studentId: updated.id, avatar: reader.result },
          });
          showToast(`Foto siswa "${student.name}" berhasil diperbarui dan disinkronkan ke database.`);
        }
      }
    };
    reader.readAsDataURL(file);
  };

  // Add new student
  const handleCreateStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStudentName.trim() || !newStudentNis.trim()) {
      showToast('Nama dan NIS wajib diisi.');
      return;
    }

    const defaultAvatar = newStudentGender === 'L' 
      ? 'https://images.unsplash.com/photo-1544717302-de2939b7ef71?w=200&auto=format&fit=crop&q=80'
      : 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80';

    const newStudent: Student = {
      id: `std-${Date.now()}`,
      name: newStudentName.trim(),
      nis: newStudentNis.trim(),
      className: newStudentClass.trim() || 'Kelas 2-A (Cendrawasih)',
      gender: newStudentGender,
      avatar: newStudentAvatar || defaultAvatar,
      parentName: newStudentParentName.trim() || `Wali ${newStudentName.trim()}`,
      parentPhone: newStudentParentPhone.trim() || '08123456789',
      parentEmail: newStudentParentEmail.trim() || 'wali@sekolah.sch.id',
    };

    onAddStudent(newStudent);
    realtimeSync.broadcast({
      type: 'STUDENT_ADDED',
      payload: newStudent,
    });

    setIsAddModalOpen(false);
    // Reset form
    setNewStudentName('');
    setNewStudentNis('');
    setNewStudentParentName('');
    setNewStudentParentPhone('');
    setNewStudentParentEmail('');
    setNewStudentAvatar('');
    showToast(`Siswa "${newStudent.name}" berhasil ditambahkan ke database!`);
  };

  // Edit existing student
  const handleOpenEditModal = (student: Student) => {
    setEditingStudent(student);
    setEditName(student.name);
    setEditNis(student.nis);
    setEditClass(student.className);
    setEditGender(student.gender);
    setEditParentName(student.parentName);
    setEditParentPhone(student.parentPhone);
    setEditParentEmail(student.parentEmail);
    setEditAvatar(student.avatar);
  };

  const handleSaveEditStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingStudent || !editName.trim()) return;

    const updated: Student = {
      ...editingStudent,
      name: editName.trim(),
      nis: editNis.trim() || editingStudent.nis,
      className: editClass.trim() || editingStudent.className,
      gender: editGender,
      parentName: editParentName.trim() || editingStudent.parentName,
      parentPhone: editParentPhone.trim() || editingStudent.parentPhone,
      parentEmail: editParentEmail.trim() || editingStudent.parentEmail,
      avatar: editAvatar || editingStudent.avatar,
    };

    onUpdateStudent(updated);
    realtimeSync.broadcast({
      type: 'STUDENT_UPDATED',
      payload: updated,
    });

    setEditingStudent(null);
    showToast(`Data siswa "${updated.name}" berhasil diperbarui!`);
  };

  // Quick preset avatars
  const avatarPresets = [
    'https://images.unsplash.com/photo-1544717302-de2939b7ef71?w=200&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Hidden File Input for Card Avatar Upload */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleCardFileChange}
        accept="image/*"
        className="hidden"
      />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 p-4 bg-slate-900 text-white border border-slate-700 rounded-2xl shadow-2xl text-xs sm:text-sm flex items-center gap-3 animate-in fade-in slide-in-from-bottom-4 duration-200">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="font-semibold">{toastMessage}</span>
        </div>
      )}

      {/* Top Header & Database Live Status Banner */}
      <div className="bg-white rounded-3xl p-5 sm:p-7 border border-slate-200 shadow-xs flex flex-col lg:flex-row lg:items-center justify-between gap-5">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2.5 flex-wrap">
            <div className="w-10 h-10 rounded-2xl bg-blue-700 text-white flex items-center justify-center shadow-xs">
              <Users className="w-5 h-5" />
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Daftar Siswa dari Database
            </h1>
            <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse" />
              Tersinkron Database Real-time
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 max-w-2xl leading-relaxed">
            Kelola data dan foto tiap siswa yang tersimpan di database. Foto yang diunggah otomatis tampil di{' '}
            <strong className="text-slate-700">Portal Orang Tua</strong> dan dicetak pada{' '}
            <strong className="text-slate-700">Laporan Rapor PDF</strong>.
          </p>
        </div>

        {/* Database Action Buttons */}
        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={onManualSyncDatabase}
            disabled={isSyncingDatabase}
            className="flex items-center gap-2 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl text-xs sm:text-sm transition-colors border border-slate-300 disabled:opacity-50"
            title="Sinkronkan data siswa dengan Google Sheets & Database"
          >
            <RefreshCw className={`w-4 h-4 text-slate-600 ${isSyncingDatabase ? 'animate-spin' : ''}`} />
            <span>{isSyncingDatabase ? 'Menyinkronkan...' : 'Sinkron Database'}</span>
          </button>

          <button
            onClick={() => setIsAddModalOpen(true)}
            className="flex items-center gap-2 px-5 py-2.5 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-2xl text-xs sm:text-sm shadow-md transition-all hover:shadow-lg"
          >
            <Plus className="w-4 h-4" />
            <span>Tambah Siswa Baru</span>
          </button>
        </div>
      </div>

      {/* Quick Metrics Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-2xs">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Siswa</div>
          <div className="text-2xl font-black text-slate-900 mt-0.5">{students.length}</div>
          <div className="text-[11px] text-slate-500 mt-1">Terdaftar di Database</div>
        </div>
        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-2xs">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Laki-Laki</div>
          <div className="text-2xl font-black text-blue-700 mt-0.5">
            {students.filter(s => s.gender === 'L').length}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Siswa Putra</div>
        </div>
        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-2xs">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Perempuan</div>
          <div className="text-2xl font-black text-rose-600 mt-0.5">
            {students.filter(s => s.gender === 'P').length}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Siswa Putri</div>
        </div>
        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-2xs">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Aktivitas</div>
          <div className="text-2xl font-black text-emerald-700 mt-0.5">{journals.length}</div>
          <div className="text-[11px] text-slate-500 mt-1">Catatan Terdata</div>
        </div>
      </div>

      {/* Filters & Search Control */}
      <div className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200 shadow-xs flex flex-col sm:flex-row gap-3 items-center justify-between">
        {/* Search Input */}
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari nama, NIS, atau nama orang tua..."
            className="w-full pl-9.5 pr-4 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-800 focus:bg-white focus:ring-2 focus:ring-blue-600 outline-hidden font-medium"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Filter Dropdowns */}
        <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
          <select
            value={selectedClassFilter}
            onChange={(e) => setSelectedClassFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-700 focus:bg-white focus:ring-2 focus:ring-blue-600 outline-hidden"
          >
            <option value="Semua">Semua Kelas</option>
            {uniqueClasses.map((cls) => (
              <option key={cls} value={cls}>{cls}</option>
            ))}
          </select>

          <select
            value={selectedGenderFilter}
            onChange={(e) => setSelectedGenderFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-700 focus:bg-white focus:ring-2 focus:ring-blue-600 outline-hidden"
          >
            <option value="Semua">Semua Gender</option>
            <option value="L">Laki-Laki</option>
            <option value="P">Perempuan</option>
          </select>

          <div className="text-xs text-slate-400 font-semibold pl-2 whitespace-nowrap hidden md:block">
            Menampilkan <strong>{filteredStudents.length}</strong> siswa
          </div>
        </div>
      </div>

      {/* Student Cards Grid */}
      {filteredStudents.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 shadow-xs space-y-3">
          <div className="w-16 h-16 rounded-3xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
            <Users className="w-8 h-8" />
          </div>
          <h3 className="text-base font-bold text-slate-800">Tidak ada siswa yang sesuai pencarian</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Coba ganti kata kunci pencarian atau bersihkan filter kelas dan gender.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredStudents.map((student) => {
            const studentJournals = journals.filter(j => j.studentId === student.id);
            const lastJournal = studentJournals[0];

            return (
              <div
                key={student.id}
                className="bg-white rounded-3xl border border-slate-200 shadow-xs hover:shadow-md transition-all duration-200 overflow-hidden flex flex-col justify-between"
              >
                {/* Top Section with Photo & Basic Info */}
                <div className="p-5 space-y-4">
                  <div className="flex items-start gap-3.5">
                    {/* Student Photo with Camera / Upload Trigger */}
                    <div className="relative group shrink-0">
                      <img
                        src={student.avatar}
                        alt={student.name}
                        className="w-18 h-18 rounded-2xl object-cover border-2 border-slate-200 shadow-xs group-hover:opacity-90 transition-opacity bg-slate-50"
                      />
                      <button
                        onClick={() => handleTriggerPhotoUpload(student.id)}
                        className="absolute inset-0 bg-black/40 text-white rounded-2xl flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-xs cursor-pointer"
                        title="Klik untuk ganti foto siswa dari HP / PC"
                      >
                        <Camera className="w-5 h-5 text-white" />
                        <span className="text-[9px] font-bold mt-0.5">Ganti Foto</span>
                      </button>
                    </div>

                    {/* Student Identity */}
                    <div className="space-y-1 flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 border border-blue-200">
                          NIS: {student.nis}
                        </span>
                        <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md ${
                          student.gender === 'L' ? 'bg-blue-100 text-blue-800' : 'bg-rose-100 text-rose-800'
                        }`}>
                          {student.gender === 'L' ? 'Laki-Laki' : 'Perempuan'}
                        </span>
                      </div>

                      <h3 className="font-bold text-slate-900 text-base leading-snug truncate" title={student.name}>
                        {student.name}
                      </h3>

                      <p className="text-xs text-slate-500 font-medium">
                        {student.className}
                      </p>
                    </div>
                  </div>

                  {/* Parent Info & Contact */}
                  <div className="bg-slate-50/80 rounded-2xl p-3 border border-slate-100 space-y-1.5 text-xs">
                    <div className="flex items-center justify-between text-slate-600">
                      <span className="text-slate-400 font-semibold">Orang Tua/Wali:</span>
                      <strong className="text-slate-800 truncate ml-2">{student.parentName}</strong>
                    </div>
                    <div className="flex items-center justify-between text-slate-600">
                      <span className="text-slate-400 font-semibold">Telepon/WA:</span>
                      <a 
                        href={`https://wa.me/${student.parentPhone.replace(/[^0-9]/g, '')}`} 
                        target="_blank" 
                        rel="noreferrer"
                        className="text-emerald-700 font-bold hover:underline flex items-center gap-1"
                      >
                        <Phone className="w-3 h-3" />
                        <span>{student.parentPhone}</span>
                      </a>
                    </div>
                  </div>

                  {/* Activities summary badge */}
                  <div className="flex items-center justify-between pt-1 border-t border-slate-100 text-xs">
                    <span className="text-slate-500">Aktivitas Tercatat:</span>
                    <span className="font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-full border border-blue-100">
                      {studentJournals.length} Catatan
                    </span>
                  </div>
                </div>

                {/* Bottom Action Footer */}
                <div className="bg-slate-50/80 px-5 py-3 border-t border-slate-100 flex items-center justify-between gap-2">
                  <button
                    onClick={() => onSelectStudentForJournal(student.id)}
                    className="flex items-center gap-1.5 text-xs font-bold text-blue-700 hover:text-blue-800 hover:bg-blue-50 px-2.5 py-1.5 rounded-xl transition-colors"
                  >
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>Catat Jurnal</span>
                  </button>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => onOpenPdfReport(student)}
                      className="p-1.5 text-slate-600 hover:text-blue-700 hover:bg-white rounded-xl transition-colors border border-slate-200 shadow-2xs"
                      title="Cetak Laporan Rapor PDF Lengkap dengan Foto"
                    >
                      <Download className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => handleOpenEditModal(student)}
                      className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-white rounded-xl transition-colors border border-slate-200 shadow-2xs"
                      title="Edit Data Siswa"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* MODAL 1: Tambah Siswa Baru */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-150">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl border border-slate-200 my-8 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center">
                  <Plus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-slate-900">Tambah Siswa Baru</h3>
                  <p className="text-xs text-slate-500">Data otomatis tersinkron ke Google Sheets & Database</p>
                </div>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-2 text-slate-400 hover:text-slate-600 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateStudent} className="space-y-4">
              {/* Photo Upload for New Student */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Foto Siswa (Akan tampil di Portal Ortu & Rapor PDF):
                </label>
                <div className="flex items-center gap-4">
                  <img
                    src={newStudentAvatar || (newStudentGender === 'L' ? avatarPresets[0] : avatarPresets[1])}
                    alt="Preview"
                    className="w-16 h-16 rounded-2xl object-cover border-2 border-blue-500 shadow-xs shrink-0"
                  />
                  <div className="space-y-1.5 flex-1">
                    <label className="inline-flex items-center gap-2 px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold rounded-xl text-xs cursor-pointer border border-blue-200 transition-colors">
                      <Camera className="w-4 h-4" />
                      <span>Upload Foto dari HP / PC</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          const r = new FileReader();
                          r.onload = () => {
                            if (typeof r.result === 'string') setNewStudentAvatar(r.result);
                          };
                          r.readAsDataURL(file);
                        }}
                      />
                    </label>
                    <p className="text-[11px] text-slate-500">Mendukung format JPG, PNG, atau kamera langsung.</p>
                  </div>
                </div>
              </div>

              {/* Nama Lengkap & NIS */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Nama Lengkap Siswa *
                  </label>
                  <input
                    type="text"
                    required
                    value={newStudentName}
                    onChange={(e) => setNewStudentName(e.target.value)}
                    placeholder="Contoh: Muhammad Farhan"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-semibold text-slate-900 focus:bg-white focus:ring-2 focus:ring-blue-600 outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Nomor Induk (NIS / NISN) *
                  </label>
                  <input
                    type="text"
                    required
                    value={newStudentNis}
                    onChange={(e) => setNewStudentNis(e.target.value)}
                    placeholder="Contoh: 20240108"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono font-semibold text-slate-900 focus:bg-white focus:ring-2 focus:ring-blue-600 outline-hidden"
                  />
                </div>
              </div>

              {/* Kelas & Gender */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Kelas
                  </label>
                  <input
                    type="text"
                    value={newStudentClass}
                    onChange={(e) => setNewStudentClass(e.target.value)}
                    placeholder="Kelas 2-A (Cendrawasih)"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 focus:bg-white focus:ring-2 focus:ring-blue-600 outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Jenis Kelamin
                  </label>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setNewStudentGender('L')}
                      className={`flex-1 py-2.5 rounded-xl font-bold text-xs border transition-colors ${
                        newStudentGender === 'L'
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-slate-50 text-slate-600 border-slate-300'
                      }`}
                    >
                      Laki-Laki
                    </button>
                    <button
                      type="button"
                      onClick={() => setNewStudentGender('P')}
                      className={`flex-1 py-2.5 rounded-xl font-bold text-xs border transition-colors ${
                        newStudentGender === 'P'
                          ? 'bg-rose-600 text-white border-rose-600'
                          : 'bg-slate-50 text-slate-600 border-slate-300'
                      }`}
                    >
                      Perempuan
                    </button>
                  </div>
                </div>
              </div>

              {/* Data Orang Tua */}
              <div className="pt-2 border-t border-slate-100 space-y-3">
                <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  Informasi Kontak Orang Tua / Wali
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Nama Orang Tua / Wali
                  </label>
                  <input
                    type="text"
                    value={newStudentParentName}
                    onChange={(e) => setNewStudentParentName(e.target.value)}
                    placeholder="Contoh: Bapak Hendra Saputra"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 focus:bg-white focus:ring-2 focus:ring-blue-600 outline-hidden"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      No. WhatsApp / HP
                    </label>
                    <input
                      type="tel"
                      value={newStudentParentPhone}
                      onChange={(e) => setNewStudentParentPhone(e.target.value)}
                      placeholder="08123456789"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono text-slate-900 focus:bg-white focus:ring-2 focus:ring-blue-600 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Email Orang Tua
                    </label>
                    <input
                      type="email"
                      value={newStudentParentEmail}
                      onChange={(e) => setNewStudentParentEmail(e.target.value)}
                      placeholder="ortu@gmail.com"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 focus:bg-white focus:ring-2 focus:ring-blue-600 outline-hidden"
                    />
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2.5 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-xl text-xs sm:text-sm shadow-md"
                >
                  Simpan Siswa ke Database
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: Edit Siswa & Ganti Foto */}
      {editingStudent && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-150">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl border border-slate-200 my-8 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center">
                  <Edit3 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-slate-900">Ubah Data & Foto Siswa</h3>
                  <p className="text-xs text-slate-500">Perubahan akan langsung disinkronkan ke database</p>
                </div>
              </div>
              <button
                onClick={() => setEditingStudent(null)}
                className="p-2 text-slate-400 hover:text-slate-600 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEditStudent} className="space-y-4">
              {/* Photo Upload for Edit */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Foto Profil Siswa:
                </label>
                <div className="flex items-center gap-4">
                  <img
                    src={editAvatar}
                    alt="Foto Siswa"
                    className="w-16 h-16 rounded-2xl object-cover border-2 border-blue-500 shadow-xs shrink-0"
                  />
                  <div className="space-y-1.5 flex-1">
                    <label className="inline-flex items-center gap-2 px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold rounded-xl text-xs cursor-pointer border border-blue-200 transition-colors">
                      <Camera className="w-4 h-4" />
                      <span>Ganti Foto (HP / File)</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          const r = new FileReader();
                          r.onload = () => {
                            if (typeof r.result === 'string') setEditAvatar(r.result);
                          };
                          r.readAsDataURL(file);
                        }}
                      />
                    </label>
                    <p className="text-[11px] text-slate-500">Foto akan tampil di portal orang tua dan rapor PDF.</p>
                  </div>
                </div>
              </div>

              {/* Nama & NIS */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Nama Lengkap Siswa
                  </label>
                  <input
                    type="text"
                    required
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-semibold text-slate-900 focus:bg-white focus:ring-2 focus:ring-blue-600 outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    NIS / NISN
                  </label>
                  <input
                    type="text"
                    required
                    value={editNis}
                    onChange={(e) => setEditNis(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono font-semibold text-slate-900 focus:bg-white focus:ring-2 focus:ring-blue-600 outline-hidden"
                  />
                </div>
              </div>

              {/* Kelas & Gender */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Kelas
                  </label>
                  <input
                    type="text"
                    value={editClass}
                    onChange={(e) => setEditClass(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 focus:bg-white focus:ring-2 focus:ring-blue-600 outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Jenis Kelamin
                  </label>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setEditGender('L')}
                      className={`flex-1 py-2.5 rounded-xl font-bold text-xs border transition-colors ${
                        editGender === 'L'
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-slate-50 text-slate-600 border-slate-300'
                      }`}
                    >
                      Laki-Laki
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditGender('P')}
                      className={`flex-1 py-2.5 rounded-xl font-bold text-xs border transition-colors ${
                        editGender === 'P'
                          ? 'bg-rose-600 text-white border-rose-600'
                          : 'bg-slate-50 text-slate-600 border-slate-300'
                      }`}
                    >
                      Perempuan
                    </button>
                  </div>
                </div>
              </div>

              {/* Wali & Kontak */}
              <div className="pt-2 border-t border-slate-100 space-y-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Nama Orang Tua / Wali
                  </label>
                  <input
                    type="text"
                    value={editParentName}
                    onChange={(e) => setEditParentName(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 focus:bg-white focus:ring-2 focus:ring-blue-600 outline-hidden"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      No. WhatsApp / HP
                    </label>
                    <input
                      type="tel"
                      value={editParentPhone}
                      onChange={(e) => setEditParentPhone(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono text-slate-900 focus:bg-white focus:ring-2 focus:ring-blue-600 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Email
                    </label>
                    <input
                      type="email"
                      value={editParentEmail}
                      onChange={(e) => setEditParentEmail(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 focus:bg-white focus:ring-2 focus:ring-blue-600 outline-hidden"
                    />
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3">
                <button
                  type="button"
                  onClick={() => setEditingStudent(null)}
                  className="px-4 py-2.5 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-xl text-xs sm:text-sm shadow-md"
                >
                  Simpan Perubahan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
