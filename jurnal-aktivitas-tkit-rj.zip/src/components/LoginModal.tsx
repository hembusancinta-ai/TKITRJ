import React, { useState } from 'react';
import { 
  GraduationCap, 
  Users, 
  Check, 
  BookOpen, 
  ChevronRight,
  Search,
  AlertCircle,
  KeyRound,
  Sparkles,
  UserCheck
} from 'lucide-react';
import { UserRole, Student } from '../types';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentRole: UserRole;
  onSelectRole: (role: UserRole, childId?: string) => void;
  students: Student[];
}

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  onClose,
  currentRole,
  onSelectRole,
  students,
}) => {
  const [activePortal, setActivePortal] = useState<'teacher' | 'parent'>(currentRole);
  
  // Parent authentication form state
  const [inputStudentName, setInputStudentName] = useState('');
  const [inputNis, setInputNis] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleParentLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);

    const trimmedName = inputStudentName.trim().toLowerCase();
    const trimmedNis = inputNis.trim();

    if (!trimmedName || !trimmedNis) {
      setAuthError('Silakan masukkan nama lengkap anak dan nomor NIS/NISN.');
      return;
    }

    // Match student where name matches (case-insensitive) and NIS matches
    const matched = students.find(s => 
      s.name.toLowerCase().trim() === trimmedName && s.nis.trim() === trimmedNis
    );

    if (!matched) {
      // Also try partial match on name if exact NIS matches to be user friendly
      const nisMatched = students.find(s => s.nis.trim() === trimmedNis);
      if (nisMatched) {
        setAuthError(`NIS ${trimmedNis} ditemukan atas nama "${nisMatched.name}". Mohon ketikkan nama lengkap yang sama.`);
      } else {
        setAuthError('Data siswa tidak ditemukan. Pastikan nama lengkap dan NIS/NISN sudah sesuai dengan data resmi sekolah.');
      }
      return;
    }

    // Success login to parent portal with this child ID
    onSelectRole('parent', matched.id);
    onClose();
  };

  const handleTeacherLogin = () => {
    onSelectRole('teacher');
    onClose();
  };

  // Quick fill helper for convenience
  const handleQuickFill = (s: Student) => {
    setInputStudentName(s.name);
    setInputNis(s.nis);
    setAuthError(null);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-150">
        <div className="text-center space-y-1.5 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-blue-700 text-white flex items-center justify-center mx-auto shadow-md">
            <BookOpen className="w-6 h-6" />
          </div>
          <h2 className="text-xl font-bold text-slate-900">Pilih Portal Akses Aplikasi</h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Akses khusus pendidik sekolah dan portal pribadi orang tua siswa
          </p>
        </div>

        {/* 2 Portal Choice Tabs */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          {/* Portal 1: Guru */}
          <div
            onClick={() => {
              setActivePortal('teacher');
              setAuthError(null);
            }}
            className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
              activePortal === 'teacher'
                ? 'border-amber-500 bg-amber-50/50 shadow-xs'
                : 'border-slate-200 hover:border-slate-300 bg-slate-50/40'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center">
                <GraduationCap className="w-5 h-5" />
              </div>
              {activePortal === 'teacher' && (
                <span className="w-5 h-5 rounded-full bg-amber-600 text-white flex items-center justify-center text-xs">
                  <Check className="w-3 h-3" />
                </span>
              )}
            </div>
            <h3 className="font-bold text-sm text-slate-900">Portal Guru</h3>
            <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
              Input data siswa, dikte suara, kelola Google Workspace, dan pengaturan sekolah.
            </p>
          </div>

          {/* Portal 2: Orang Tua */}
          <div
            onClick={() => {
              setActivePortal('parent');
              setAuthError(null);
            }}
            className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
              activePortal === 'parent'
                ? 'border-emerald-500 bg-emerald-50/50 shadow-xs'
                : 'border-slate-200 hover:border-slate-300 bg-slate-50/40'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                <Users className="w-5 h-5" />
              </div>
              {activePortal === 'parent' && (
                <span className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs">
                  <Check className="w-3 h-3" />
                </span>
              )}
            </div>
            <h3 className="font-bold text-sm text-slate-900">Portal Orang Tua</h3>
            <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
              Verifikasi nama dan NIS anak untuk melihat catatan belajar pribadi tanpa data anak lain.
            </p>
          </div>
        </div>

        {/* Form if Portal Orang Tua is selected */}
        {activePortal === 'parent' ? (
          <form onSubmit={handleParentLogin} className="space-y-4 mb-5">
            <div className="p-4 bg-emerald-50/70 rounded-2xl border border-emerald-200 space-y-3">
              <div className="flex items-center gap-2 text-emerald-900 text-xs font-bold">
                <KeyRound className="w-4 h-4 text-emerald-700" />
                <span>Verifikasi Identitas Siswa (Anak Anda)</span>
              </div>
              <p className="text-[11px] text-slate-600">
                Untuk menjaga privasi, portal hanya akan menampilkan data anak yang sesuai dengan Nama Lengkap dan NIS/NISN yang dimasukkan.
              </p>

              {authError && (
                <div className="p-2.5 bg-rose-100 border border-rose-300 rounded-xl text-xs text-rose-800 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span>{authError}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nama Lengkap Anak:
                </label>
                <input
                  type="text"
                  required
                  value={inputStudentName}
                  onChange={e => setInputStudentName(e.target.value)}
                  placeholder="Contoh: Ahmad Fauzan Al-Ghifari"
                  className="w-full px-3 py-2 bg-white border border-emerald-300 rounded-xl text-xs sm:text-sm font-semibold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nomor Induk Siswa (NIS / NISN):
                </label>
                <input
                  type="text"
                  required
                  value={inputNis}
                  onChange={e => setInputNis(e.target.value)}
                  placeholder="Contoh: 20240101"
                  className="w-full px-3 py-2 bg-white border border-emerald-300 rounded-xl text-xs sm:text-sm font-mono font-bold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-400"
                />
              </div>

              {/* Quick sample chips */}
              <div className="pt-2 border-t border-emerald-200/60">
                <span className="text-[10px] text-emerald-800 font-semibold block mb-1">
                  Pilih Cepat untuk Simulasi Data:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {students.slice(0, 3).map(s => (
                    <button
                      type="button"
                      key={s.id}
                      onClick={() => handleQuickFill(s)}
                      className="px-2 py-1 bg-white hover:bg-emerald-100 border border-emerald-200 text-emerald-900 rounded-lg text-[10px] font-medium transition-colors"
                    >
                      {s.name} ({s.nis})
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs sm:text-sm transition-colors"
              >
                Batal
              </button>
              <button
                type="submit"
                className="flex-2 py-2.5 px-4 font-bold rounded-xl text-xs sm:text-sm text-white bg-emerald-600 hover:bg-emerald-700 flex items-center justify-center gap-2 shadow-md transition-all"
              >
                <UserCheck className="w-4 h-4" />
                <span>Verifikasi & Masuk Portal</span>
              </button>
            </div>
          </form>
        ) : (
          <div className="space-y-4 mb-5">
            <div className="p-4 bg-amber-50/60 rounded-2xl border border-amber-200 text-xs text-slate-700 space-y-1">
              <div className="font-bold text-amber-900">Hak Akses Guru & Admin</div>
              <p>
                Anda akan masuk sebagai guru pengampu untuk mencatat aktivitas harian, mengatur nama sekolah, serta menyambungkan ke Google Workspace.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs sm:text-sm transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleTeacherLogin}
                className="flex-2 py-2.5 px-4 font-bold rounded-xl text-xs sm:text-sm text-white bg-amber-600 hover:bg-amber-700 flex items-center justify-center gap-2 shadow-md transition-all"
              >
                <span>Masuk ke Portal Guru</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
