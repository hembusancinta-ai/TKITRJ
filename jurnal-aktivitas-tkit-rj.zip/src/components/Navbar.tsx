import React, { useState } from 'react';
import { 
  BookOpen, 
  GraduationCap, 
  Users, 
  Calendar, 
  Image as ImageIcon, 
  FileText, 
  Bell, 
  CheckCircle2, 
  ChevronDown,
  Settings,
  ShieldCheck,
  LogOut,
  Sparkles
} from 'lucide-react';
import { UserRole, NotificationItem, SchoolSettings, Student } from '../types';

interface NavbarProps {
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  activeTab: string;
  onTabChange: (tab: string) => void;
  schoolSettings: SchoolSettings;
  notifications: NotificationItem[];
  onMarkNotificationRead: (id: string) => void;
  onClearAllNotifications: () => void;
  onRequestPushPermission: () => void;
  hasPushPermission: boolean;
  onOpenLoginModal: () => void;
  currentChild?: Student;
  onLogout?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentRole,
  onRoleChange,
  activeTab,
  onTabChange,
  schoolSettings,
  notifications,
  onMarkNotificationRead,
  onClearAllNotifications,
  onRequestPushPermission,
  hasPushPermission,
  onOpenLoginModal,
  currentChild,
  onLogout,
}) => {
  const [showNotifMenu, setShowNotifMenu] = useState(false);
  const unreadCount = notifications.filter(n => !n.read).length;

  const teacherNavItems = [
    { id: 'input', label: 'Input Jurnal', icon: BookOpen },
    { id: 'students', label: 'Daftar Siswa', icon: Users },
    { id: 'calendar', label: 'Agenda Akademik', icon: Calendar },
    { id: 'gallery', label: 'Galeri Drive', icon: ImageIcon },
    { id: 'summary', label: 'Ringkasan Mingguan', icon: FileText },
    { id: 'settings', label: 'Pengaturan', icon: Settings },
  ];

  // Dynamic parent nav items based on school settings
  const parentNavItems = [
    { id: 'parent-feed', label: 'Jurnal Anak', icon: BookOpen },
    ...(schoolSettings.parentPortalSections.showAcademicCalendar 
      ? [{ id: 'calendar', label: 'Agenda Sekolah', icon: Calendar }] 
      : []),
    ...(schoolSettings.parentPortalSections.showDriveGallery 
      ? [{ id: 'gallery', label: 'Galeri Kegiatan', icon: ImageIcon }] 
      : []),
    ...(schoolSettings.parentPortalSections.showWeeklySummaryTab 
      ? [{ id: 'summary', label: 'Rapor Mingguan', icon: FileText }] 
      : []),
  ];

  const currentNavItems = currentRole === 'teacher' ? teacherNavItems : parentNavItems;

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-20">
          {/* Logo & Big School Brand */}
          <div className="flex items-center gap-3.5">
            {schoolSettings.schoolLogo ? (
              <img
                src={schoolSettings.schoolLogo}
                alt="Logo Sekolah"
                className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl object-contain bg-white border border-slate-200 p-1 shadow-md shrink-0"
              />
            ) : (
              <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-blue-800 text-white flex items-center justify-center shadow-md shrink-0">
                <BookOpen className="w-6 h-6 sm:w-7 sm:h-7" />
              </div>
            )}
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                {/* LARGER FONT SIZE FOR SCHOOL NAME */}
                <h1 className="font-black text-slate-900 tracking-tight text-lg sm:text-2xl leading-none">
                  {schoolSettings.schoolName || 'SD & TK CENDEKIA HARAPAN'}
                </h1>
                <span className={`text-[10px] sm:text-xs font-bold px-2.5 py-0.5 rounded-full ${
                  currentRole === 'teacher' 
                    ? 'bg-amber-100 text-amber-900 border border-amber-300' 
                    : 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                }`}>
                  {currentRole === 'teacher' ? 'Portal Guru' : 'Portal Orang Tua'}
                </span>
              </div>
              <div className="flex items-center gap-2 mt-1">
                <p className="text-xs sm:text-sm font-semibold text-slate-500">
                  {currentRole === 'parent' && currentChild 
                    ? `Siswa: ${currentChild.name} (NIS: ${currentChild.nis})` 
                    : (schoolSettings.schoolSubheader || 'Jurnal Catatan Aktivitas Siswa Terpadu')}
                </p>
              </div>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1.5">
            {currentNavItems.map(item => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onTabChange(item.id)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-colors ${
                    isActive
                      ? 'bg-blue-50 text-blue-700 border border-blue-200 shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Right Action Tools */}
          <div className="flex items-center gap-2.5">
            {/* Live Real-Time Database Indicator */}
            <div 
              className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-[11px] font-bold shadow-2xs"
              title="Aplikasi tersinkron otomatis dan real-time dengan database"
            >
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>Real-Time DB</span>
            </div>

            {/* Notification Bell & Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowNotifMenu(!showNotifMenu)}
                className="relative p-2.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors border border-slate-200"
                title="Notifikasi Real-time"
              >
                <Bell className="w-5 h-5" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-rose-600 text-white text-[10px] font-black rounded-full flex items-center justify-center animate-bounce shadow-xs">
                    {unreadCount}
                  </span>
                )}
              </button>

              {/* Notifications Popover */}
              {showNotifMenu && (
                <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-2xl border border-slate-200 py-3 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                  <div className="flex items-center justify-between px-4 pb-2 border-b border-slate-100">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 text-sm">Notifikasi Real-Time</span>
                      {unreadCount > 0 && (
                        <span className="text-xs bg-rose-100 text-rose-700 px-2 py-0.5 rounded-full font-bold">
                          {unreadCount} baru
                        </span>
                      )}
                    </div>
                    {notifications.length > 0 && (
                      <button
                        onClick={onClearAllNotifications}
                        className="text-xs text-blue-600 hover:underline font-semibold"
                      >
                        Tandai semua dibaca
                      </button>
                    )}
                  </div>

                  {/* Push notification banner */}
                  {!hasPushPermission && (
                    <div className="mx-3 my-2 p-2.5 bg-amber-50 rounded-xl border border-amber-200 flex items-center justify-between gap-2">
                      <div className="text-xs text-amber-900">
                        <strong>Aktifkan Push Notifikasi</strong> agar dapat notifikasi langsung di gawai.
                      </div>
                      <button
                        onClick={onRequestPushPermission}
                        className="text-xs font-bold px-2.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg whitespace-nowrap shadow-2xs"
                      >
                        Izinkan
                      </button>
                    </div>
                  )}

                  <div className="max-h-72 overflow-y-auto divide-y divide-slate-100">
                    {notifications.length === 0 ? (
                      <div className="py-8 text-center text-slate-400 text-xs">
                        Tidak ada notifikasi saat ini
                      </div>
                    ) : (
                      notifications.map(n => (
                        <div
                          key={n.id}
                          onClick={() => onMarkNotificationRead(n.id)}
                          className={`px-4 py-3 cursor-pointer hover:bg-slate-50 transition-colors ${
                            !n.read ? 'bg-blue-50/60' : ''
                          }`}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <h4 className="text-xs font-bold text-slate-900">{n.title}</h4>
                            <span className="text-[10px] text-slate-400 whitespace-nowrap">{n.time}</span>
                          </div>
                          <p className="text-xs text-slate-600 mt-1 leading-relaxed">{n.message}</p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Role Switcher / Portal Switcher */}
            <button
              onClick={onOpenLoginModal}
              className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold border transition-colors shadow-2xs ${
                currentRole === 'teacher'
                  ? 'bg-amber-50 hover:bg-amber-100 text-amber-900 border-amber-300'
                  : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border-emerald-300'
              }`}
              title="Ganti Portal atau Masuk Ulang"
            >
              {currentRole === 'teacher' ? (
                <>
                  <GraduationCap className="w-4 h-4 text-amber-700" />
                  <span className="hidden sm:inline">Portal Guru</span>
                </>
              ) : (
                <>
                  <Users className="w-4 h-4 text-emerald-700" />
                  <span className="hidden sm:inline">
                    {currentChild ? currentChild.name.split(' ')[0] : 'Portal Orang Tua'}
                  </span>
                </>
              )}
              <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
            </button>

            {/* Dedicated Logout / Keluar Button to Return to Login Page */}
            {onLogout && (
              <button
                onClick={onLogout}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold text-slate-600 hover:text-rose-700 bg-slate-100 hover:bg-rose-50 border border-slate-200 hover:border-rose-200 transition-colors shadow-2xs"
                title="Keluar ke Halaman Login"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">Keluar</span>
              </button>
            )}
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="lg:hidden flex items-center justify-around py-2 border-t border-slate-100 overflow-x-auto">
          {currentNavItems.map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={`flex flex-col items-center gap-1 py-1.5 px-3 rounded-lg text-xs font-semibold whitespace-nowrap ${
                  isActive ? 'text-blue-700 font-bold' : 'text-slate-500'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
