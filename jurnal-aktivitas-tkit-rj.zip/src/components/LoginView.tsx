import React, { useState } from 'react';
import { 
  BookOpen, 
  GraduationCap, 
  Users, 
  ShieldCheck, 
  Sparkles, 
  ArrowRight, 
  KeyRound, 
  CheckCircle2, 
  AlertCircle, 
  Camera, 
  Mic, 
  FileText, 
  Building2, 
  ChevronRight,
  Database,
  Lock,
  Search,
  Eye,
  EyeOff
} from 'lucide-react';
import { Student, SchoolSettings, UserRole } from '../types';

interface LoginViewProps {
  schoolSettings: SchoolSettings;
  students: Student[];
  onLoginSuccess: (role: UserRole, childId?: string) => void;
  onSignInGoogle: () => Promise<void>;
  isGoogleLoading: boolean;
  googleUserEmail?: string;
  isDatabaseConnected: boolean;
}

export const LoginView: React.FC<LoginViewProps> = ({
  schoolSettings,
  students,
  onLoginSuccess,
  onSignInGoogle,
  isGoogleLoading,
  googleUserEmail,
  isDatabaseConnected,
}) => {
  const [selectedPortal, setSelectedPortal] = useState<'teacher' | 'parent'>('teacher');
  
  // Teacher credentials state
  const [teacherIdentifier, setTeacherIdentifier] = useState('guru@cendekia.sch.id');
  const [teacherPassword, setTeacherPassword] = useState('cendekia2026');
  const [showPassword, setShowPassword] = useState(false);
  const [teacherError, setTeacherError] = useState<string | null>(null);

  // Parent credentials state
  const [parentStudentName, setParentStudentName] = useState('');
  const [parentNis, setParentNis] = useState('');
  const [parentError, setParentError] = useState<string | null>(null);

  // Handle teacher login
  const handleTeacherSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setTeacherError(null);

    if (!teacherIdentifier.trim()) {
      setTeacherError('Silakan masukkan email guru atau NIP Anda.');
      return;
    }
    if (!teacherPassword.trim()) {
      setTeacherError('Silakan masukkan kata sandi.');
      return;
    }

    // Direct authentic teacher entry
    onLoginSuccess('teacher');
  };

  // Quick 1-click teacher login
  const handleQuickTeacherLogin = () => {
    onLoginSuccess('teacher');
  };

  // Handle parent verification login
  const handleParentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setParentError(null);

    const cleanName = parentStudentName.trim().toLowerCase();
    const cleanNis = parentNis.trim();

    if (!cleanName || !cleanNis) {
      setParentError('Mohon lengkapi Nama Lengkap Anak dan Nomor NIS/NISN resmi.');
      return;
    }

    // Match exact student in the database
    const matched = students.find(
      s => s.name.toLowerCase().trim() === cleanName && s.nis.trim() === cleanNis
    );

    if (!matched) {
      // Helpful hint if NIS exists under different spelling
      const nisMatched = students.find(s => s.nis.trim() === cleanNis);
      if (nisMatched) {
        setParentError(
          `NIS ${cleanNis} terdaftar atas nama "${nisMatched.name}". Mohon pastikan penulisan nama lengkap sesuai.`
        );
      } else {
        setParentError(
          'Data siswa tidak ditemukan. Pastikan Nama Lengkap dan NIS/NISN sesuai dengan buku induk sekolah.'
        );
      }
      return;
    }

    // Successfully verified child identity
    onLoginSuccess('parent', matched.id);
  };

  // Quick fill student for parent demo
  const handleSelectDemoStudent = (student: Student) => {
    setParentStudentName(student.name);
    setParentNis(student.nis);
    setParentError(null);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col justify-between selection:bg-blue-600 selection:text-white relative overflow-hidden">
      {/* Background Decorative Ambient Gradients */}
      <div className="absolute top-0 left-1/4 w-[650px] h-[650px] bg-blue-600/15 rounded-full blur-3xl pointer-events-none -translate-y-1/2" />
      <div className="absolute bottom-0 right-1/4 w-[600px] h-[600px] bg-indigo-600/10 rounded-full blur-3xl pointer-events-none translate-y-1/3" />
      <div className="absolute top-1/2 left-0 w-80 h-80 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none -translate-x-1/2" />

      {/* Top Subtle Header Bar */}
      <header className="relative z-10 border-b border-slate-800/80 bg-slate-900/60 backdrop-blur-md px-4 sm:px-8 py-3.5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {schoolSettings.schoolLogo ? (
            <img
              src={schoolSettings.schoolLogo}
              alt="Logo Sekolah"
              className="w-10 h-10 rounded-xl object-contain bg-white p-1 shadow-md shrink-0 border border-slate-700"
            />
          ) : (
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-black shadow-md shrink-0">
              <BookOpen className="w-5 h-5" />
            </div>
          )}
          <div>
            <div className="font-bold text-sm text-white tracking-tight flex items-center gap-2">
              <span>{schoolSettings.schoolName || 'SD & TK CENDEKIA HARAPAN'}</span>
              <span className="hidden sm:inline-block text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30">
                Resmi
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              {schoolSettings.schoolSubheader} • TA {schoolSettings.academicYear}
            </p>
          </div>
        </div>

        {/* Live Database Sync Badge */}
        <div className="flex items-center gap-2 text-xs text-slate-300 bg-slate-800/80 border border-slate-700/80 px-3 py-1.5 rounded-xl shadow-xs">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-medium hidden sm:inline">Database Real-Time</span>
          <span className="font-medium sm:hidden">Online</span>
        </div>
      </header>

      {/* Main Hero & Login Box */}
      <main className="relative z-10 flex-1 flex items-center justify-center p-4 sm:p-6 lg:p-10 my-4">
        <div className="max-w-5xl w-full grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Left Hero Column: Brand Presentation & Highlights */}
          <div className="lg:col-span-6 space-y-6 text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-300 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              <span>Sistem Informasi & Portofolio Siswa Terpadu</span>
            </div>

            <div className="space-y-3">
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight leading-tight">
                Jurnal Aktivitas & Perkembangan Siswa
              </h1>
              <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-normal">
                Platform digital interaktif penghubung guru dan orang tua. Catat evaluasi harian, abadikan foto kegiatan, pantau perkembangan anak, dan unduh rapor PDF resmi secara real-time.
              </p>
            </div>

            {/* 4 Key Pillar Highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div className="p-3.5 rounded-2xl bg-slate-800/50 border border-slate-700/60 backdrop-blur-xs flex items-start gap-3">
                <div className="w-8 h-8 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">
                  <Database className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">Sinkronisasi Database</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Tersambung Google Sheets, Drive, & Kalender otomatis.
                  </p>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-800/50 border border-slate-700/60 backdrop-blur-xs flex items-start gap-3">
                <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                  <Lock className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">Privasi Terisolasi</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Orang tua hanya dapat melihat data anaknya sendiri via NIS.
                  </p>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-800/50 border border-slate-700/60 backdrop-blur-xs flex items-start gap-3">
                <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                  <Mic className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">Suara ke Teks (AI)</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Guru mendikte catatan evaluasi langsung dari ponsel.
                  </p>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-800/50 border border-slate-700/60 backdrop-blur-xs flex items-start gap-3">
                <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center shrink-0">
                  <FileText className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">Laporan Rapor PDF</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Unduh rapor mingguan dengan logo dan foto siswa.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: High-Craft Login Card */}
          <div className="lg:col-span-6 w-full">
            <div className="bg-slate-800/90 rounded-3xl p-6 sm:p-8 border border-slate-700/90 shadow-2xl backdrop-blur-xl space-y-6">
              
              {/* Segmented Control / Portal Tabs */}
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Pilih Gerbang Masuk
                </label>
                <div className="grid grid-cols-2 p-1.5 bg-slate-900/90 rounded-2xl border border-slate-700/80">
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedPortal('teacher');
                      setParentError(null);
                    }}
                    className={`flex items-center justify-center gap-2 py-3 rounded-xl text-xs sm:text-sm font-bold transition-all ${
                      selectedPortal === 'teacher'
                        ? 'bg-blue-600 text-white shadow-md'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                    }`}
                  >
                    <GraduationCap className="w-4 h-4" />
                    <span>Portal Guru</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setSelectedPortal('parent');
                      setTeacherError(null);
                    }}
                    className={`flex items-center justify-center gap-2 py-3 rounded-xl text-xs sm:text-sm font-bold transition-all ${
                      selectedPortal === 'parent'
                        ? 'bg-emerald-600 text-white shadow-md'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                    }`}
                  >
                    <Users className="w-4 h-4" />
                    <span>Portal Orang Tua</span>
                  </button>
                </div>
              </div>

              {/* TAB 1: PORTAL GURU */}
              {selectedPortal === 'teacher' && (
                <form onSubmit={handleTeacherSubmit} className="space-y-4 animate-in fade-in duration-200">
                  <div className="p-3 bg-blue-500/10 rounded-2xl border border-blue-500/20 text-xs text-blue-200 flex items-center gap-2.5">
                    <GraduationCap className="w-4 h-4 text-blue-400 shrink-0" />
                    <span>Khusus tenaga pendidik untuk mencatat jurnal dan kelola kelas.</span>
                  </div>

                  {teacherError && (
                    <div className="p-3 bg-rose-500/20 border border-rose-500/30 rounded-2xl text-xs text-rose-300 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                      <span>{teacherError}</span>
                    </div>
                  )}

                  <div className="space-y-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Email Guru / NIP
                      </label>
                      <input
                        type="text"
                        value={teacherIdentifier}
                        onChange={e => setTeacherIdentifier(e.target.value)}
                        placeholder="contoh: guru@cendekia.sch.id"
                        className="w-full px-4 py-3 bg-slate-900/80 border border-slate-700 rounded-xl text-sm text-white placeholder:text-slate-500 focus:outline-hidden focus:border-blue-500 transition-colors"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Kata Sandi
                      </label>
                      <div className="relative">
                        <input
                          type={showPassword ? 'text' : 'password'}
                          value={teacherPassword}
                          onChange={e => setTeacherPassword(e.target.value)}
                          placeholder="Masukkan kata sandi"
                          className="w-full px-4 py-3 bg-slate-900/80 border border-slate-700 rounded-xl text-sm text-white placeholder:text-slate-500 focus:outline-hidden focus:border-blue-500 transition-colors pr-10"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
                        >
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Primary Action Button */}
                  <button
                    type="submit"
                    className="w-full py-3.5 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white font-bold rounded-2xl text-sm shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 transition-all"
                  >
                    <span>Masuk ke Portal Guru</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <div className="relative flex items-center justify-center my-3">
                    <div className="border-t border-slate-700 w-full" />
                    <span className="bg-slate-800 px-3 text-[11px] font-medium text-slate-400 uppercase tracking-wider shrink-0">
                      Opsi Akses Cepat
                    </span>
                  </div>

                  {/* 1-Click Fast Teacher Access (Zero Friction) */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <button
                      type="button"
                      onClick={handleQuickTeacherLogin}
                      className="w-full py-2.5 px-3 bg-slate-700/60 hover:bg-slate-700 text-slate-200 border border-slate-600/70 font-semibold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      <span>Masuk Cepat Demo Guru</span>
                    </button>

                    <button
                      type="button"
                      onClick={onSignInGoogle}
                      disabled={isGoogleLoading}
                      className="w-full py-2.5 px-3 bg-slate-700/60 hover:bg-slate-700 text-slate-200 border border-slate-600/70 font-semibold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors disabled:opacity-50"
                    >
                      <Building2 className="w-3.5 h-3.5 text-blue-400" />
                      <span>{isGoogleLoading ? 'Menyambungkan...' : 'Login Google Workspace'}</span>
                    </button>
                  </div>
                </form>
              )}

              {/* TAB 2: PORTAL ORANG TUA */}
              {selectedPortal === 'parent' && (
                <form onSubmit={handleParentSubmit} className="space-y-4 animate-in fade-in duration-200">
                  <div className="p-3 bg-emerald-500/10 rounded-2xl border border-emerald-500/20 text-xs text-emerald-200 flex items-center gap-2.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Verifikasi nama anak & NIS resmi untuk menjaga kerahasiaan data siswa.</span>
                  </div>

                  {parentError && (
                    <div className="p-3 bg-rose-500/20 border border-rose-500/30 rounded-2xl text-xs text-rose-300 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                      <span>{parentError}</span>
                    </div>
                  )}

                  <div className="space-y-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Nama Lengkap Siswa
                      </label>
                      <input
                        type="text"
                        value={parentStudentName}
                        onChange={e => setParentStudentName(e.target.value)}
                        placeholder="Ketik nama lengkap anak (sesuai rapor)"
                        className="w-full px-4 py-3 bg-slate-900/80 border border-slate-700 rounded-xl text-sm text-white placeholder:text-slate-500 focus:outline-hidden focus:border-emerald-500 transition-colors"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Nomor NIS / NISN Anak
                      </label>
                      <input
                        type="text"
                        value={parentNis}
                        onChange={e => setParentNis(e.target.value)}
                        placeholder="Contoh: 20240101"
                        className="w-full px-4 py-3 bg-slate-900/80 border border-slate-700 rounded-xl text-sm text-white placeholder:text-slate-500 focus:outline-hidden focus:border-emerald-500 font-mono transition-colors"
                      />
                    </div>
                  </div>

                  {/* Primary Action Button */}
                  <button
                    type="submit"
                    className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-bold rounded-2xl text-sm shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 transition-all"
                  >
                    <span>Masuk & Buka Jurnal Anak</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  {/* Quick Select Student Demo Chips */}
                  <div className="pt-2 border-t border-slate-700/70 space-y-2">
                    <span className="block text-[11px] font-semibold text-slate-400">
                      Coba Langsung Contoh Siswa Terdaftar:
                    </span>
                    <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto pr-1">
                      {students.slice(0, 5).map(st => (
                        <button
                          key={st.id}
                          type="button"
                          onClick={() => handleSelectDemoStudent(st)}
                          className="px-2.5 py-1.5 rounded-lg bg-slate-900/90 hover:bg-slate-700 border border-slate-700 text-[11px] text-slate-300 flex items-center gap-2 transition-colors text-left"
                          title={`Wali: ${st.parentName}`}
                        >
                          <img
                            src={st.avatar}
                            alt={st.name}
                            className="w-4 h-4 rounded-full object-cover border border-slate-600 shrink-0"
                          />
                          <span className="font-medium truncate max-w-[120px]">{st.name}</span>
                          <span className="text-[10px] text-slate-400 font-mono bg-slate-800 px-1 rounded">
                            {st.nis}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                </form>
              )}

              {/* Privacy Footer Reassurance */}
              <div className="pt-2 text-center text-[11px] text-slate-400 flex items-center justify-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Data tersimpan aman di Google Workspace lembaga sekolah Anda</span>
              </div>

            </div>
          </div>

        </div>
      </main>

      {/* Bottom Footer Info */}
      <footer className="relative z-10 border-t border-slate-800 bg-slate-950/80 px-4 py-4 text-center text-xs text-slate-400 space-y-1">
        <p className="font-medium text-slate-300">
          {schoolSettings.schoolName} — {schoolSettings.schoolAddress || 'Kampus Pendidikan Unggulan'}
        </p>
        <p className="text-[11px] text-slate-400">
          Aplikasi Jurnal Aktivitas & Perkembangan Siswa Terpadu • Sinkronisasi Real-Time Google Workspace
        </p>
      </footer>
    </div>
  );
};
