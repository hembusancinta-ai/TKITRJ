import React, { useState } from 'react';
import { 
  Calendar as CalendarIcon, 
  Clock, 
  MapPin, 
  Plus, 
  ChevronLeft, 
  ChevronRight, 
  Bell, 
  CheckCircle2, 
  Share2,
  CalendarCheck,
  Tag
} from 'lucide-react';
import { AcademicEvent, UserRole } from '../types';

interface AcademicCalendarViewProps {
  events: AcademicEvent[];
  onAddEvent: (event: Omit<AcademicEvent, 'id'>, syncGoogleCal: boolean, pushToParents: boolean) => Promise<void>;
  onTriggerAgendaNotification: (event: AcademicEvent) => void;
  currentRole: UserRole;
  isGoogleConnected: boolean;
}

export const AcademicCalendarView: React.FC<AcademicCalendarViewProps> = ({
  events,
  onAddEvent,
  onTriggerAgendaNotification,
  currentRole,
  isGoogleConnected,
}) => {
  // Calendar state
  const [currentDate, setCurrentDate] = useState(new Date(2026, 8, 8)); // September 2026
  const [selectedDayEvents, setSelectedDayEvents] = useState<AcademicEvent[] | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);

  // New event form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState('2026-09-15');
  const [startTime, setStartTime] = useState('08:00');
  const [endTime, setEndTime] = useState('11:00');
  const [category, setCategory] = useState<AcademicEvent['category']>('Akademik');
  const [location, setLocation] = useState('Aula Sekolah SD Cendekia');
  const [syncGoogleCalendar, setSyncGoogleCalendar] = useState(true);
  const [pushNotification, setPushNotification] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  // Days in month calculation
  const firstDayOfMonth = new Date(year, month, 1).getDay(); // 0 = Sun
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const monthNames = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ];

  const handlePrevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const getEventsForDay = (day: number) => {
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return events.filter(e => e.date === dateStr);
  };

  const handleDayClick = (day: number) => {
    const evs = getEventsForDay(day);
    setSelectedDayEvents(evs);
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    setIsSubmitting(true);
    try {
      await onAddEvent({
        title: title.trim(),
        description: description.trim(),
        date,
        startTime,
        endTime,
        category,
        location,
      }, syncGoogleCalendar, pushNotification);

      setShowAddModal(false);
      setTitle('');
      setDescription('');
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const getCategoryColor = (cat: AcademicEvent['category']) => {
    switch (cat) {
      case 'Akademik':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Ujian':
        return 'bg-rose-100 text-rose-800 border-rose-200';
      case 'Pertemuan Wali':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'Ekstrakurikuler':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      default:
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl p-4 sm:p-6 border border-slate-200 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-bold text-slate-900">
                Kalender Agenda Akademik Sekolah
              </h2>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                Google Calendar
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              Jadwal kegiatan akademik, ujian, dan pertemuan wali murid dengan pengingat notifikasi push.
            </p>
          </div>

          {currentRole === 'teacher' && (
            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center justify-center gap-1.5 px-4 py-2 bg-blue-700 hover:bg-blue-800 text-white font-semibold rounded-xl text-xs shadow-xs transition-colors self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>Jadwalkan Agenda Baru</span>
            </button>
          )}
        </div>
      </div>

      {/* Calendar Grid */}
      <div className="bg-white rounded-2xl p-4 sm:p-6 border border-slate-200 shadow-xs space-y-4">
        {/* Month Navigation */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CalendarCheck className="w-5 h-5 text-blue-700" />
            <h3 className="font-bold text-base text-slate-900">
              {monthNames[month]} {year}
            </h3>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={handlePrevMonth}
              className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={handleNextMonth}
              className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 transition-colors"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Days of Week Header */}
        <div className="grid grid-cols-7 gap-1 text-center font-bold text-xs text-slate-400 py-1 border-b border-slate-100">
          <div>Min</div>
          <div>Sen</div>
          <div>Sel</div>
          <div>Rab</div>
          <div>Kam</div>
          <div>Jum</div>
          <div>Sab</div>
        </div>

        {/* Calendar Day Cells */}
        <div className="grid grid-cols-7 gap-1">
          {/* Empty cells before start of month */}
          {Array.from({ length: firstDayOfMonth }).map((_, idx) => (
            <div key={`empty-${idx}`} className="h-16 sm:h-20 bg-slate-50/40 rounded-xl" />
          ))}

          {/* Actual days */}
          {Array.from({ length: daysInMonth }).map((_, idx) => {
            const dayNum = idx + 1;
            const dayEvents = getEventsForDay(dayNum);
            const isToday = dayNum === 8 && month === 8 && year === 2026;

            return (
              <div
                key={`day-${dayNum}`}
                onClick={() => handleDayClick(dayNum)}
                className={`h-16 sm:h-20 p-1.5 sm:p-2 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                  isToday 
                    ? 'border-blue-500 bg-blue-50/40 shadow-xs' 
                    : 'border-slate-100 hover:border-slate-300 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className={`text-xs font-bold ${isToday ? 'text-blue-700 font-extrabold' : 'text-slate-700'}`}>
                    {dayNum}
                  </span>
                  {dayEvents.length > 0 && (
                    <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse" />
                  )}
                </div>

                <div className="space-y-0.5 overflow-hidden">
                  {dayEvents.slice(0, 2).map(ev => (
                    <div
                      key={ev.id}
                      className="text-[9px] sm:text-[10px] truncate px-1 py-0.2 rounded-sm bg-blue-100 text-blue-800 font-medium"
                      title={ev.title}
                    >
                      {ev.title}
                    </div>
                  ))}
                  {dayEvents.length > 2 && (
                    <div className="text-[9px] text-slate-400 font-semibold">
                      +{dayEvents.length - 2} lagi
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Upcoming Events List */}
      <div className="bg-white rounded-2xl p-4 sm:p-6 border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-sm sm:text-base text-slate-900">
            Daftar Agenda Akademik Mendatang
          </h3>
          <span className="text-xs text-slate-500">
            {events.length} Agenda Terjadwal
          </span>
        </div>

        <div className="space-y-3">
          {events.map(ev => (
            <div
              key={ev.id}
              className="p-4 rounded-xl border border-slate-200 bg-slate-50/70 hover:bg-slate-50 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3"
            >
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 flex-wrap">
                  <h4 className="font-bold text-slate-900 text-sm">{ev.title}</h4>
                  <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full border ${getCategoryColor(ev.category)}`}>
                    {ev.category}
                  </span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed max-w-xl">
                  {ev.description}
                </p>
                <div className="flex items-center gap-3 text-xs text-slate-500 flex-wrap">
                  <span className="flex items-center gap-1 font-medium text-slate-700">
                    <CalendarIcon className="w-3.5 h-3.5 text-blue-600" />
                    {ev.date}
                  </span>
                  {ev.startTime && (
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      {ev.startTime} - {ev.endTime || 'Selesai'} WIB
                    </span>
                  )}
                  {ev.location && (
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      {ev.location}
                    </span>
                  )}
                </div>
              </div>

              {/* Notification Push Button */}
              <div className="flex items-center gap-2 self-end sm:self-center">
                <button
                  onClick={() => onTriggerAgendaNotification(ev)}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-blue-50 text-blue-700 border border-slate-200 hover:border-blue-300 rounded-lg text-xs font-semibold transition-colors shadow-2xs"
                  title="Kirim pengingat notifikasi push ke orang tua sekarang"
                >
                  <Bell className="w-3.5 h-3.5 text-blue-600" />
                  <span>Kirim Notif</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add Event Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-slate-200 animate-in fade-in duration-150">
            <h3 className="font-bold text-base text-slate-900 mb-4">
              Jadwalkan Agenda Akademik Baru
            </h3>

            <form onSubmit={handleFormSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Judul Agenda
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Pentas Seni Kelas 2, Ujian Tengah Semester..."
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:bg-white focus:ring-1 focus:ring-blue-600 outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Tanggal
                  </label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={e => setDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:bg-white focus:ring-1 focus:ring-blue-600 outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Kategori
                  </label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:bg-white focus:ring-1 focus:ring-blue-600 outline-hidden"
                  >
                    <option value="Akademik">Akademik</option>
                    <option value="Ujian">Ujian</option>
                    <option value="Pertemuan Wali">Pertemuan Wali</option>
                    <option value="Ekstrakurikuler">Ekstrakurikuler</option>
                    <option value="Libur Sekolah">Libur Sekolah</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Waktu Mulai
                  </label>
                  <input
                    type="time"
                    value={startTime}
                    onChange={e => setStartTime(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:bg-white focus:ring-1 focus:ring-blue-600 outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Waktu Selesai
                  </label>
                  <input
                    type="time"
                    value={endTime}
                    onChange={e => setEndTime(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:bg-white focus:ring-1 focus:ring-blue-600 outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Lokasi Kegiatan
                </label>
                <input
                  type="text"
                  placeholder="Aula Sekolah / Ruang Kelas / Daring"
                  value={location}
                  onChange={e => setLocation(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:bg-white focus:ring-1 focus:ring-blue-600 outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Deskripsi Singkat
                </label>
                <textarea
                  rows={2}
                  placeholder="Informasi detail kegiatan untuk dibagikan ke orang tua..."
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:bg-white focus:ring-1 focus:ring-blue-600 outline-hidden"
                />
              </div>

              {/* Sync check options */}
              <div className="space-y-2 pt-1 border-t border-slate-100 text-xs">
                <label className="flex items-center gap-2 cursor-pointer text-slate-700">
                  <input
                    type="checkbox"
                    checked={syncGoogleCalendar}
                    onChange={e => setSyncGoogleCalendar(e.target.checked)}
                    className="rounded-sm text-blue-600 focus:ring-blue-500 w-4 h-4"
                  />
                  <span>Sinkronkan ke <strong>Google Calendar</strong> saya</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer text-slate-700">
                  <input
                    type="checkbox"
                    checked={pushNotification}
                    onChange={e => setPushNotification(e.target.checked)}
                    className="rounded-sm text-blue-600 focus:ring-blue-500 w-4 h-4"
                  />
                  <span>Kirim <strong>Push Notifikasi</strong> langsung ke gawai orang tua</span>
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 text-xs font-semibold bg-blue-700 hover:bg-blue-800 text-white rounded-xl shadow-xs transition-colors disabled:opacity-50"
                >
                  {isSubmitting ? 'Menyimpan...' : 'Simpan Agenda'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
