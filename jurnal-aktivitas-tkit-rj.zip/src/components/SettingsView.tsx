import React, { useState, useRef } from 'react';
import { 
  Building2, 
  Eye, 
  Database, 
  FileSpreadsheet, 
  Folder, 
  Calendar, 
  Check, 
  Save, 
  RotateCcw, 
  Users, 
  Edit3, 
  ExternalLink, 
  RefreshCw, 
  ShieldAlert, 
  ShieldCheck, 
  Sparkles,
  Sliders,
  CheckCircle2,
  Lock,
  Plus,
  Camera,
  Upload,
  Trash2,
  Image as ImageIcon
} from 'lucide-react';
import { SchoolSettings, Student } from '../types';
import { WorkspaceSyncStatus } from '../services/googleWorkspace';

interface SettingsViewProps {
  settings: SchoolSettings;
  onUpdateSettings: (newSettings: SchoolSettings) => void;
  syncStatus: WorkspaceSyncStatus;
  onConnectGoogle: () => Promise<void>;
  onInitSpreadsheet: () => Promise<void>;
  isGoogleLoading: boolean;
  googleUserEmail?: string;
  students: Student[];
  onUpdateStudent: (updatedStudent: Student) => void;
  onAddStudent?: (newStudent: Student) => void;
  onNavigateToStudents?: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onUpdateSettings,
  syncStatus,
  onConnectGoogle,
  onInitSpreadsheet,
  isGoogleLoading,
  googleUserEmail,
  students,
  onUpdateStudent,
  onAddStudent,
  onNavigateToStudents,
}) => {
  // Local state for editable settings
  const [formData, setFormData] = useState<SchoolSettings>(settings);
  const [saveAlert, setSaveAlert] = useState<string | null>(null);

  // Student edit modal / inline edit state
  const [editingStudentId, setEditingStudentId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editNis, setEditNis] = useState('');
  const [editClass, setEditClass] = useState('');
  const [editParentName, setEditParentName] = useState('');

  const logoInputRef = useRef<HTMLInputElement | null>(null);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setFormData(prev => ({ ...prev, schoolLogo: reader.result as string }));
        setSaveAlert('Logo sekolah berhasil dipilih! Klik "Simpan Pengaturan" untuk menerapkan.');
        setTimeout(() => setSaveAlert(null), 3500);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveLogo = () => {
    setFormData(prev => ({ ...prev, schoolLogo: '' }));
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings(formData);
    setSaveAlert('Pengaturan nama sekolah, logo, dan visibilitas portal berhasil disimpan!');
    setTimeout(() => setSaveAlert(null), 3500);
  };

  const handleToggleSection = (sectionKey: keyof SchoolSettings['parentPortalSections']) => {
    setFormData(prev => ({
      ...prev,
      parentPortalSections: {
        ...prev.parentPortalSections,
        [sectionKey]: !prev.parentPortalSections[sectionKey]
      }
    }));
  };

  const handleStartEditStudent = (student: Student) => {
    setEditingStudentId(student.id);
    setEditName(student.name);
    setEditNis(student.nis);
    setEditClass(student.className);
    setEditParentName(student.parentName);
  };

  const handleSaveStudentEdit = () => {
    if (!editingStudentId || !editName.trim()) return;
    const orig = students.find(s => s.id === editingStudentId);
    if (!orig) return;

    const updated: Student = {
      ...orig,
      name: editName.trim(),
      nis: editNis.trim() || orig.nis,
      className: editClass.trim() || orig.className,
      parentName: editParentName.trim() || orig.parentName,
    };

    onUpdateStudent(updated);
    setEditingStudentId(null);
    setSaveAlert(`Data siswa "${updated.name}" berhasil diperbarui.`);
    setTimeout(() => setSaveAlert(null), 3500);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-6 space-y-6">
      {/* Top Banner Alert */}
      {saveAlert && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs sm:text-sm text-emerald-800 flex items-center gap-2.5 animate-in fade-in slide-in-from-top-2 duration-150">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span className="font-semibold">{saveAlert}</span>
        </div>
      )}

      {/* Main Header */}
      <div className="bg-white rounded-3xl p-5 sm:p-7 border border-slate-200 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-blue-700 text-white flex items-center justify-center shadow-xs">
                <Building2 className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                  Pengaturan Sekolah & Portal Orang Tua
                </h1>
                <p className="text-xs sm:text-sm text-slate-500">
                  Kelola nama sekolah, integrasi Google Workspace, visibilitas fitur orang tua, dan data siswa.
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleSaveSettings}
              className="flex items-center gap-2 px-5 py-2.5 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-xl text-xs sm:text-sm shadow-xs transition-colors"
            >
              <Save className="w-4 h-4" />
              <span>Simpan Pengaturan</span>
            </button>
          </div>
        </div>
      </div>

      <form onSubmit={handleSaveSettings} className="space-y-6">
        {/* SECTION 1: NAMA SEKOLAH & IDENTITAS */}
        <div className="bg-white rounded-3xl p-5 sm:p-7 border border-slate-200 shadow-xs space-y-5">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-800 flex items-center justify-center font-bold text-sm">
                1
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Identitas & Nama Resmi Sekolah
                </h2>
                <p className="text-xs text-slate-500">
                  Nama sekolah akan ditampilkan dengan ukuran huruf yang lebih besar di seluruh aplikasi dan rapor PDF.
                </p>
              </div>
            </div>
            <span className="text-[11px] font-semibold px-2.5 py-1 rounded-full bg-blue-50 text-blue-700 border border-blue-200 hidden sm:inline">
              Huruf Lebih Besar
            </span>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">
                Nama Sekolah (Ukuran Font Besar di Header):
              </label>
              <input
                type="text"
                required
                value={formData.schoolName}
                onChange={e => setFormData({ ...formData, schoolName: e.target.value })}
                placeholder="Contoh: SD & TK CENDEKIA HARAPAN"
                className="w-full px-4 py-3 bg-slate-50 border border-slate-300 rounded-xl text-base sm:text-lg font-black text-slate-900 focus:bg-white focus:ring-2 focus:ring-blue-600 outline-hidden tracking-tight"
              />
              <p className="text-[11px] text-slate-500 mt-1">
                Akan muncul di header atas navigasi, kartu portal orang tua, dan kop surat rapor resmi.
              </p>
            </div>

            {/* Live Preview Box */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-1.5">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Pratinjau Tampilan Header:
              </span>
              <div className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                {formData.schoolName || 'Nama Sekolah Belum Diisi'}
              </div>
              <div className="text-xs font-semibold text-slate-600">
                {formData.schoolSubheader || 'Slogan atau Jenjang Pendidikan'} • Tahun Ajaran {formData.academicYear}
              </div>
            </div>

            {/* UPLOAD LOGO SEKOLAH (Tombol Upload Logo di Halaman Pengaturan) */}
            <div className="pt-2 border-t border-slate-100 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider">
                    Logo Resmi Sekolah:
                  </label>
                  <p className="text-[11px] text-slate-500">
                    Logo akan otomatis muncul di header aplikasi, portal orang tua, dan kop surat laporan rapor PDF.
                  </p>
                </div>
                {formData.schoolLogo && (
                  <button
                    type="button"
                    onClick={handleRemoveLogo}
                    className="inline-flex items-center gap-1 text-[11px] text-rose-600 hover:text-rose-700 font-bold hover:underline"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>Hapus Logo</span>
                  </button>
                )}
              </div>

              <div className="flex flex-col sm:flex-row sm:items-center gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-200">
                {/* Logo Preview Box */}
                <div className="w-20 h-20 rounded-2xl bg-white border-2 border-slate-300 flex items-center justify-center overflow-hidden shrink-0 shadow-xs relative group p-1">
                  {formData.schoolLogo ? (
                    <img
                      src={formData.schoolLogo}
                      alt="Logo Sekolah"
                      className="w-full h-full object-contain"
                    />
                  ) : (
                    <div className="flex flex-col items-center justify-center text-slate-400 text-center p-1">
                      <ImageIcon className="w-7 h-7 stroke-1" />
                      <span className="text-[9px] font-semibold mt-0.5">Belum Ada Logo</span>
                    </div>
                  )}
                </div>

                {/* Upload & Preset Buttons */}
                <div className="space-y-2 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <input
                      type="file"
                      ref={logoInputRef}
                      onChange={handleLogoUpload}
                      accept="image/*"
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => logoInputRef.current?.click()}
                      className="inline-flex items-center gap-2 px-4 py-2.5 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-xl text-xs shadow-xs transition-colors cursor-pointer"
                    >
                      <Upload className="w-4 h-4" />
                      <span>Upload Logo Sekolah (File / Kamera)</span>
                    </button>
                  </div>

                  <p className="text-[11px] text-slate-500">
                    Format yang didukung: PNG, JPG, JPEG, SVG. Disarankan gambar persegi dengan latar belakang transparan atau putih.
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Slogan / Subjudul Sekolah:
                </label>
                <input
                  type="text"
                  value={formData.schoolSubheader}
                  onChange={e => setFormData({ ...formData, schoolSubheader: e.target.value })}
                  placeholder="Contoh: Sekolah Unggul Ramah Anak"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:bg-white focus:ring-1 focus:ring-blue-600 outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Tahun Ajaran:
                </label>
                <input
                  type="text"
                  value={formData.academicYear}
                  onChange={e => setFormData({ ...formData, academicYear: e.target.value })}
                  placeholder="2026/2027"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:bg-white focus:ring-1 focus:ring-blue-600 outline-hidden"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Alamat & Kontak Sekolah (Dicetak pada Kop PDF):
                </label>
                <input
                  type="text"
                  value={formData.schoolAddress}
                  onChange={e => setFormData({ ...formData, schoolAddress: e.target.value })}
                  placeholder="Jl. Pendidikan No. 45, Jakarta | Telp: (021) 7890-1234"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:bg-white focus:ring-1 focus:ring-blue-600 outline-hidden"
                />
              </div>
            </div>
          </div>
        </div>

        {/* SECTION 2: KONTROL BAGIAN-BAGIAN PORTAL ORANG TUA */}
        <div className="bg-white rounded-3xl p-5 sm:p-7 border border-slate-200 shadow-xs space-y-5">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-sm">
                2
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Bagian yang Ditampilkan di Portal Orang Tua
                </h2>
                <p className="text-xs text-slate-500">
                  Pilih fitur dan menu yang diizinkan untuk diakses orang tua ketika masuk ke portal siswa.
                </p>
              </div>
            </div>
            <span className="text-[11px] font-semibold px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 hidden sm:inline">
              Personalisasi Hak Akses
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {/* Toggle 1: 4 Quick Stats */}
            <div 
              onClick={() => handleToggleSection('showSummaryStats')}
              className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex items-start justify-between gap-3 ${
                formData.parentPortalSections.showSummaryStats
                  ? 'border-emerald-500 bg-emerald-50/40'
                  : 'border-slate-200 bg-slate-50/50 opacity-75'
              }`}
            >
              <div className="space-y-1">
                <div className="text-xs font-bold text-slate-900">
                  Kotak Ringkasan Capaian Cepat
                </div>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Menampilkan 4 metrik cepat (Total Aktivitas, Capaian Sangat Baik, Status Belajar, dan Evaluasi).
                </p>
              </div>
              <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${
                formData.parentPortalSections.showSummaryStats
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-200 text-slate-400'
              }`}>
                {formData.parentPortalSections.showSummaryStats && <Check className="w-3.5 h-3.5" />}
              </div>
            </div>

            {/* Toggle 2: Category Filter */}
            <div 
              onClick={() => handleToggleSection('showCategoryFilter')}
              className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex items-start justify-between gap-3 ${
                formData.parentPortalSections.showCategoryFilter
                  ? 'border-emerald-500 bg-emerald-50/40'
                  : 'border-slate-200 bg-slate-50/50 opacity-75'
              }`}
            >
              <div className="space-y-1">
                <div className="text-xs font-bold text-slate-900">
                  Filter 5 Aspek Kategori
                </div>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Memungkinkan orang tua memfilter linimasa berdasarkan Kognitif, Motorik, Sosial, Kemandirian, dll.
                </p>
              </div>
              <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${
                formData.parentPortalSections.showCategoryFilter
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-200 text-slate-400'
              }`}>
                {formData.parentPortalSections.showCategoryFilter && <Check className="w-3.5 h-3.5" />}
              </div>
            </div>

            {/* Toggle 3: Rating Bintang & Komentar Orang Tua */}
            <div 
              onClick={() => handleToggleSection('allowParentFeedback')}
              className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex items-start justify-between gap-3 ${
                formData.parentPortalSections.allowParentFeedback
                  ? 'border-amber-500 bg-amber-50/40'
                  : 'border-slate-200 bg-slate-50/50 opacity-75'
              }`}
            >
              <div className="space-y-1">
                <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  <span>Rating Bintang & Komentar Orang Tua</span>
                  <span className="text-[9px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.2 rounded-sm">
                    ⭐ Interaktif
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Orang tua dapat memberikan 1-5 bintang serta menuliskan komentar/apresiasi langsung kepada guru.
                </p>
              </div>
              <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${
                formData.parentPortalSections.allowParentFeedback
                  ? 'bg-amber-600 text-white'
                  : 'bg-slate-200 text-slate-400'
              }`}>
                {formData.parentPortalSections.allowParentFeedback && <Check className="w-3.5 h-3.5" />}
              </div>
            </div>

            {/* Toggle 4: Unduh Rapor PDF */}
            <div 
              onClick={() => handleToggleSection('showWeeklyReportDownload')}
              className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex items-start justify-between gap-3 ${
                formData.parentPortalSections.showWeeklyReportDownload
                  ? 'border-emerald-500 bg-emerald-50/40'
                  : 'border-slate-200 bg-slate-50/50 opacity-75'
              }`}
            >
              <div className="space-y-1">
                <div className="text-xs font-bold text-slate-900">
                  Tombol Unduh Rapor PDF Resmi
                </div>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Mengizinkan orang tua mengunduh berkas laporan cetak PDF dengan kop sekolah dan kolom tanda tangan.
                </p>
              </div>
              <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${
                formData.parentPortalSections.showWeeklyReportDownload
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-200 text-slate-400'
              }`}>
                {formData.parentPortalSections.showWeeklyReportDownload && <Check className="w-3.5 h-3.5" />}
              </div>
            </div>

            {/* Toggle 5: Tab Agenda Akademik */}
            <div 
              onClick={() => handleToggleSection('showAcademicCalendar')}
              className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex items-start justify-between gap-3 ${
                formData.parentPortalSections.showAcademicCalendar
                  ? 'border-blue-500 bg-blue-50/40'
                  : 'border-slate-200 bg-slate-50/50 opacity-75'
              }`}
            >
              <div className="space-y-1">
                <div className="text-xs font-bold text-slate-900">
                  Menu Tab: Agenda Akademik Sekolah
                </div>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Menampilkan kalender kegiatan sekolah, ujian, dan jadwal pertemuan wali murid di portal orang tua.
                </p>
              </div>
              <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${
                formData.parentPortalSections.showAcademicCalendar
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-200 text-slate-400'
              }`}>
                {formData.parentPortalSections.showAcademicCalendar && <Check className="w-3.5 h-3.5" />}
              </div>
            </div>

            {/* Toggle 6: Tab Galeri Google Drive */}
            <div 
              onClick={() => handleToggleSection('showDriveGallery')}
              className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex items-start justify-between gap-3 ${
                formData.parentPortalSections.showDriveGallery
                  ? 'border-blue-500 bg-blue-50/40'
                  : 'border-slate-200 bg-slate-50/50 opacity-75'
              }`}
            >
              <div className="space-y-1">
                <div className="text-xs font-bold text-slate-900">
                  Menu Tab: Galeri Foto Kegiatan (Drive)
                </div>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Menampilkan album foto kegiatan belajar siswa di navigasi portal orang tua.
                </p>
              </div>
              <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${
                formData.parentPortalSections.showDriveGallery
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-200 text-slate-400'
              }`}>
                {formData.parentPortalSections.showDriveGallery && <Check className="w-3.5 h-3.5" />}
              </div>
            </div>

            {/* Toggle 7: Tab Rapor & Evaluasi Mingguan */}
            <div 
              onClick={() => handleToggleSection('showWeeklySummaryTab')}
              className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex items-start justify-between gap-3 sm:col-span-2 ${
                formData.parentPortalSections.showWeeklySummaryTab
                  ? 'border-blue-500 bg-blue-50/40'
                  : 'border-slate-200 bg-slate-50/50 opacity-75'
              }`}
            >
              <div className="space-y-1">
                <div className="text-xs font-bold text-slate-900">
                  Menu Tab: Rapor & Evaluasi Mingguan
                </div>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Menyediakan halaman analisis perkembangan mingguan dengan grafik distribusi 5 aspek di portal orang tua.
                </p>
              </div>
              <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${
                formData.parentPortalSections.showWeeklySummaryTab
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-200 text-slate-400'
              }`}>
                {formData.parentPortalSections.showWeeklySummaryTab && <Check className="w-3.5 h-3.5" />}
              </div>
            </div>
          </div>
        </div>

        {/* SECTION 3: SAMBUNGKAN GOOGLE WORKSPACE (PINDAH KE PENGATURAN & KHUSUS GURU) */}
        <div className="bg-white rounded-3xl p-5 sm:p-7 border border-slate-200 shadow-xs space-y-5">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center font-bold text-sm">
                3
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Integrasi Google Workspace (Khusus Guru & Admin)
                </h2>
                <p className="text-xs text-slate-500">
                  Sambungkan ke Google Sheets, Google Drive, dan Google Calendar. Menu ini eksklusif diatur oleh guru.
                </p>
              </div>
            </div>
            <span className="text-[11px] font-semibold px-2.5 py-1 rounded-full bg-amber-50 text-amber-800 border border-amber-200 flex items-center gap-1">
              <Lock className="w-3 h-3 text-amber-600" />
              Khusus Guru
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
            {/* Service 1: Google Sheets */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col justify-between space-y-3">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                    <FileSpreadsheet className="w-5 h-5" />
                  </div>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    syncStatus.isConnected ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'
                  }`}>
                    {syncStatus.isConnected ? 'Terhubung' : 'Belum Terhubung'}
                  </span>
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-900">Google Sheets</h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Database catatan siswa, riwayat jurnal, dan capaian harian.
                  </p>
                </div>
              </div>

              {syncStatus.spreadsheetUrl ? (
                <a
                  href={syncStatus.spreadsheetUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-xs transition-colors shadow-2xs"
                >
                  <span>Buka Spreadsheet</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              ) : (
                <button
                  type="button"
                  onClick={onConnectGoogle}
                  disabled={isGoogleLoading}
                  className="flex items-center justify-center gap-1.5 px-3 py-2 bg-white border border-slate-300 text-slate-700 hover:bg-slate-100 font-semibold rounded-xl text-xs transition-colors"
                >
                  <span>Hubungkan Sheet</span>
                </button>
              )}
            </div>

            {/* Service 2: Google Drive */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col justify-between space-y-3">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center">
                    <Folder className="w-5 h-5" />
                  </div>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    syncStatus.isConnected ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'
                  }`}>
                    {syncStatus.isConnected ? 'Folder Siap' : 'Belum Terhubung'}
                  </span>
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-900">Google Drive</h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Penyimpanan otomatis foto kegiatan dan karya siswa.
                  </p>
                </div>
              </div>

              {syncStatus.driveFolderUrl ? (
                <a
                  href={syncStatus.driveFolderUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-1.5 px-3 py-2 bg-amber-600 hover:bg-amber-700 text-white font-semibold rounded-xl text-xs transition-colors shadow-2xs"
                >
                  <span>Buka Folder Drive</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              ) : (
                <button
                  type="button"
                  onClick={onConnectGoogle}
                  disabled={isGoogleLoading}
                  className="flex items-center justify-center gap-1.5 px-3 py-2 bg-white border border-slate-300 text-slate-700 hover:bg-slate-100 font-semibold rounded-xl text-xs transition-colors"
                >
                  <span>Hubungkan Drive</span>
                </button>
              )}
            </div>

            {/* Service 3: Google Calendar */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col justify-between space-y-3">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center">
                    <Calendar className="w-5 h-5" />
                  </div>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    syncStatus.isConnected ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'
                  }`}>
                    {syncStatus.isConnected ? 'Sinkron' : 'Belum Terhubung'}
                  </span>
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-900">Google Calendar</h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Sinkronisasi otomatis agenda akademik ke kalender sekolah.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={onConnectGoogle}
                disabled={isGoogleLoading}
                className="flex items-center justify-center gap-1.5 px-3 py-2 bg-blue-700 hover:bg-blue-800 text-white font-semibold rounded-xl text-xs transition-colors shadow-2xs disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isGoogleLoading ? 'animate-spin' : ''}`} />
                <span>{syncStatus.isConnected ? 'Sinkronkan Ulang' : 'Sambungkan Google'}</span>
              </button>
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs text-slate-600">
            <span>
              Akun Google: <strong>{googleUserEmail || 'Belum tersambung (dapat disambungkan via akun Google Anda)'}</strong>
            </span>
            {syncStatus.isConnected && (
              <span className="text-[11px] text-emerald-700 font-semibold flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                Semua Izin Workspace Aktif
              </span>
            )}
          </div>
        </div>

        {/* SECTION 4: GANTI NAMA ANAK & MANAJEMEN DATA SISWA (HANYA ADA DI PORTAL GURU) */}
        <div className="bg-white rounded-3xl p-5 sm:p-7 border border-slate-200 shadow-xs space-y-5">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-purple-100 text-purple-800 flex items-center justify-center font-bold text-sm">
                4
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Kelola & Ganti Nama Siswa (Khusus Portal Guru)
                </h2>
                <p className="text-xs text-slate-500">
                  Ubah nama lengkap, nomor NIS/NISN, atau wali murid. Portal orang tua hanya dapat login dengan nama & NIS ini.
                </p>
              </div>
            </div>
            <span className="text-[11px] font-semibold px-2.5 py-1 rounded-full bg-purple-50 text-purple-700 border border-purple-200">
              {students.length} Siswa Terdaftar
            </span>
          </div>

          {onNavigateToStudents && (
            <div className="p-3.5 bg-purple-50/80 rounded-2xl border border-purple-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <Users className="w-5 h-5 text-purple-700 shrink-0" />
                <div className="text-xs text-purple-900">
                  <strong>Halaman Khusus Daftar Siswa & Foto:</strong> Kelola foto tiap siswa, tambah siswa baru, dan cetak rapor PDF langsung dari database.
                </div>
              </div>
              <button
                type="button"
                onClick={onNavigateToStudents}
                className="px-3.5 py-1.5 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-bold whitespace-nowrap shadow-2xs self-start sm:self-auto"
              >
                Buka Halaman Daftar Siswa
              </button>
            </div>
          )}

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-semibold">
                  <th className="pb-2.5">Nama Siswa</th>
                  <th className="pb-2.5">Nomor NIS / NISN</th>
                  <th className="pb-2.5">Kelas</th>
                  <th className="pb-2.5">Nama Orang Tua</th>
                  <th className="pb-2.5 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {students.map(student => {
                  const isEditing = editingStudentId === student.id;
                  return (
                    <tr key={student.id} className="hover:bg-slate-50/70 transition-colors">
                      {isEditing ? (
                        <>
                          <td className="py-2.5 pr-2">
                            <input
                              type="text"
                              value={editName}
                              onChange={e => setEditName(e.target.value)}
                              className="w-full px-2 py-1 bg-white border border-blue-400 rounded-lg text-xs font-bold text-slate-900 outline-hidden"
                            />
                          </td>
                          <td className="py-2.5 pr-2">
                            <input
                              type="text"
                              value={editNis}
                              onChange={e => setEditNis(e.target.value)}
                              className="w-full px-2 py-1 bg-white border border-blue-400 rounded-lg text-xs font-mono text-slate-900 outline-hidden"
                            />
                          </td>
                          <td className="py-2.5 pr-2">
                            <input
                              type="text"
                              value={editClass}
                              onChange={e => setEditClass(e.target.value)}
                              className="w-full px-2 py-1 bg-white border border-blue-400 rounded-lg text-xs text-slate-900 outline-hidden"
                            />
                          </td>
                          <td className="py-2.5 pr-2">
                            <input
                              type="text"
                              value={editParentName}
                              onChange={e => setEditParentName(e.target.value)}
                              className="w-full px-2 py-1 bg-white border border-blue-400 rounded-lg text-xs text-slate-900 outline-hidden"
                            />
                          </td>
                          <td className="py-2.5 text-right space-x-1">
                            <button
                              type="button"
                              onClick={handleSaveStudentEdit}
                              className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-[11px]"
                            >
                              Simpan
                            </button>
                            <button
                              type="button"
                              onClick={() => setEditingStudentId(null)}
                              className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg text-[11px]"
                            >
                              Batal
                            </button>
                          </td>
                        </>
                      ) : (
                        <>
                          <td className="py-3 font-bold text-slate-900">
                            <div className="flex items-center gap-2">
                              <img
                                src={student.avatar}
                                alt={student.name}
                                className="w-7 h-7 rounded-full object-cover border border-slate-200"
                              />
                              <span>{student.name}</span>
                            </div>
                          </td>
                          <td className="py-3 font-mono font-semibold text-blue-700">
                            {student.nis}
                          </td>
                          <td className="py-3 text-slate-600">
                            {student.className}
                          </td>
                          <td className="py-3 text-slate-600">
                            {student.parentName}
                          </td>
                          <td className="py-3 text-right">
                            <button
                              type="button"
                              onClick={() => handleStartEditStudent(student)}
                              className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-100 hover:bg-blue-50 text-slate-700 hover:text-blue-700 rounded-lg font-semibold text-xs transition-colors"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                              <span>Ganti Nama / NIS</span>
                            </button>
                          </td>
                        </>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Bottom Save Bar */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-3 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-2xl text-sm shadow-md transition-colors"
          >
            <Save className="w-4 h-4" />
            <span>Simpan Semua Pengaturan</span>
          </button>
        </div>
      </form>
    </div>
  );
};
