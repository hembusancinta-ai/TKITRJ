import React, { useState } from 'react';
import { 
  FileText, 
  Download, 
  Sparkles, 
  TrendingUp, 
  Award, 
  CheckCircle, 
  User, 
  Share2, 
  Send,
  Calendar,
  AlertCircle
} from 'lucide-react';
import { Student, ActivityJournal, ActivityCategory, MilestoneLevel, WeeklySummaryData, UserRole, SchoolSettings } from '../types';
import { generateStudentReportPdf } from '../services/pdfReport';

interface WeeklySummaryViewProps {
  students: Student[];
  journals: ActivityJournal[];
  onSendSummaryNotification: (studentName: string) => void;
  currentRole?: UserRole;
  currentChildId?: string;
  schoolSettings?: SchoolSettings;
}

export const WeeklySummaryView: React.FC<WeeklySummaryViewProps> = ({
  students,
  journals,
  onSendSummaryNotification,
  currentRole = 'teacher',
  currentChildId,
  schoolSettings,
}) => {
  const defaultStudentId = currentRole === 'parent' && currentChildId 
    ? currentChildId 
    : (students[0]?.id || '');
    
  const [selectedStudentId, setSelectedStudentId] = useState<string>(defaultStudentId);
  const [selectedWeek, setSelectedWeek] = useState<string>('Minggu Ini (1 - 8 September 2026)');
  const [notificationSent, setNotificationSent] = useState(false);

  // If in parent mode, always force the current verified child
  const effectiveStudentId = currentRole === 'parent' && currentChildId ? currentChildId : selectedStudentId;
  const currentStudent = students.find(s => s.id === effectiveStudentId) || students[0];
  const studentJournals = journals.filter(j => j.studentId === currentStudent.id);

  // Compute automated summary
  const totalActivities = studentJournals.length;

  const categoryCounts: Record<ActivityCategory, number> = {
    'Kognitif & Logika': studentJournals.filter(j => j.category === 'Kognitif & Logika').length,
    'Sosial & Emosional': studentJournals.filter(j => j.category === 'Sosial & Emosional').length,
    'Motorik & Seni': studentJournals.filter(j => j.category === 'Motorik & Seni').length,
    'Kemandirian': studentJournals.filter(j => j.category === 'Kemandirian').length,
    'Bahasa & Literasi': studentJournals.filter(j => j.category === 'Bahasa & Literasi').length,
  };

  const milestoneCounts: Record<MilestoneLevel, number> = {
    'Sangat Baik': studentJournals.filter(j => j.milestone === 'Sangat Baik').length,
    'Berkembang Sesuai Harapan': studentJournals.filter(j => j.milestone === 'Berkembang Sesuai Harapan').length,
    'Mulai Terlihat': studentJournals.filter(j => j.milestone === 'Mulai Terlihat').length,
    'Perlu Bimbingan': studentJournals.filter(j => j.milestone === 'Perlu Bimbingan').length,
  };

  // Generate automated insights based on data
  const achievements: string[] = [
    `Menunjukkan ketertarikan tinggi pada pemecahan masalah dan eksperimen terstruktur (${categoryCounts['Kognitif & Logika']} sesi).`,
    `Kemampuan sosialisasi dan kerjasama kelompok terjalin hangat bersama rekan sebangku.`,
    `Kemampuan motorik dan ekspresi seni berkembang sangat stabil dan rapi.`,
    `Tingkat kedisiplinan dan kemandirian merapikan barang pribadi tergolong memuaskan.`,
  ];

  const teacherRecommendation = `${currentStudent.name} menunjukkan progress belajar yang luar biasa pada minggu ini, khususnya pada aspek inisiatif bertanya dan percaya diri. Untuk orang tua di rumah, disarankan terus memberikan apresiasi positif dan menyediakan waktu membaca buku cerita bersama anak minimal 15 menit setiap malam.`;

  const summaryData: WeeklySummaryData = {
    studentId: currentStudent.id,
    studentName: currentStudent.name,
    weekRange: selectedWeek,
    totalActivities,
    categoryCounts,
    milestoneCounts,
    keyAchievements: achievements,
    teacherNotes: teacherRecommendation,
    growthRating: 5,
  };

  const handleDownloadPdf = () => {
    generateStudentReportPdf(currentStudent, studentJournals, selectedWeek, summaryData, schoolSettings);
  };

  const handleSendNotif = () => {
    onSendSummaryNotification(currentStudent.name);
    setNotificationSent(true);
    setTimeout(() => setNotificationSent(false), 4000);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl p-4 sm:p-6 border border-slate-200 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-bold text-slate-900">
                {currentRole === 'parent' ? `Rapor Mingguan: ${currentStudent.name}` : 'Ringkasan Mingguan Otomatis'}
              </h2>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-blue-600" />
                {currentRole === 'parent' ? 'Laporan Pribadi' : 'Otomatis'}
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              Analisis cerdas perkembangan belajar siswa yang dapat diunduh dalam format PDF resmi dengan kop sekolah.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            {currentRole === 'teacher' && (
              <button
                onClick={handleSendNotif}
                className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs transition-colors"
              >
                <Send className="w-3.5 h-3.5 text-blue-600" />
                <span>{notificationSent ? 'Terkirim ke Ortu!' : 'Kirim Notif Ortu'}</span>
              </button>
            )}

            <button
              onClick={handleDownloadPdf}
              className="flex items-center gap-1.5 px-4 py-2 bg-blue-700 hover:bg-blue-800 text-white font-semibold rounded-xl text-xs shadow-xs transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Unduh Rapor PDF</span>
            </button>
          </div>
        </div>

        {/* Student & Week Filter */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4 pt-4 border-t border-slate-100">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              {currentRole === 'parent' ? 'Identitas Anak Anda:' : 'Pilih Siswa:'}
            </label>
            {currentRole === 'parent' ? (
              <div className="px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 flex items-center justify-between">
                <span>{currentStudent.name}</span>
                <span className="text-xs font-mono text-blue-700">NIS: {currentStudent.nis}</span>
              </div>
            ) : (
              <select
                value={selectedStudentId}
                onChange={e => setSelectedStudentId(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm font-semibold text-slate-900 focus:bg-white focus:ring-1 focus:ring-blue-600 outline-hidden"
              >
                {students.map(s => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.nis}) - {s.className}
                  </option>
                ))}
              </select>
            )}
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Periode Minggu:
            </label>
            <select
              value={selectedWeek}
              onChange={e => setSelectedWeek(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm text-slate-900 focus:bg-white focus:ring-1 focus:ring-blue-600 outline-hidden"
            >
              <option value="Minggu Ini (1 - 8 September 2026)">Minggu Ini (1 - 8 September 2026)</option>
              <option value="Minggu Sebelumnya (24 - 31 Agustus 2026)">Minggu Sebelumnya (24 - 31 Agustus 2026)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs text-center">
          <span className="text-xs text-slate-500 font-medium">Total Aktivitas</span>
          <div className="text-2xl font-bold text-blue-700 mt-1">{totalActivities}</div>
          <span className="text-[11px] text-emerald-600 font-medium">Terdokumentasi Lengkap</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs text-center">
          <span className="text-xs text-slate-500 font-medium">Capaian Tertinggi</span>
          <div className="text-2xl font-bold text-emerald-700 mt-1">{milestoneCounts['Sangat Baik']}</div>
          <span className="text-[11px] text-slate-500 font-medium">Predikat Sangat Baik</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs text-center">
          <span className="text-xs text-slate-500 font-medium">Aspek Terkuat</span>
          <div className="text-base font-bold text-purple-700 mt-2 truncate">Kognitif & Logika</div>
          <span className="text-[11px] text-slate-500 font-medium">Fokus Observasi</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs text-center">
          <span className="text-xs text-slate-500 font-medium">Indeks Keaktifan</span>
          <div className="text-2xl font-bold text-amber-600 mt-1">96%</div>
          <span className="text-[11px] text-emerald-600 font-medium">Sangat Aktif</span>
        </div>
      </div>

      {/* Breakdown by 5 Aspects */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-blue-600" />
          <span>Distribusi Aspek Perkembangan Siswa</span>
        </h3>

        <div className="space-y-3">
          {Object.entries(categoryCounts).map(([cat, count]) => {
            const maxVal = Math.max(...Object.values(categoryCounts), 1);
            const percentage = Math.round((count / maxVal) * 100);
            return (
              <div key={cat} className="space-y-1">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-700">
                  <span>{cat}</span>
                  <span className="text-slate-500 font-normal">{count} Kegiatan</span>
                </div>
                <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-blue-600 rounded-full transition-all duration-500"
                    style={{ width: `${Math.max(percentage, 8)}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Automated Key Insights & Teacher Recommendation */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
          <Award className="w-4 h-4 text-amber-500" />
          <span>Sorotan Capaian & Rekomendasi Belajar</span>
        </h3>

        <div className="space-y-2">
          {achievements.map((ach, i) => (
            <div key={i} className="flex items-start gap-2 text-xs text-slate-700">
              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>{ach}</span>
            </div>
          ))}
        </div>

        <div className="p-4 bg-blue-50/70 border border-blue-100 rounded-xl space-y-1 text-xs">
          <div className="font-bold text-blue-900">Catatan Khusus Wali Kelas:</div>
          <p className="text-slate-700 leading-relaxed">{teacherRecommendation}</p>
        </div>

        {/* PDF Export Banner Box */}
        <div className="p-4 bg-slate-900 text-white rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="text-xs font-bold">Laporan Resmi Siap Cetak (PDF)</div>
            <p className="text-[11px] text-slate-300 mt-0.5">
              Lengkap dengan kop sekolah, foto dokumentasi, dan kolom tanda tangan wali kelas & orang tua.
            </p>
          </div>
          <button
            onClick={handleDownloadPdf}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white font-bold rounded-lg text-xs transition-colors self-start sm:self-auto"
          >
            <Download className="w-4 h-4" />
            <span>Unduh File PDF</span>
          </button>
        </div>
      </div>
    </div>
  );
};
