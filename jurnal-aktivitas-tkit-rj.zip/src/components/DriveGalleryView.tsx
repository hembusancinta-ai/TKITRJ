import React, { useState } from 'react';
import { 
  Folder, 
  ExternalLink, 
  RefreshCw, 
  Image as ImageIcon, 
  Calendar, 
  User, 
  Filter, 
  Eye, 
  CloudUpload,
  Upload
} from 'lucide-react';
import { DriveMediaItem, UserRole } from '../types';

interface DriveGalleryViewProps {
  galleryItems: DriveMediaItem[];
  driveFolderUrl: string | null;
  onRefreshGallery: () => Promise<void>;
  isRefreshing: boolean;
  onUploadDirectPhoto?: (file: File, description: string) => Promise<void>;
  isGoogleConnected: boolean;
  currentRole?: UserRole;
  currentChildName?: string;
}

export const DriveGalleryView: React.FC<DriveGalleryViewProps> = ({
  galleryItems,
  driveFolderUrl,
  onRefreshGallery,
  isRefreshing,
  onUploadDirectPhoto,
  isGoogleConnected,
  currentRole = 'teacher',
  currentChildName,
}) => {
  const [selectedPhoto, setSelectedPhoto] = useState<DriveMediaItem | null>(null);
  const [filterCategory, setFilterCategory] = useState<string>('Semua');

  const categories = ['Semua', 'Kognitif & Logika', 'Motorik & Seni', 'Sosial & Emosional', 'Bahasa & Literasi', 'Kemandirian'];

  // Data isolation: If in parent role, only show photos of this child or general photos!
  const roleFilteredItems = currentRole === 'parent' && currentChildName
    ? galleryItems.filter(item => !item.studentName || item.studentName.toLowerCase().trim() === currentChildName.toLowerCase().trim())
    : galleryItems;

  const filteredItems = filterCategory === 'Semua'
    ? roleFilteredItems
    : roleFilteredItems.filter(item => item.category === filterCategory);

  return (
    <div className="max-w-5xl mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl p-4 sm:p-6 border border-slate-200 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-bold text-slate-900">
                Galeri Dokumentasi Kegiatan Siswa
              </h2>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200 flex items-center gap-1">
                <Folder className="w-3.5 h-3.5 text-amber-600" />
                Google Drive
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              Koleksi foto kegiatan belajar, karya seni, dan perkembangan anak yang tersimpan di Google Drive.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onRefreshGallery()}
              disabled={isRefreshing}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs transition-colors disabled:opacity-50"
              title="Perbarui daftar foto dari Google Drive"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
              <span>{isRefreshing ? 'Menyinkronkan...' : 'Segarkan'}</span>
            </button>

            {currentRole === 'teacher' && (
              driveFolderUrl ? (
                <a
                  href={driveFolderUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 px-3.5 py-2 bg-blue-700 hover:bg-blue-800 text-white font-semibold rounded-xl text-xs shadow-xs transition-colors"
                >
                  <span>Buka Google Drive</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              ) : (
                <button
                  disabled
                  className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-200 text-slate-500 rounded-xl text-xs font-semibold"
                >
                  <span>Folder Drive Terhubung</span>
                </button>
              )
            )}
          </div>
        </div>

        {/* Filter Categories */}
        <div className="mt-4 pt-4 border-t border-slate-100 flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          <Filter className="w-4 h-4 text-slate-400 shrink-0 mr-1" />
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setFilterCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                filterCategory === cat
                  ? 'bg-blue-700 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Gallery Grid */}
      {filteredItems.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center border border-slate-200">
          <ImageIcon className="w-12 h-12 text-slate-300 mx-auto mb-2" />
          <h3 className="font-bold text-sm text-slate-800">Belum Ada Foto dalam Kategori Ini</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            Foto yang diambil guru saat mencatat jurnal perkembangan akan otomatis masuk ke galeri Google Drive ini.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {filteredItems.map(item => (
            <div
              key={item.id}
              onClick={() => setSelectedPhoto(item)}
              className="group bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-md transition-all cursor-pointer flex flex-col"
            >
              <div className="relative aspect-4/3 bg-slate-900 overflow-hidden">
                <img
                  src={item.thumbnailUrl}
                  alt={item.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/25 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <span className="px-3 py-1.5 bg-black/70 text-white text-xs font-semibold rounded-lg backdrop-blur flex items-center gap-1.5">
                    <Eye className="w-4 h-4" />
                    Perbesar
                  </span>
                </div>
                {item.category && (
                  <span className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded-md bg-black/60 text-white text-[10px] font-medium backdrop-blur">
                    {item.category}
                  </span>
                )}
              </div>

              <div className="p-3.5 flex-1 flex flex-col justify-between space-y-2">
                <div>
                  <h4 className="font-bold text-xs text-slate-900 line-clamp-1">
                    {item.description || item.name}
                  </h4>
                  {item.studentName && (
                    <div className="flex items-center gap-1 text-[11px] text-slate-600 mt-1">
                      <User className="w-3 h-3 text-slate-400" />
                      <span>{item.studentName}</span>
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-100">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {item.date}
                  </span>
                  <span className="text-blue-600 font-medium group-hover:underline">
                    Lihat detail →
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Lightbox Modal */}
      {selectedPhoto && (
        <div
          onClick={() => setSelectedPhoto(null)}
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4"
        >
          <div
            onClick={e => e.stopPropagation()}
            className="bg-white rounded-2xl max-w-2xl w-full overflow-hidden shadow-2xl animate-in zoom-in-95 duration-150"
          >
            <div className="relative bg-slate-950 flex items-center justify-center max-h-[60vh]">
              <img
                src={selectedPhoto.thumbnailUrl}
                alt={selectedPhoto.name}
                className="max-h-[60vh] w-auto object-contain"
              />
              <button
                onClick={() => setSelectedPhoto(null)}
                className="absolute top-3 right-3 p-2 bg-black/60 hover:bg-black/80 text-white rounded-full text-xs font-bold"
              >
                ✕
              </button>
            </div>

            <div className="p-5 space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-slate-900">
                    {selectedPhoto.description || selectedPhoto.name}
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Siswa: <strong className="text-slate-700">{selectedPhoto.studentName || 'Seluruh Siswa'}</strong>
                  </p>
                </div>
                {selectedPhoto.category && (
                  <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800">
                    {selectedPhoto.category}
                  </span>
                )}
              </div>

              <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
                <span>Tanggal Dokumentasi: {selectedPhoto.date}</span>
                <span className="text-emerald-700 font-medium">Tersimpan di Google Drive</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
