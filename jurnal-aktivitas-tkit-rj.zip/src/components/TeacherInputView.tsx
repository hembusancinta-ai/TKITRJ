import React, { useState, useEffect, useRef } from 'react';
import { 
  Mic, 
  MicOff, 
  Camera, 
  Upload, 
  Check, 
  ChevronRight, 
  ChevronLeft, 
  Sparkles, 
  Save, 
  RotateCcw, 
  Image as ImageIcon,
  User, 
  Phone, 
  Calendar as CalendarIcon,
  Tag,
  Clock,
  Send,
  CloudUpload,
  CheckCircle2,
  AlertCircle,
  Star,
  MessageCircle
} from 'lucide-react';
import { Student, ActivityJournal, ActivityCategory, MilestoneLevel } from '../types';
import { speechService } from '../services/speechRecognition';
import { WorkspaceSyncStatus } from '../services/googleWorkspace';

interface TeacherInputViewProps {
  students: Student[];
  onSaveJournal: (journal: Omit<ActivityJournal, 'id' | 'timestamp'>, imageBlob?: Blob) => Promise<boolean>;
  syncStatus: WorkspaceSyncStatus;
  recentJournals: ActivityJournal[];
  initialStudentId?: string;
}

const CATEGORIES: { label: ActivityCategory; color: string; desc: string }[] = [
  { label: 'Kognitif & Logika', color: 'bg-blue-50 text-blue-700 border-blue-200', desc: 'Pemecahan masalah, sains, hitung' },
  { label: 'Sosial & Emosional', color: 'bg-rose-50 text-rose-700 border-rose-200', desc: 'Empati, kerjasama, kontrol diri' },
  { label: 'Motorik & Seni', color: 'bg-amber-50 text-amber-700 border-amber-200', desc: 'Kreativitas warna, gerak fisik' },
  { label: 'Kemandirian', color: 'bg-emerald-50 text-emerald-700 border-emerald-200', desc: 'Adab makan, disiplin, tanggung jawab' },
  { label: 'Bahasa & Literasi', color: 'bg-purple-50 text-purple-700 border-purple-200', desc: 'Kosakata, bercerita, menyimak' },
];

const MILESTONES: { level: MilestoneLevel; badge: string; icon: string }[] = [
  { level: 'Sangat Baik', badge: 'bg-emerald-100 text-emerald-800 border-emerald-300', icon: '🌟' },
  { level: 'Berkembang Sesuai Harapan', badge: 'bg-blue-100 text-blue-800 border-blue-300', icon: '👍' },
  { level: 'Mulai Terlihat', badge: 'bg-amber-100 text-amber-800 border-amber-300', icon: '🌱' },
  { level: 'Perlu Bimbingan', badge: 'bg-orange-100 text-orange-800 border-orange-300', icon: '💡' },
];

export const TeacherInputView: React.FC<TeacherInputViewProps> = ({
  students,
  onSaveJournal,
  syncStatus,
  recentJournals,
  initialStudentId,
}) => {
  // Currently selected student
  const [selectedStudentIndex, setSelectedStudentIndex] = useState<number>(() => {
    if (initialStudentId) {
      const idx = students.findIndex(s => s.id === initialStudentId);
      if (idx !== -1) return idx;
    }
    return 0;
  });

  useEffect(() => {
    if (initialStudentId) {
      const idx = students.findIndex(s => s.id === initialStudentId);
      if (idx !== -1) {
        setSelectedStudentIndex(idx);
      }
    }
  }, [initialStudentId, students]);

  const currentStudent = students[selectedStudentIndex] || students[0];

  // Form states
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<ActivityCategory>('Kognitif & Logika');
  const [milestone, setMilestone] = useState<MilestoneLevel>('Berkembang Sesuai Harapan');
  const [narrative, setNarrative] = useState('');
  const [activityDate, setActivityDate] = useState(new Date().toISOString().split('T')[0]);
  const [activityTime, setActivityTime] = useState(() => {
    const d = new Date();
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  });

  // Photo state
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [selectedImageFile, setSelectedImageFile] = useState<Blob | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Speech-to-text state
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [speechError, setSpeechError] = useState<string | null>(null);
  const [interimText, setInterimText] = useState('');

  // Saving state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);

  // Switch student
  const handleStudentChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const idx = students.findIndex(s => s.id === e.target.value);
    if (idx !== -1) {
      setSelectedStudentIndex(idx);
    }
  };

  const handleNextStudent = () => {
    if (selectedStudentIndex < students.length - 1) {
      setSelectedStudentIndex(prev => prev + 1);
    } else {
      setSelectedStudentIndex(0); // Loop back
    }
  };

  const handlePrevStudent = () => {
    if (selectedStudentIndex > 0) {
      setSelectedStudentIndex(prev => prev - 1);
    } else {
      setSelectedStudentIndex(students.length - 1);
    }
  };

  // Voice recording toggle
  const toggleVoiceRecording = () => {
    setSpeechError(null);
    if (isRecordingVoice) {
      speechService.stopListening();
      setIsRecordingVoice(false);
      setInterimText('');
    } else {
      if (!speechService.checkSupport()) {
        setSpeechError('Peramban tidak mendukung pengenalan suara. Anda dapat mengetik narasi secara manual.');
        return;
      }

      speechService.startListening({
        lang: 'id-ID',
        onStart: () => {
          setIsRecordingVoice(true);
        },
        onResult: (transcript, isFinal) => {
          if (isFinal) {
            setNarrative(prev => (prev ? `${prev} ${transcript}` : transcript));
            setInterimText('');
          } else {
            setInterimText(transcript);
          }
        },
        onError: (err) => {
          setSpeechError(err);
          setIsRecordingVoice(false);
          setInterimText('');
        },
        onEnd: () => {
          setIsRecordingVoice(false);
          setInterimText('');
        }
      });
    }
  };

  // Image upload handling
  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const clearImage = () => {
    setImagePreview(null);
    setSelectedImageFile(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Reset form
  const resetForm = () => {
    setTitle('');
    setNarrative('');
    setImagePreview(null);
    setSelectedImageFile(null);
    setCategory('Kognitif & Logika');
    setMilestone('Berkembang Sesuai Harapan');
    if (fileInputRef.current) fileInputRef.current.value = '';
    const d = new Date();
    setActivityTime(`${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`);
  };

  // Save journal
  const handleSubmit = async (advanceNext: boolean = false) => {
    if (!narrative.trim()) {
      alert('Silakan isi narasi catatan perkembangan siswa.');
      return;
    }

    setIsSubmitting(true);
    setSaveSuccessMsg(null);

    try {
      const success = await onSaveJournal({
        studentId: currentStudent.id,
        studentName: currentStudent.name,
        className: currentStudent.className,
        date: activityDate,
        time: activityTime,
        category,
        milestone,
        title: title.trim() || `Aktivitas ${category}`,
        narrative: narrative.trim(),
        photoUrl: imagePreview || undefined,
        teacherName: 'Ibu Ratna Kumalasari, S.Pd',
        tags: [`#${category.replace(/\s+/g, '')}`, `#${currentStudent.className.split(' ')[0]}`],
        syncedToGoogleSheets: syncStatus.isConnected,
        syncedToGoogleDrive: syncStatus.isConnected && !!selectedImageFile,
      }, selectedImageFile || undefined);

      if (success) {
        setSaveSuccessMsg(`Catatan perkembangan untuk ${currentStudent.name} berhasil disimpan!`);
        resetForm();

        if (advanceNext) {
          setTimeout(() => {
            handleNextStudent();
            setSaveSuccessMsg(null);
          }, 800);
        } else {
          setTimeout(() => setSaveSuccessMsg(null), 3500);
        }
      }
    } catch (err) {
      console.error('Error saving journal:', err);
      alert('Gagal menyimpan jurnal. Mohon coba lagi.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Filter journals for current student
  const studentJournals = recentJournals.filter(j => j.studentId === currentStudent.id);

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      {/* Session Progress Header */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-bold text-slate-900">
                Input Jurnal Perkembangan Siswa
              </h2>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                Sesi Berurutan
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              Input efisien per anak. Rekam narasi suara & simpan otomatis ke Google Drive & Sheet.
            </p>
          </div>

          {/* Stepper counter & quick flip */}
          <div className="flex items-center gap-2 self-end sm:self-auto bg-slate-50 p-1.5 rounded-xl border border-slate-200">
            <button
              onClick={handlePrevStudent}
              className="p-1.5 hover:bg-white rounded-lg text-slate-600 transition-colors"
              title="Siswa Sebelumnya"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs font-semibold text-slate-700 px-2">
              Siswa {selectedStudentIndex + 1} dari {students.length}
            </span>
            <button
              onClick={handleNextStudent}
              className="p-1.5 hover:bg-white rounded-lg text-slate-600 transition-colors"
              title="Siswa Berikutnya"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Student Dropdown Selector (Automated from Google Sheets) */}
        <div className="mt-4 pt-4 border-t border-slate-100">
          <label className="block text-xs font-semibold text-slate-700 mb-1.5">
            Pilih Siswa (Otomatis dari Database Google Sheet):
          </label>
          <div className="relative">
            <select
              value={currentStudent.id}
              onChange={handleStudentChange}
              className="w-full pl-3 pr-10 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-semibold text-slate-900 focus:bg-white focus:border-blue-600 focus:ring-2 focus:ring-blue-100 outline-hidden transition-all"
            >
              {students.map((s, idx) => (
                <option key={s.id} value={s.id}>
                  {idx + 1}. {s.name} ({s.nis}) - {s.className}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Selected Student Bio Card */}
        <div className="mt-3 p-3.5 bg-gradient-to-r from-blue-50/70 to-slate-50 rounded-xl border border-blue-100 flex items-center gap-3.5">
          <img
            src={currentStudent.avatar}
            alt={currentStudent.name}
            className="w-13 h-13 rounded-full object-cover border-2 border-white shadow-xs"
          />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-slate-900 truncate">
                {currentStudent.name}
              </h3>
              <span className={`text-[10px] font-semibold px-1.5 py-0.2 rounded-sm ${currentStudent.gender === 'L' ? 'bg-blue-100 text-blue-800' : 'bg-pink-100 text-pink-800'}`}>
                {currentStudent.gender === 'L' ? 'Laki-laki' : 'Perempuan'}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              NIS: <span className="font-medium text-slate-700">{currentStudent.nis}</span> • {currentStudent.className}
            </p>
            <div className="flex items-center gap-3 text-[11px] text-slate-600 mt-1">
              <span>Wali: <strong>{currentStudent.parentName}</strong></span>
              <span className="hidden sm:inline">•</span>
              <span className="hidden sm:inline">Telp: {currentStudent.parentPhone}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Input Form */}
      <div className="bg-white rounded-2xl p-4 sm:p-6 border border-slate-200 shadow-xs space-y-5">
        {saveSuccessMsg && (
          <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2.5 text-emerald-800 text-xs sm:text-sm font-medium animate-in fade-in duration-200">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>{saveSuccessMsg}</span>
          </div>
        )}

        {/* Date & Time Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Tanggal Observasi
            </label>
            <div className="relative">
              <input
                type="date"
                value={activityDate}
                onChange={e => setActivityDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-900 focus:bg-white focus:border-blue-600 focus:ring-1 focus:ring-blue-100 outline-hidden"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Waktu Aktivitas
            </label>
            <input
              type="time"
              value={activityTime}
              onChange={e => setActivityTime(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-900 focus:bg-white focus:border-blue-600 focus:ring-1 focus:ring-blue-100 outline-hidden"
            />
          </div>
        </div>

        {/* Category Selector Chips */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-2">
            Aspek Perkembangan Siswa:
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
            {CATEGORIES.map(cat => {
              const isSelected = category === cat.label;
              return (
                <button
                  key={cat.label}
                  type="button"
                  onClick={() => setCategory(cat.label)}
                  className={`p-2.5 text-left rounded-xl border text-xs font-medium transition-all ${
                    isSelected 
                      ? 'bg-blue-600 text-white border-blue-600 shadow-xs ring-2 ring-blue-100' 
                      : `${cat.color} hover:opacity-90`
                  }`}
                >
                  <div className="font-semibold text-xs leading-tight">{cat.label}</div>
                  <div className={`text-[10px] mt-1 line-clamp-1 ${isSelected ? 'text-blue-100' : 'opacity-80'}`}>
                    {cat.desc}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Milestone Indicator */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-2">
            Tingkat Capaian Siswa:
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {MILESTONES.map(m => {
              const isSelected = milestone === m.level;
              return (
                <button
                  key={m.level}
                  type="button"
                  onClick={() => setMilestone(m.level)}
                  className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs font-medium transition-all ${
                    isSelected
                      ? `${m.badge} font-bold ring-2 ring-blue-200 shadow-xs`
                      : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <span className="text-base">{m.icon}</span>
                  <span className="text-xs leading-tight text-left">{m.level}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Activity Title */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Judul Kegiatan / Observasi
          </label>
          <input
            type="text"
            placeholder="Contoh: Eksperimen Tunas Tanaman, Menggunting Pola Geometri, Bermain Peran..."
            value={title}
            onChange={e => setTitle(e.target.value)}
            className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-900 focus:bg-white focus:border-blue-600 focus:ring-2 focus:ring-blue-100 outline-hidden transition-all"
          />
        </div>

        {/* Narrative Box with Speech-to-Text Feature */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-semibold text-slate-700">
              Narasi & Catatan Perkembangan Siswa:
            </label>
            
            {/* SPEECH TO TEXT BUTTON */}
            <button
              type="button"
              onClick={toggleVoiceRecording}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                isRecordingVoice
                  ? 'bg-red-600 text-white shadow-md animate-pulse'
                  : 'bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200'
              }`}
              title="Bicara dalam Bahasa Indonesia untuk input teks otomatis"
            >
              {isRecordingVoice ? (
                <>
                  <MicOff className="w-3.5 h-3.5 animate-spin" />
                  <span>Mendengarkan... (Klik Selesai)</span>
                </>
              ) : (
                <>
                  <Mic className="w-3.5 h-3.5 text-blue-600" />
                  <span>Dikte Suara (Bicara)</span>
                </>
              )}
            </button>
          </div>

          {/* Voice recording live status alert */}
          {isRecordingVoice && (
            <div className="mb-2 p-2.5 bg-red-50 border border-red-200 rounded-xl flex items-center justify-between text-xs text-red-700">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-ping" />
                <span>Mikrofon aktif. Silakan bicara mengenai aktivitas <strong>{currentStudent.name}</strong>...</span>
              </div>
              <span className="text-[11px] font-semibold text-red-800">Bahasa Indonesia</span>
            </div>
          )}

          {speechError && (
            <div className="mb-2 p-2 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-amber-600" />
              <span>{speechError}</span>
            </div>
          )}

          <div className="relative">
            <textarea
              rows={4}
              placeholder="Ketik narasi atau klik tombol 'Dikte Suara' untuk mendikte langsung dari HP..."
              value={narrative}
              onChange={e => setNarrative(e.target.value)}
              className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-900 focus:bg-white focus:border-blue-600 focus:ring-2 focus:ring-blue-100 outline-hidden transition-all leading-relaxed"
            />
            {interimText && (
              <div className="absolute bottom-3 left-3 right-3 text-xs italic text-blue-600 bg-white/90 p-1.5 rounded-md border border-blue-200 truncate">
                Mendengar: "{interimText}"
              </div>
            )}
          </div>
        </div>

        {/* Photo Upload / Camera for Mobile & Web */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1.5">
            Foto Dokumentasi Aktivitas (Tersimpan di Google Drive):
          </label>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            onChange={handleImageSelect}
            className="hidden"
            id="activity-camera-input"
          />

          {!imagePreview ? (
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-slate-300 hover:border-blue-500 bg-slate-50/50 hover:bg-blue-50/30 rounded-xl p-6 text-center cursor-pointer transition-colors"
            >
              <div className="flex flex-col items-center justify-center gap-2">
                <div className="w-11 h-11 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center">
                  <Camera className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs sm:text-sm font-semibold text-blue-700">
                    Ambil Foto dari Kamera HP / Galeri
                  </span>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Format JPG, PNG (akan otomatis diunggah ke Google Drive)
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="relative rounded-xl overflow-hidden border border-slate-200 bg-slate-900 max-h-64 flex items-center justify-center">
              <img
                src={imagePreview}
                alt="Pratinjau Aktivitas"
                className="max-h-64 w-auto object-contain"
              />
              <div className="absolute top-2 right-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={clearImage}
                  className="p-1.5 bg-black/60 hover:bg-black/80 text-white rounded-lg text-xs backdrop-blur"
                >
                  Hapus Foto
                </button>
              </div>
              <div className="absolute bottom-2 left-2 bg-black/60 backdrop-blur px-2 py-1 rounded-md text-[11px] text-white flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Foto siap disimpan ke Google Drive</span>
              </div>
            </div>
          )}
        </div>

        {/* Sync destination status indicator */}
        <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CloudUpload className="w-4 h-4 text-blue-600" />
            <span>Target Penyimpanan: <strong>Google Sheets</strong> (Data Jurnal) & <strong>Google Drive</strong> (Foto)</span>
          </div>
          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${syncStatus.isConnected ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-200 text-slate-700'}`}>
            {syncStatus.isConnected ? 'Google Terhubung' : 'Mode Offline/Lokal'}
          </span>
        </div>

        {/* Action Buttons: Save & Save-and-Next-Student */}
        <div className="pt-2 flex flex-col sm:flex-row gap-3">
          {/* Button 1: Simpan Saja */}
          <button
            type="button"
            disabled={isSubmitting}
            onClick={() => handleSubmit(false)}
            className="flex-1 flex items-center justify-center gap-2 py-3 px-4 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-800 font-semibold rounded-xl text-xs sm:text-sm border border-slate-300 transition-colors disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            <span>{isSubmitting ? 'Menyimpan...' : 'Simpan Catatan'}</span>
          </button>

          {/* Button 2: Simpan & Lanjut ke Siswa Berikutnya (Explicitly requested for one-session efficiency) */}
          <button
            type="button"
            disabled={isSubmitting}
            onClick={() => handleSubmit(true)}
            className="flex-1 flex items-center justify-center gap-2 py-3 px-4 bg-blue-700 hover:bg-blue-800 active:bg-blue-900 text-white font-semibold rounded-xl text-xs sm:text-sm shadow-md transition-all disabled:opacity-50"
          >
            <span>{isSubmitting ? 'Memproses...' : 'Simpan & Lanjut Siswa Berikutnya'}</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* History of notes for this student today */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-bold text-slate-900">
            Riwayat Jurnal {currentStudent.name}
          </h3>
          <span className="text-xs text-slate-500">
            {studentJournals.length} Catatan
          </span>
        </div>

        {studentJournals.length === 0 ? (
          <div className="py-6 text-center text-xs text-slate-400">
            Belum ada catatan aktivitas untuk siswa ini.
          </div>
        ) : (
          <div className="space-y-2.5">
            {studentJournals.map(j => (
              <div
                key={j.id}
                className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-2 text-xs"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-slate-900">{j.title}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-blue-100 text-blue-700 font-medium">
                        {j.category}
                      </span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-emerald-100 text-emerald-700 font-medium">
                        {j.milestone}
                      </span>
                      {j.parentRating && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-amber-100 text-amber-900 font-bold flex items-center gap-1">
                          <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                          <span>{j.parentRating} Bintang Orang Tua</span>
                        </span>
                      )}
                    </div>
                    <p className="text-slate-600 line-clamp-2 leading-relaxed">{j.narrative}</p>
                  </div>
                  <div className="text-[10px] text-slate-400 whitespace-nowrap">
                    {j.date} {j.time}
                  </div>
                </div>

                {/* Comments from parents */}
                {j.comments && j.comments.length > 0 && (
                  <div className="pt-2 border-t border-slate-200/60 space-y-1.5">
                    <span className="text-[10px] font-bold text-slate-700 flex items-center gap-1">
                      <MessageCircle className="w-3 h-3 text-emerald-600" />
                      <span>Tanggapan / Komentar Orang Tua:</span>
                    </span>
                    {j.comments.map(c => (
                      <div key={c.id} className="p-2 bg-white rounded-lg border border-slate-200 text-[11px] text-slate-800">
                        <div className="flex justify-between text-[10px] text-slate-500 mb-0.5">
                          <strong className="text-emerald-800">{c.senderName}</strong>
                          <span>{c.dateStr}</span>
                        </div>
                        <p>{c.comment}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
