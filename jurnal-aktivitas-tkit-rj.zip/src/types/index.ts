export type UserRole = 'teacher' | 'parent';

export type ActivityCategory = 
  | 'Kognitif & Logika'
  | 'Sosial & Emosional'
  | 'Motorik & Seni'
  | 'Kemandirian'
  | 'Bahasa & Literasi';

export type MilestoneLevel = 
  | 'Sangat Baik' 
  | 'Berkembang Sesuai Harapan' 
  | 'Mulai Terlihat' 
  | 'Perlu Bimbingan';

export interface Student {
  id: string;
  name: string;
  nis: string;
  className: string;
  gender: 'L' | 'P';
  avatar: string;
  parentName: string;
  parentPhone: string;
  parentEmail: string;
  birthDate?: string;
}

export interface JournalComment {
  id: string;
  senderRole: 'parent' | 'teacher';
  senderName: string;
  comment: string;
  timestamp: number;
  dateStr: string;
}

export interface ActivityJournal {
  id: string;
  studentId: string;
  studentName: string;
  className: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  timestamp: number;
  category: ActivityCategory;
  milestone: MilestoneLevel;
  title: string;
  narrative: string;
  photoUrl?: string;
  photoDriveId?: string;
  teacherName: string;
  tags?: string[];
  syncedToGoogleSheets?: boolean;
  syncedToGoogleDrive?: boolean;
  parentRating?: number; // 1 to 5 stars
  comments?: JournalComment[];
}

export interface AcademicEvent {
  id: string;
  title: string;
  description: string;
  date: string; // YYYY-MM-DD
  startTime?: string;
  endTime?: string;
  category: 'Akademik' | 'Ujian' | 'Pertemuan Wali' | 'Ekstrakurikuler' | 'Libur Sekolah';
  location?: string;
  googleCalendarEventId?: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  time: string;
  timestamp: number;
  read: boolean;
  targetRole: 'parent' | 'teacher' | 'all';
  studentId?: string;
  type: 'journal' | 'agenda' | 'summary' | 'system';
}

export interface DriveMediaItem {
  id: string;
  name: string;
  mimeType: string;
  thumbnailUrl: string;
  date: string;
  studentName?: string;
  category?: string;
  description?: string;
}

export interface WeeklySummaryData {
  studentId: string;
  studentName: string;
  weekRange: string;
  totalActivities: number;
  categoryCounts: Record<ActivityCategory, number>;
  milestoneCounts: Record<MilestoneLevel, number>;
  keyAchievements: string[];
  teacherNotes: string;
  growthRating: number; // 1 - 5
}

export interface ParentPortalSections {
  showSummaryStats: boolean; // Quick 4-box metrics (Total, Capaian, etc)
  showCategoryFilter: boolean; // Kategori filter chips
  showTeacherRecommendation: boolean; // Catatan guru / evaluasi
  showWeeklyReportDownload: boolean; // Tombol unduh rapor PDF
  showAcademicCalendar: boolean; // Akses tab agenda akademik sekolah
  showDriveGallery: boolean; // Akses tab galeri foto kegiatan
  showWeeklySummaryTab: boolean; // Akses tab evaluasi mingguan
  allowParentFeedback: boolean; // Fitur bintang dan komentar orang tua
}

export interface SchoolSettings {
  schoolName: string;
  schoolSubheader: string;
  schoolAddress: string;
  academicYear: string;
  teacherInCharge: string;
  schoolLogo?: string; // Data URL / Image URL of school logo
  parentPortalSections: ParentPortalSections;
}

export const DEFAULT_SCHOOL_SETTINGS: SchoolSettings = {
  schoolName: 'SD & TK CENDEKIA HARAPAN',
  schoolSubheader: 'Pendidikan Karakter Unggul & Berakhlak Mulia',
  schoolAddress: 'Jl. Pendidikan No. 45, Jakarta Selatan | Telp: (021) 7890-1234',
  academicYear: '2026/2027',
  teacherInCharge: 'Ibu Ratna Kumalasari, S.Pd',
  schoolLogo: '',
  parentPortalSections: {
    showSummaryStats: true,
    showCategoryFilter: true,
    showTeacherRecommendation: true,
    showWeeklyReportDownload: true,
    showAcademicCalendar: true,
    showDriveGallery: true,
    showWeeklySummaryTab: true,
    allowParentFeedback: true,
  },
};
